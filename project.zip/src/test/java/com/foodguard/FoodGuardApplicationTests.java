package com.foodguard;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

@SpringBootTest
@ActiveProfiles("test")
class FoodGuardApplicationTests {

    @Test
    void contextLoads() {
        // Verifies Spring application context initializes successfully
    }
}
