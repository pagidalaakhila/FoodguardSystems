package com.foodguard.service;

import com.foodguard.dto.FoodActionDto;
import com.foodguard.entity.*;
import com.foodguard.repository.FoodActionRepository;
import com.foodguard.repository.FoodItemRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class FoodActionServiceTest {

    @Mock
    private FoodActionRepository foodActionRepository;

    @Mock
    private FoodItemRepository foodItemRepository;

    @InjectMocks
    private FoodActionService foodActionService;

    private User user;
    private FoodItem item;

    @BeforeEach
    void setUp() {
        user = new User("alex@example.com", "pass", "Alex Green");
        user.setId(10L);

        item = new FoodItem(
                user,
                "Greek Yogurt",
                FoodCategory.DAIRY,
                new BigDecimal("4.00"),
                "tubs",
                LocalDate.now().minusDays(3),
                LocalDate.now().plusDays(2),
                StorageLocation.FRIDGE,
                new BigDecimal("12.00"),
                "Breakfast tubs"
        );
        item.setId(50L);
    }

    @Test
    @DisplayName("Should reduce inventory and calculate proportional cost on partial consumption")
    void testPartialConsumption() {
        when(foodItemRepository.findById(50L)).thenReturn(Optional.of(item));
        when(foodActionRepository.save(any(FoodAction.class))).thenAnswer(invocation -> invocation.getArgument(0));

        // Consume 1 out of 4 tubs (cost impact = 12 * 1 / 4 = $3.00)
        FoodActionDto dto = new FoodActionDto(50L, ActionType.CONSUMED, new BigDecimal("1.00"), "Ate for breakfast");

        FoodAction action = foodActionService.logAction(dto, user);

        assertNotNull(action);
        assertEquals(ActionType.CONSUMED, action.getActionType());
        assertEquals(new BigDecimal("1.00"), action.getQuantity());
        assertEquals(new BigDecimal("3.00"), action.getCostImpact());

        // Verify remaining item quantity & cost
        assertEquals(new BigDecimal("3.00"), item.getQuantity());
        assertEquals(new BigDecimal("9.00"), item.getCost());
        verify(foodItemRepository, times(1)).save(item);
        verify(foodItemRepository, never()).delete(any(FoodItem.class));
    }

    @Test
    @DisplayName("Should remove item from inventory when entire quantity is consumed or donated")
    void testFullConsumptionRemovesItem() {
        when(foodItemRepository.findById(50L)).thenReturn(Optional.of(item));
        when(foodActionRepository.save(any(FoodAction.class))).thenAnswer(invocation -> invocation.getArgument(0));

        // Consume all 4 tubs
        FoodActionDto dto = new FoodActionDto(50L, ActionType.DONATED, new BigDecimal("4.00"), "Donated to food bank");

        FoodAction action = foodActionService.logAction(dto, user);

        assertNotNull(action);
        assertEquals(ActionType.DONATED, action.getActionType());
        assertEquals(new BigDecimal("12.00"), action.getCostImpact());

        // Verify item was deleted from active inventory
        verify(foodItemRepository, times(1)).delete(item);
    }

    @Test
    @DisplayName("Should reject logging quantity exceeding current inventory balance")
    void testExceedingQuantityThrowsException() {
        when(foodItemRepository.findById(50L)).thenReturn(Optional.of(item));

        FoodActionDto dto = new FoodActionDto(50L, ActionType.WASTED, new BigDecimal("5.00"), "Spoiled");

        assertThrows(IllegalArgumentException.class, () -> {
            foodActionService.logAction(dto, user);
        });
    }
}
