package com.foodguard.service;

import com.foodguard.dto.FoodItemDto;
import com.foodguard.entity.*;
import com.foodguard.exception.UnauthorizedException;
import com.foodguard.repository.FoodItemRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class FoodItemServiceTest {

    @Mock
    private FoodItemRepository foodItemRepository;

    @InjectMocks
    private FoodItemService foodItemService;

    private User user1;
    private User user2;
    private FoodItem item;

    @BeforeEach
    void setUp() {
        user1 = new User("user1@example.com", "secret", "User One");
        user1.setId(1L);

        user2 = new User("user2@example.com", "secret", "User Two");
        user2.setId(2L);

        item = new FoodItem(
                user1,
                "Organic Spinach",
                FoodCategory.PRODUCE,
                new BigDecimal("2.00"),
                "bags",
                LocalDate.now().minusDays(2),
                LocalDate.now().plusDays(2),
                StorageLocation.FRIDGE,
                new BigDecimal("5.00"),
                "Crisper drawer"
        );
        item.setId(100L);
    }

    @Test
    @DisplayName("Should accurately classify item expiring in 2 days as EXPIRING_SOON")
    void testExpiryClassificationExpiringSoon() {
        assertEquals(2, item.getDaysUntilExpiry());
        assertEquals(ExpiryStatus.EXPIRING_SOON, item.getStatus());
        assertEquals("Expires in 2 days", item.getExpiryBadgeText());
    }

    @Test
    @DisplayName("Should accurately classify expired item as EXPIRED")
    void testExpiryClassificationExpired() {
        item.setExpiryDate(LocalDate.now().minusDays(1));
        assertEquals(-1, item.getDaysUntilExpiry());
        assertEquals(ExpiryStatus.EXPIRED, item.getStatus());
        assertEquals("Expired yesterday", item.getExpiryBadgeText());
    }

    @Test
    @DisplayName("Should accurately classify item with long expiry as FRESH")
    void testExpiryClassificationFresh() {
        item.setExpiryDate(LocalDate.now().plusDays(10));
        assertEquals(10, item.getDaysUntilExpiry());
        assertEquals(ExpiryStatus.FRESH, item.getStatus());
        assertEquals("Expires in 10 days", item.getExpiryBadgeText());
    }

    @Test
    @DisplayName("Should throw UnauthorizedException when accessing item belonging to another user")
    void testOwnershipSecurityCheck() {
        when(foodItemRepository.findById(100L)).thenReturn(Optional.of(item));

        // User2 tries to access User1's item
        assertThrows(UnauthorizedException.class, () -> {
            foodItemService.getItemByIdAndUser(100L, user2);
        });
    }

    @Test
    @DisplayName("Should create and persist food item for user successfully")
    void testCreateFoodItem() {
        FoodItemDto dto = new FoodItemDto();
        dto.setName("Fresh Eggs");
        dto.setCategory(FoodCategory.DAIRY);
        dto.setQuantity(new BigDecimal("12.00"));
        dto.setUnit("items");
        dto.setPurchaseDate(LocalDate.now());
        dto.setExpiryDate(LocalDate.now().plusDays(14));
        dto.setStorageLocation(StorageLocation.FRIDGE);
        dto.setCost(new BigDecimal("4.00"));

        when(foodItemRepository.save(any(FoodItem.class))).thenAnswer(invocation -> invocation.getArgument(0));

        FoodItem created = foodItemService.createItem(dto, user1);
        assertNotNull(created);
        assertEquals("Fresh Eggs", created.getName());
        assertEquals(user1, created.getUser());
        verify(foodItemRepository, times(1)).save(any(FoodItem.class));
    }
}
