/**
 * FoodGuard - Core Client Application JavaScript
 */

document.addEventListener('DOMContentLoaded', () => {
    initModals();
    initActionModal();
    initDismissibleAlerts();
    initNotificationPoller();
    initConfirmationDialogs();
    initLanguageSelector();
});

/**
 * Universal Modal Management
 */
function initModals() {
    // Close modal on close button or backdrop click
    document.querySelectorAll('.modal-backdrop').forEach(backdrop => {
        backdrop.addEventListener('click', (e) => {
            if (e.target === backdrop) {
                closeModal(backdrop.id);
            }
        });

        const closeBtn = backdrop.querySelector('.modal-close, [data-modal-close]');
        if (closeBtn) {
            closeBtn.addEventListener('click', () => {
                closeModal(backdrop.id);
            });
        }
    });

    // ESC key closes any open modal
    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape') {
            document.querySelectorAll('.modal-backdrop.show').forEach(m => {
                closeModal(m.id);
            });
        }
    });
}

function openModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.classList.add('show');
        document.body.style.overflow = 'hidden';
    }
}

function closeModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.classList.remove('show');
        document.body.style.overflow = '';
    }
}

/**
 * Food Action / Kitchen Stock Logging Modal (Take / Cook / Deduct for Restaurants & Hotels)
 */
let currentItemMaxQty = 1.0;
let currentItemUnitCost = 0.0;
let currentItemUnit = 'kg';

function initActionModal() {
    const actionModal = document.getElementById('actionModal');
    if (!actionModal) return;

    const actionItemName = document.getElementById('actionItemName');
    const actionFoodItemId = document.getElementById('actionFoodItemId');
    const actionQuantityInput = document.getElementById('actionQuantityInput');
    const actionUnitDisplay = document.querySelectorAll('.action-unit-display');
    const actionMaxQtyDisplay = document.getElementById('actionMaxQtyDisplay');
    const actionItemCostDisplay = document.getElementById('actionItemCostDisplay');
    const actionItemCostHidden = document.getElementById('actionItemCostHidden');
    const actionTypeSelect = document.getElementById('actionTypeSelect');
    const actionRedirectUri = document.getElementById('actionRedirectUri');

    document.querySelectorAll('[data-open-action]').forEach(button => {
        button.addEventListener('click', () => {
            const itemId = button.getAttribute('data-item-id');
            const itemName = button.getAttribute('data-item-name');
            const itemQtyStr = button.getAttribute('data-item-quantity');
            const itemCostStr = button.getAttribute('data-item-cost') || '0';
            const itemUnit = button.getAttribute('data-item-unit') || 'kg';
            const defaultType = button.getAttribute('data-default-action') || 'CONSUMED';

            const itemQty = parseFloat(itemQtyStr) || 1.0;
            const itemCost = parseFloat(itemCostStr) || 0.0;

            currentItemMaxQty = itemQty;
            currentItemUnitCost = itemCost;
            currentItemUnit = itemUnit;

            if (actionFoodItemId) actionFoodItemId.value = itemId;
            if (actionItemName) actionItemName.textContent = itemName;
            if (actionMaxQtyDisplay) actionMaxQtyDisplay.textContent = formatCleanNumber(itemQty);
            if (actionItemCostDisplay) actionItemCostDisplay.textContent = itemCost.toFixed(2);
            if (actionItemCostHidden) actionItemCostHidden.value = itemCost.toFixed(2);
            if (actionTypeSelect) actionTypeSelect.value = defaultType;

            if (actionRedirectUri) {
                actionRedirectUri.value = window.location.pathname + window.location.search;
            }

            actionUnitDisplay.forEach(span => {
                span.textContent = itemUnit;
            });

            // For restaurants & hotels: auto-select half if stock > 0, else full
            const initialTake = itemQty >= 1.0 ? roundToTwo(itemQty / 2) : itemQty;
            if (actionQuantityInput) {
                actionQuantityInput.value = initialTake;
                actionQuantityInput.max = itemQty;
                actionQuantityInput.min = "0.01";
                actionQuantityInput.step = "0.01";
            }

            highlightActiveQuickBtn(initialTake, itemQty);
            updateKitchenStockPreview();
            openModal('actionModal');
        });
    });
}

function roundToTwo(num) {
    return Math.round((num + Number.EPSILON) * 100) / 100;
}

function formatCleanNumber(num) {
    if (num === null || num === undefined || isNaN(num)) return "0";
    return Number.isInteger(num) ? num.toString() : num.toFixed(2).replace(/\.?0+$/, '');
}

function setQuickFraction(fraction) {
    const actionQuantityInput = document.getElementById('actionQuantityInput');
    if (!actionQuantityInput) return;

    let targetQty = roundToTwo(currentItemMaxQty * fraction);
    if (targetQty <= 0) targetQty = 0.01;
    actionQuantityInput.value = targetQty;

    highlightActiveQuickBtn(targetQty, currentItemMaxQty);
    updateKitchenStockPreview();
}

function highlightActiveQuickBtn(currentVal, maxQty) {
    document.querySelectorAll('.quick-qty-btn').forEach(b => {
        b.style.borderColor = 'var(--charcoal-300)';
        b.style.color = 'var(--charcoal-700)';
        b.style.background = '#ffffff';
    });

    let activeBtnId = null;
    const ratio = maxQty > 0 ? (currentVal / maxQty) : 0;
    if (Math.abs(ratio - 0.25) < 0.02) activeBtnId = 'btnTakeQuarter';
    else if (Math.abs(ratio - 0.50) < 0.02) activeBtnId = 'btnTakeHalf';
    else if (Math.abs(ratio - 0.75) < 0.02) activeBtnId = 'btnTakeThreeQuarter';
    else if (Math.abs(ratio - 1.00) < 0.02) activeBtnId = 'btnTakeAll';

    if (activeBtnId) {
        const btn = document.getElementById(activeBtnId);
        if (btn) {
            btn.style.borderColor = 'var(--forest-600)';
            btn.style.color = 'var(--forest-800)';
            btn.style.background = 'var(--forest-50)';
        }
    }
}

function updateKitchenStockPreview() {
    const actionQuantityInput = document.getElementById('actionQuantityInput');
    if (!actionQuantityInput) return;

    const taking = parseFloat(actionQuantityInput.value) || 0;
    const remaining = Math.max(0, roundToTwo(currentItemMaxQty - taking));
    const costImpact = currentItemMaxQty > 0 ? roundToTwo((taking / currentItemMaxQty) * currentItemUnitCost) : 0;
    const remainingCost = Math.max(0, roundToTwo(currentItemUnitCost - costImpact));

    const takingDisplay = document.getElementById('previewTakingDisplay');
    const remainingDisplay = document.getElementById('previewRemainingDisplay');
    const costImpactDisplay = document.getElementById('previewCostImpact');
    const remCostDisplay = document.getElementById('previewRemainingCost');
    const statusBadge = document.getElementById('previewStatusBadge');
    const submitBtnText = document.getElementById('actionSubmitBtnText');
    const submitBtn = document.getElementById('actionSubmitBtn');

    if (takingDisplay) takingDisplay.textContent = `-${formatCleanNumber(taking)} ${currentItemUnit}`;
    if (remainingDisplay) remainingDisplay.textContent = `${formatCleanNumber(remaining)} ${currentItemUnit}`;
    if (costImpactDisplay) costImpactDisplay.textContent = `₹${costImpact.toFixed(2)}`;
    if (remCostDisplay) remCostDisplay.textContent = `₹${remainingCost.toFixed(2)}`;

    if (statusBadge) {
        if (taking <= 0) {
            statusBadge.innerHTML = `<span style="color: #dc2626;"><i class="fas fa-exclamation-triangle"></i> Please enter a quantity greater than zero.</span>`;
            if (submitBtn) submitBtn.disabled = true;
        } else if (taking > currentItemMaxQty) {
            statusBadge.innerHTML = `<span style="color: #dc2626;"><i class="fas fa-times-circle"></i> Exceeds available stock (${formatCleanNumber(currentItemMaxQty)} ${currentItemUnit} max)!</span>`;
            if (submitBtn) submitBtn.disabled = true;
        } else if (remaining === 0) {
            statusBadge.innerHTML = `<span style="color: #d97706;"><i class="fas fa-check-double"></i> Full stock taken. Item will be completed and cleared from active inventory.</span>`;
            if (submitBtn) submitBtn.disabled = false;
        } else {
            statusBadge.innerHTML = `<span style="color: #166534;"><i class="fas fa-check-circle"></i> <strong>${formatCleanNumber(remaining)} ${currentItemUnit}</strong> will stay active in your kitchen stock.</span>`;
            if (submitBtn) submitBtn.disabled = false;
        }
    }

    if (submitBtnText) {
        if (taking > 0 && taking <= currentItemMaxQty) {
            submitBtnText.textContent = `Take ${formatCleanNumber(taking)} ${currentItemUnit} & Update Inventory`;
        } else {
            submitBtnText.textContent = `Take Stock & Update Inventory`;
        }
    }
}

/**
 * Auto-dismiss alerts
 */
function initDismissibleAlerts() {
    const alerts = document.querySelectorAll('.alert');
    alerts.forEach(alert => {
        setTimeout(() => {
            alert.style.transition = 'opacity 0.4s ease, transform 0.4s ease';
            alert.style.opacity = '0';
            alert.style.transform = 'translateY(-8px)';
            setTimeout(() => alert.remove(), 400);
        }, 5000);
    });
}

/**
 * Notification Badge Poller
 */
function initNotificationPoller() {
    const badge = document.getElementById('navNotificationBadge');
    if (!badge) return;

    function checkUnread() {
        fetch('/notifications/api/unread-count')
            .then(res => {
                if (res.ok) return res.json();
                throw new Error('Not logged in or error');
            })
            .then(data => {
                if (data && data.count !== undefined) {
                    if (data.count > 0) {
                        badge.textContent = data.count > 99 ? '99+' : data.count;
                        badge.style.display = 'flex';
                    } else {
                        badge.style.display = 'none';
                    }
                }
            })
            .catch(() => {
                // Silently handle when user logs out
            });
    }

    // Check immediately on page load, then every 60 seconds
    checkUnread();
    setInterval(checkUnread, 60000);
}

/**
 * Confirmation Dialogs
 */
function initConfirmationDialogs() {
    document.querySelectorAll('[data-confirm]').forEach(el => {
        el.addEventListener('click', (e) => {
            const message = el.getAttribute('data-confirm') || 'Are you sure you want to proceed?';
            if (!confirm(message)) {
                e.preventDefault();
            }
        });
    });
}

/**
 * FoodGuard Full-Project Multi-Language (i18n) Engine & Comprehensive Dictionaries
 * Dual-Engine Architecture:
 *   1. Instant Offline Phrase & Substring Engine (0ms latency, handles DOM text nodes, placeholders, titles, attributes)
 *   2. Headless Google Website Translator Synchronization (handles arbitrary dynamic text & paragraph streams)
 *   3. MutationObserver Engine (auto-translates newly rendered modals, notifications, and dynamic cards)
 */
const FOODGUARD_TRANSLATIONS = {
    hi: {
        "FoodGuard": "FoodGuard",
        "Dashboard": "डैशबोर्ड",
        "Inventory": "इन्वेंटरी",
        "History": "इतिहास",
        "Recipes": "व्यंजन",
        "Analytics": "विश्लेषण",
        "Notifications": "सूचनाएं",
        "Alerts & Notices": "अलर्ट और सूचनाएं",
        "Alerts & Notifications": "अलर्ट और सूचनाएं",
        "Login": "लॉग इन",
        "Register": "पंजीकरण",
        "Logout": "लॉग आउट",
        "Sign Out": "साइन आउट",
        "Account": "खाता",
        "My Inventory": "मेरी इन्वेंटरी",
        "Official Analytics": "आधिकारिक विश्लेषण",
        "Official Profile & ID": "आधिकारिक प्रोफ़ाइल और आईडी",
        "Verified Official Account": "सत्यापित आधिकारिक खाता",
        "Sign In to Your Account": "अपने खाते में साइन इन करें",
        "Create a Free Account": "मुफ़्त खाता बनाएं",
        "Select Language": "भाषा चुनें",
        "Smart Kitchen Waste Prevention": "स्मार्ट रसोई अपशिष्ट रोकथाम",
        "Protect Your Food, Save Your Money & Cut Waste.": "अपने भोजन को सुरक्षित रखें, पैसे बचाएं और अपशिष्ट घटाएं।",
        "Protect Your Food,": "अपने भोजन को सुरक्षित रखें,",
        "Save Your Money": "पैसे बचाएं",
        "& Cut Waste.": "और अपशिष्ट घटाएं।",
        "FoodGuard is an intelligent food inventory and expiry prevention platform. Track expiration dates, get automated alerts, turn expiring items into delicious recipes, and quantify your real financial savings.": "FoodGuard एक बुद्धिमान खाद्य इन्वेंटरी और समाप्ति रोकथाम मंच है। समाप्ति तिथियों को ट्रैक करें, स्वचालित अलर्ट प्राप्त करें, और वास्तविक बचत मापें।",
        "Start Free Today": "आज ही मुफ़्त शुरू करें",
        "Go to Dashboard": "डैशबोर्ड पर जाएं",
        "Avg. Food Waste Reduced": "औसत खाद्य अपशिष्ट में कमी",
        "Annual Household Savings": "वार्षिक घरेलू बचत",
        "Dashboard Overview": "डैशबोर्ड अवलोकन",
        "Welcome back": "स्वागत है",
        "Here is your kitchen inventory status today.": "आज आपकी रसोई इन्वेंटरी की स्थिति यहाँ है।",
        "Active Items": "सक्रिय वस्तुएं",
        "Expiring Soon": "जल्द समाप्त होने वाला",
        "Expired Items": "समाप्त वस्तुएं",
        "Expired": "समाप्त",
        "Financial Saved": "वित्तीय बचत",
        "fresh & safe": "ताज़ा और सुरक्षित",
        "Needs action within": "कार्रवाई आवश्यक भीतर",
        "Audit or discard safely": "सुरक्षित रूप से ऑडिट या हटा दें",
        "prevention rate": "रोकथाम दर",
        "Items Requiring Immediate Attention": "तत्काल ध्यान देने योग्य वस्तुएं",
        "Items Expiring Soon": "जल्द समाप्त होने वाली वस्तुएं",
        "View All Expiring": "सभी समाप्त होने वाली देखें",
        "View All Inventory": "पूरी इन्वेंटरी देखें",
        "No items expiring soon!": "कोई वस्तु जल्द समाप्त नहीं हो रही!",
        "Your refrigerator and pantry are currently fresh and well-managed.": "आपका फ्रिज और पैंट्री ताज़ा और व्यवस्थित हैं।",
        "No items expiring soon! Your kitchen inventory is in great shape.": "कोई भी वस्तु जल्द समाप्त नहीं हो रही! आपकी रसोई सुरक्षित है।",
        "Waste-Preventing Recipes": "अपशिष्ट-रोकथाम व्यंजन",
        "Explore All": "सभी देखें",
        "Recent Actions Log": "हालिया गतिविधि लॉग",
        "Full History": "पूरा इतिहास",
        "Add Food Item": "खाद्य वस्तु जोड़ें",
        "Export CSV": "सीएसवी निर्यात",
        "Export to CSV": "सीएसवी में निर्यात करें",
        "Recipe Ideas": "व्यंजन विचार",
        "Take / Cook": "लें / पकाएं",
        "Cook / Log": "पकाएं / दर्ज करें",
        "Take / Use": "लें / उपयोग करें",
        "Food Inventory": "खाद्य इन्वेंटरी",
        "Food Inventory Management": "खाद्य इन्वेंटरी प्रबंधन",
        "Track, filter, and prevent food spoilage before expiration dates.": "खाद्य अपशिष्ट रोकें और समाप्ति तिथियों को ट्रैक करें।",
        "Add New Item": "नई वस्तु जोड़ें",
        "Search Items": "वस्तुएं खोजें",
        "Item or notes...": "वस्तु या विवरण...",
        "Search by item name...": "वस्तु के नाम से खोजें...",
        "Category": "श्रेणी",
        "All Categories": "सभी श्रेणियां",
        "Storage Location": "भंडारण स्थान",
        "All Locations": "सभी स्थान",
        "Expiry Status": "समाप्ति स्थिति",
        "All Statuses": "सभी स्थितियां",
        "Fresh & Safe": "ताज़ा और सुरक्षित",
        "Expiring Soon (≤3d)": "जल्द समाप्त होने वाला (≤3 दिन)",
        "Apply Filter": "फ़िल्टर लागू करें",
        "Reset Filters": "फ़िल्टर रीसेट करें",
        "Filter": "फ़िल्टर",
        "Clear": "साफ़ करें",
        "No inventory items found": "कोई इन्वेंटरी वस्तु नहीं मिली",
        "No items match your active filter criteria or your inventory is currently empty.": "कोई वस्तु आपके फ़िल्टर से मेल नहीं खाती या इन्वेंटरी खाली है।",
        "Add Your First Item": "अपनी पहली वस्तु जोड़ें",
        "Item Name": "वस्तु का नाम",
        "Qty": "मात्रा",
        "Quantity": "मात्रा",
        "Storage": "भंडारण",
        "Expiry Date": "समाप्ति तिथि",
        "Expiry Date (DD-MM-YYYY)": "समाप्ति तिथि (DD-MM-YYYY)",
        "Purchase Date (DD-MM-YYYY) *": "खरीद तिथि (DD-MM-YYYY) *",
        "Expiration Date (DD-MM-YYYY) *": "समाप्ति तिथि (DD-MM-YYYY) *",
        "Status": "स्थिति",
        "Cost": "लागत",
        "Actions": "कार्रवाई",
        "Action": "कार्रवाई",
        "Edit Item": "वस्तु संपादित करें",
        "Delete Item": "वस्तु हटाएं",
        "Edit": "संपादित करें",
        "Delete": "हटाएं",
        "Log": "दर्ज करें",
        "Showing page": "पृष्ठ दिखा रहा है",
        "total items": "कुल वस्तुएं",
        "Prev": "पिछला",
        "Next": "अगला",
        "Expires in": "समाप्त होने में",
        "days ago": "दिन पहले",
        "days": "दिन",
        "day": "दिन",
        "Take / Use Stock (Kitchen & Hotel)": "स्टॉक लें / उपयोग करें (रसोई और होटल)",
        "Take / Use Stock (Restaurant & Kitchen)": "स्टॉक लें / उपयोग करें (रेस्तरां और रसोई)",
        "Restaurant & Hotel Inventory Control • Deduct Partial Quantities (e.g. Half kg)": "रेस्तरां और होटल इन्वेंटरी नियंत्रण • आंशिक मात्रा घटाएं (उदा. आधा किलो)",
        "Selected Kitchen Item": "चयनित रसोई वस्तु",
        "Current In Stock": "वर्तमान में स्टॉक में",
        "Value:": "मूल्य:",
        "Purpose / Kitchen Action": "उद्देश्य / रसोई कार्रवाई",
        "Take for Kitchen Cooking / Restaurant Orders": "रसोई पकाने / रेस्तरां ऑर्डर के लिए लें",
        "Staff Meal / Community Donation": "स्टाफ भोजन / समुदाय दान",
        "Kitchen Spoilage / Trimming Waste": "रसोई अपशिष्ट / ट्रिमिंग कचरा",
        "Quick Restaurant Take Portions": "रेस्तरां त्वरित भाग",
        "Click to set amount": "मात्रा सेट करने के लिए क्लिक करें",
        "Quarter": "चौथाई (25%)",
        "Take Half": "आधा लें (50%)",
        "Take Half kg": "आधा किलो लें",
        "Take Half (50%)": "आधा लें (50%)",
        "Take All": "सभी लें (100%)",
        "Quantity to Take / Deduct *": "लेने / घटाने की मात्रा *",
        "Stock Change Live Preview": "स्टॉक परिवर्तन लाइव पूर्वावलोकन",
        "Taking Now:": "अभी ले रहे हैं:",
        "Remaining In Stock:": "स्टॉक में शेष:",
        "Cost Impact:": "लागत प्रभाव:",
        "Remaining Value:": "शेष मूल्य:",
        "will stay available in your kitchen inventory.": "आपकी रसोई इन्वेंटरी में उपलब्ध रहेगा।",
        "Kitchen Note / Order Reference (Optional)": "रसोई नोट / ऑर्डर संदर्भ (वैकल्पिक)",
        "Cancel": "रद्द करें",
        "Take Stock & Update Inventory": "स्टॉक लें और इन्वेंटरी अपडेट करें",
        "Confirm & Save": "पुष्टि करें और सहेजें",
        "Add New Food Item": "नया खाद्य उत्पाद जोड़ें",
        "Edit Food Item": "खाद्य उत्पाद संपादित करें",
        "Add to Inventory": "इन्वेंटरी में जोड़ें",
        "Update Item": "वस्तु अपडेट करें",
        "Estimated Cost (₹ INR)": "अनुमानित लागत (₹ INR)",
        "Notes": "टिप्पणियाँ",
        "Zero-Waste Recipes": "शून्य-अपशिष्ट व्यंजन",
        "Clever meal ideas automatically matched with ingredients waiting in your kitchen.": "आपकी रसोई में मौजूद सामग्रियों से स्वचालित रूप से मेल खाने वाले विचार।",
        "Search recipe or ingredient...": "व्यंजन या सामग्री खोजें...",
        "In Stock": "स्टॉक में",
        "Uses your inventory:": "आपकी इन्वेंटरी का उपयोग करता है:",
        "Cook This": "इसे पकाएं",
        "Ingredients": "सामग्री",
        "Instructions": "निर्देश",
        "Preparation Time": "तैयारी का समय",
        "Prep Time": "तैयारी समय",
        "Difficulty": "कठिनाई",
        "Servings": "सर्विंग्स",
        "mins": "मिनट",
        "Waste & Impact Analytics": "अपशिष्ट और प्रभाव विश्लेषण",
        "Real-time database analytics quantifying your household food savings and habits.": "वास्तविक समय डेटाबेस विश्लेषण जो आपकी खाद्य बचत और आदतों को मापता है।",
        "Download Audit CSV": "ऑडिट सीएसवी डाउनलोड करें",
        "Value Saved": "बचत मूल्य",
        "Financial Waste": "वित्तीय अपशिष्ट",
        "Prevention Rate": "रोकथाम दर",
        "Prevented from grocery waste": "किराने के कचरे से बचाया गया",
        "Estimated grocery loss": "अनुमानित किराना नुकसान",
        "Efficiency rating": "दक्षता रेटिंग",
        "Monthly Action Trends (Past 6 Months)": "मासिक गतिविधि रुझान (पिछले 6 महीने)",
        "Active Inventory by Category": "श्रेणी के अनुसार सक्रिय इन्वेंटरी",
        "Storage Location Distribution": "भंडारण स्थान वितरण",
        "Cumulative Financial Balance (₹)": "संचयी वित्तीय शेष (₹)",
        "Food Action History": "खाद्य गतिविधि इतिहास",
        "Action & Waste Audit History": "गतिविधि और अपशिष्ट ऑडिट इतिहास",
        "Audit log of consumed, donated, and wasted groceries with calculated financial impact.": "उपभोग, दान और व्यर्थ किराने का ऑडिट लॉग।",
        "Export History CSV": "इतिहास सीएसवी निर्यात",
        "Total Value Saved": "कुल बचत मूल्य",
        "Financial Loss (Wasted)": "वित्तीय नुकसान (अपशिष्ट)",
        "Financial Impact": "वित्तीय प्रभाव",
        "Percentage of items saved": "बचाई गई वस्तुओं का प्रतिशत",
        "items lost to waste": "वस्तुएं कचरे में गईं",
        "consumed": "उपभोग किया",
        "donated": "दान किया",
        "wasted": "व्यर्थ हुआ",
        "Official User Profile & Identity Dossier": "आधिकारिक उपयोगकर्ता प्रोफ़ाइल और पहचान दस्तावेज़",
        "Official Digital Household Identity Card": "आधिकारिक डिजिटल घरेलू पहचान पत्र",
        "FoodGuard National Food Security & Waste Prevention Registry": "FoodGuard राष्ट्रीय खाद्य सुरक्षा और अपशिष्ट रोकथाम रजिस्ट्री",
        "VERIFIED & ACTIVE": "सत्यापित और सक्रिय",
        "Primary Household Administrator": "प्राथमिक घरेलू प्रशासक",
        "Authorized digital identity credential for zero-waste compliance and household registry.": "शून्य-अपशिष्ट अनुपालन और घरेलू रजिस्ट्री के लिए अधिकृत डिजिटल पहचान।",
        "Print Official ID Card": "आधिकारिक आईडी कार्ड प्रिंट करें",
        "Print ID Card": "आईडी कार्ड प्रिंट करें",
        "Export Account Dossier": "खाता दस्तावेज़ निर्यात करें",
        "FoodGuard Official Credential": "FoodGuard आधिकारिक प्रमाण पत्र",
        "REPUBLIC OF INDIA • CITIZEN REGISTRY": "भारत गणराज्य • नागरिक रजिस्ट्री",
        "OFFICIAL HOLDER": "आधिकारिक धारक",
        "Official Full Name": "आधिकारिक पूरा नाम",
        "Unique Identity Number (UID)": "विशिष्ट पहचान संख्या (UID)",
        "Designation / Role": "पद / भूमिका",
        "Registered Email": "पंजीकृत ईमेल",
        "Date of Issue": "जारी करने की तिथि",
        "Enrolled": "नामांकित",
        "Security": "सुरक्षा",
        "Active Kitchen Items": "सक्रिय रसोई वस्तुएं",
        "Safely Consumed": "सुरक्षित उपभोग",
        "Community Donations": "सामुदायिक दान",
        "Verified Savings": "सत्यापित बचत",
        "Account Settings": "खाता सेटिंग्स",
        "Profile & Expiry Alert Preferences": "प्रोफ़ाइल और समाप्ति चेतावनी प्राथमिकताएं",
        "Email Address": "ईमेल पता",
        "Email Address (Account ID)": "ईमेल पता (खाता आईडी)",
        "Full Name": "पूरा नाम",
        "Expiry Warning Window (Days Before Expiration)": "समाप्ति चेतावनी अवधि (समाप्ति से पहले के दिन)",
        "Send me automated email notifications when items are about to expire": "वस्तुएं समाप्त होने पर मुझे स्वचालित ईमेल सूचनाएं भेजें",
        "Save Preferences": "प्राथमिकताएं सहेजें",
        "Change Password": "पासवर्ड बदलें",
        "Current Password": "वर्तमान पासवर्ड",
        "New Password": "नया पासवर्ड",
        "Confirm New Password": "नए पासवर्ड की पुष्टि करें",
        "Update Password": "पासवर्ड अपडेट करें",
        "Account Session": "खाता सत्र",
        "Log Out of FoodGuard": "FoodGuard से लॉग आउट करें",
        "Sign In": "साइन इन",
        "Sign In – FoodGuard": "साइन इन – FoodGuard",
        "Welcome Back": "वापसी पर स्वागत है",
        "Sign in to manage your food inventory": "अपनी खाद्य इन्वेंटरी प्रबंधित करने के लिए साइन इन करें",
        "Sign In to FoodGuard": "FoodGuard में साइन इन करें",
        "Instant Demo Login": "त्वरित डेमो लॉगिन",
        "Use Demo Account (Alex Green)": "डेमो खाते का उपयोग करें (Alex Green)",
        "Don't have an account yet?": "क्या अभी तक आपका खाता नहीं है?",
        "Sign Up": "साइन अप करें",
        "Create an Account": "खाता बनाएं",
        "Already have an account?": "क्या आपके पास पहले से खाता है?",
        "Mark All as Read": "सभी को पढ़ा हुआ चिह्नित करें",
        "No notifications": "कोई सूचना नहीं",
        "You have no alerts at this time.": "इस समय आपके पास कोई अलर्ट नहीं है।",
        "Empowering households and communities to eliminate food waste, save money, and cook delicious meals before ingredients expire.": "खाद्य अपशिष्ट समाप्त करने, पैसे बचाने और सामग्री समाप्त होने से पहले स्वादिष्ट भोजन पकाने के लिए सशक्त बनाना।",
        "Quick Navigation": "त्वरित नेविगेशन",
        "System Info": "सिस्टम जानकारी",
        "All rights reserved.": "सर्वाधिकार सुरक्षित।",
        "Fruits & Vegetables": "फल और सब्जियां",
        "Dairy & Eggs": "डेयरी और अंडे",
        "Meat & Poultry": "मांस और पोल्ट्री",
        "Fish & Seafood": "मछली और समुद्री भोजन",
        "Bakery & Bread": "बेकरी और ब्रेड",
        "Grains, Pasta & Rice": "अनाज और चावल",
        "Canned & Preserved": "डिब्बाबंद खाद्य",
        "Condiments & Sauces": "मसाले और सॉस",
        "Beverages": "पेय पदार्थ",
        "Snacks & Sweets": "स्नैक्स और मिठाइयाँ",
        "Frozen Foods": "फ्रोजन फूड",
        "Other": "अन्य",
        "Refrigerator": "रेफ्रिजरेटर (फ्रिज)",
        "Fridge": "फ्रिज",
        "Freezer": "फ्रीजर",
        "Pantry": "रसोई पैंट्री",
        "Countertop": "काउंटरटॉप"
    },
    te: {
        "FoodGuard": "FoodGuard",
        "Dashboard": "డాష్‌బోర్డ్",
        "Inventory": "ఇన్వెంటరీ",
        "History": "చరిత్ర",
        "Recipes": "వంటకాలు",
        "Analytics": "విశ్లేషణ",
        "Notifications": "నోటిఫికేషన్‌లు",
        "Alerts & Notices": "హెచ్చరికలు & నోటీసులు",
        "Alerts & Notifications": "హెచ్చరికలు & నోటిఫికేషన్‌లు",
        "Login": "లాగిన్",
        "Register": "నమోదు",
        "Logout": "లాగ్ అవుట్",
        "Sign Out": "సైన్ అవుట్",
        "Account": "ఖాతా",
        "My Inventory": "నా ఇన్వెంటరీ",
        "Official Analytics": "అధికారిక విశ్లేషణ",
        "Official Profile & ID": "అధికారిక ప్రొఫైల్ & ID",
        "Verified Official Account": "ధృవీకరించబడిన అధికారిక ఖాతా",
        "Sign In to Your Account": "మీ ఖాతాలోకి సైన్ ఇన్ అవ్వండి",
        "Create a Free Account": "ఉచిత ఖాతాను సృష్టించండి",
        "Select Language": "భాషను ఎంచుకోండి",
        "Smart Kitchen Waste Prevention": "స్మార్ట్ కిచెన్ ఆహార వృధా నివారణ",
        "Protect Your Food, Save Your Money & Cut Waste.": "మీ ఆహారాన్ని కాపాడుకోండి, డబ్బు ఆదా చేయండి & వృధాను తగ్గించండి.",
        "Protect Your Food,": "మీ ఆహారాన్ని కాపాడుకోండి,",
        "Save Your Money": "డబ్బు ఆదా చేయండి",
        "& Cut Waste.": "& వృధాను తగ్గించండి.",
        "FoodGuard is an intelligent food inventory and expiry prevention platform. Track expiration dates, get automated alerts, turn expiring items into delicious recipes, and quantify your real financial savings.": "FoodGuard ఒక తెలివైన ఆహార ఇన్వెంటరీ మరియు గడువు నివారణ వేదిక. గడువు తేదీలను ట్రాక్ చేయండి, ఆటోమేటెడ్ హెచ్చరికలను పొందండి మరియు నిజమైన పొదుపును లెక్కించండి.",
        "Start Free Today": "ఈరోజే ఉచితంగా ప్రారంభించండి",
        "Go to Dashboard": "డాష్‌బోర్డ్‌కు వెళ్లండి",
        "Avg. Food Waste Reduced": "సగటు ఆహార వృధా తగ్గింపు",
        "Annual Household Savings": "వార్షిక గృహ పొదుపు",
        "Dashboard Overview": "డాష్‌బోర్డ్ అవలోకనం",
        "Welcome back": "తిరిగి స్వాగతం",
        "Here is your kitchen inventory status today.": "ఈరోజు మీ కిచెన్ ఇన్వెంటరీ స్థితి ఇక్కడ ఉంది.",
        "Active Items": "క్రియాశీల అంశాలు",
        "Expiring Soon": "త్వరలో ముగియబోయేవి",
        "Expired Items": "గడువు ముగిసిన అంశాలు",
        "Expired": "గడువు ముగిసింది",
        "Financial Saved": "ఆర్థిక పొదుపు",
        "fresh & safe": "తాజా & సురక్షితం",
        "Needs action within": "లోపల చర్య అవసరం",
        "Audit or discard safely": "ఆడిట్ చేయండి లేదా సురక్షితంగా తొలగించండి",
        "prevention rate": "నివారణ రేటు",
        "Items Requiring Immediate Attention": "తక్షణ శ్రద్ధ అవసరమైన అంశాలు",
        "Items Expiring Soon": "త్వరలో గడువు ముగిసే అంశాలు",
        "View All Expiring": "గడువు ముగిసేవన్నీ చూడండి",
        "View All Inventory": "మొత్తం ఇన్వెంటరీని చూడండి",
        "No items expiring soon!": "ఏ వస్తువులూ త్వరలో గడువు ముగియడం లేదు!",
        "Your refrigerator and pantry are currently fresh and well-managed.": "మీ రిఫ్రిజిరేటర్ మరియు ప్యాంట్రీ ప్రస్తుతం తాజాగా మరియు చక్కగా నిర్వహించబడుతున్నాయి.",
        "No items expiring soon! Your kitchen inventory is in great shape.": "ఏ అంశాలు త్వరలో గడువు ముగియడం లేదు! మీ వంటగది సురక్షితంగా ఉంది.",
        "Waste-Preventing Recipes": "వృధా నివారణ వంటకాలు",
        "Explore All": "అన్నీ చూడండి",
        "Recent Actions Log": "ఇటీవలి చర్యల లాగ్",
        "Full History": "పూర్తి చరిత్ర",
        "Add Food Item": "ఆహార అంశాన్ని జోడించండి",
        "Export CSV": "CSV ఎగుమతి",
        "Export to CSV": "CSV కి ఎగుమతి చేయండి",
        "Recipe Ideas": "వంటల ఆలోచనలు",
        "Take / Cook": "తీసుకోండి / వండండి",
        "Cook / Log": "వండండి / లాగ్ చేయండి",
        "Take / Use": "తీసుకోండి / వాడండి",
        "Food Inventory": "ఆహార ఇన్వెంటరీ",
        "Food Inventory Management": "ఆహార ఇన్వెంటరీ నిర్వహణ",
        "Track, filter, and prevent food spoilage before expiration dates.": "ఆహార వృధాను అరికట్టండి మరియు గడువు తేదీలను ట్రాక్ చేయండి.",
        "Add New Item": "కొత్త అంశాన్ని జోడించండి",
        "Search Items": "అంశాలను శోధించండి",
        "Item or notes...": "అంశం లేదా గమనికలు...",
        "Search by item name...": "అంశం పేరు ద్వారా శోధించండి...",
        "Category": "వర్గం",
        "All Categories": "అన్ని వర్గాలు",
        "Storage Location": "నిల్వ స్థానం",
        "All Locations": "అన్ని స్థానాలు",
        "Expiry Status": "గడువు స్థితి",
        "All Statuses": "అన్ని స్థితులు",
        "Fresh & Safe": "తాజా మరియు సురక్షితం",
        "Expiring Soon (≤3d)": "త్వరలో ముగుస్తుంది (≤3 రోజులు)",
        "Apply Filter": "ఫిల్టర్‌ని వర్తింపజేయి",
        "Reset Filters": "ఫిల్టర్‌లను రీసెట్ చేయండి",
        "Filter": "ఫిల్టర్",
        "Clear": "క్లియర్",
        "No inventory items found": "ఇన్వెంటరీ అంశాలు కనుగొనబడలేదు",
        "No items match your active filter criteria or your inventory is currently empty.": "మీ ఫిల్టర్‌కు ఏ అంశాలూ సరిపోలడం లేదు లేదా ఇన్వెంటరీ ఖాళీగా ఉంది.",
        "Add Your First Item": "మీ మొదటి అంశాన్ని జోడించండి",
        "Item Name": "అంశం పేరు",
        "Qty": "పరిమాణం",
        "Quantity": "పరిమాణం",
        "Storage": "నిల్వ",
        "Expiry Date": "గడువు తేదీ",
        "Expiry Date (DD-MM-YYYY)": "గడువు తేదీ (DD-MM-YYYY)",
        "Purchase Date (DD-MM-YYYY) *": "కొనుగోలు తేదీ (DD-MM-YYYY) *",
        "Expiration Date (DD-MM-YYYY) *": "గడువు తేదీ (DD-MM-YYYY) *",
        "Status": "స్థితి",
        "Cost": "ధర",
        "Actions": "చర్యలు",
        "Action": "చర్య",
        "Edit Item": "అంశాన్ని సవరించండి",
        "Delete Item": "అంశాన్ని తొలగించండి",
        "Edit": "సవరించు",
        "Delete": "తొలగించు",
        "Log": "లాగ్ చేయండి",
        "Showing page": "పేజీ చూపిస్తోంది",
        "total items": "మొత్తం అంశాలు",
        "Prev": "మునుపటి",
        "Next": "తదుపరి",
        "Expires in": "ముగియడానికి గడువు",
        "days ago": "రోజుల క్రితం",
        "days": "రోజులు",
        "day": "రోజు",
        "Take / Use Stock (Kitchen & Hotel)": "స్టాక్ తీసుకోండి / ఉపయోగించండి (కిచెన్ & హోటల్)",
        "Take / Use Stock (Restaurant & Kitchen)": "స్టాక్ తీసుకోండి / ఉపయోగించండి (రెస్టారెంట్ & కిచెన్)",
        "Restaurant & Hotel Inventory Control • Deduct Partial Quantities (e.g. Half kg)": "రెస్టారెంట్ & హోటల్ ఇన్వెంటరీ కంట్రోల్ • పాక్షిక పరిమాణాలు తీసుకోండి (ఉదా. అర కిలో)",
        "Selected Kitchen Item": "ఎంచుకున్న కిచెన్ వస్తువు",
        "Current In Stock": "ప్రస్తుతం స్టాక్‌లో ఉంది",
        "Value:": "విలువ:",
        "Purpose / Kitchen Action": "ప్రయోజనం / కిచెన్ చర్య",
        "Take for Kitchen Cooking / Restaurant Orders": "వంట కోసం / రెస్టారెంట్ ఆర్డర్‌ల కోసం తీసుకోండి",
        "Staff Meal / Community Donation": "సిబ్బంది భోజనం / కమ్యూనిటీ విరాళం",
        "Kitchen Spoilage / Trimming Waste": "కిచెన్ పాడైన ఆహారం / వ్యర్థాలు",
        "Quick Restaurant Take Portions": "త్వరిత భాగాలు (రెస్టారెంట్)",
        "Click to set amount": "పరిమాణం సెట్ చేయడానికి క్లిక్ చేయండి",
        "Quarter": "పావు భాగం (25%)",
        "Take Half": "సగం తీసుకోండి (50%)",
        "Take Half kg": "అర కిలో తీసుకోండి",
        "Take Half (50%)": "సగం తీసుకోండి (50%)",
        "Take All": "మొత్తం తీసుకోండి (100%)",
        "Quantity to Take / Deduct *": "తీసుకోవలసిన / తగ్గించవలసిన పరిమాణం *",
        "Stock Change Live Preview": "స్టాక్ మార్పు ప్రత్యక్ష ప్రివ్యూ",
        "Taking Now:": "ఇప్పుడు తీసుకుంటున్నారు:",
        "Remaining In Stock:": "స్టాక్‌లో మిగిలి ఉన్నది:",
        "Cost Impact:": "ధర ప్రభావం:",
        "Remaining Value:": "మిగిలిన విలువ:",
        "will stay available in your kitchen inventory.": "మీ వంటగది ఇన్వెంటరీలో అందుబాటులో ఉంటుంది.",
        "Kitchen Note / Order Reference (Optional)": "కిచెన్ నోట్ / ఆర్డర్ రిఫరెన్స్ (ఐచ్ఛికం)",
        "Cancel": "రద్దు చేయండి",
        "Take Stock & Update Inventory": "స్టాక్ తీసుకొని ఇన్వెంటరీని నవీకరించండి",
        "Confirm & Save": "నిర్ధారించి సేవ్ చేయండి",
        "Add New Food Item": "కొత్త ఆహార అంశాన్ని జోడించండి",
        "Edit Food Item": "ఆహార అంశాన్ని సవరించండి",
        "Add to Inventory": "ఇన్వెంటరీకి జోడించండి",
        "Update Item": "అంశాన్ని నవీకరించండి",
        "Estimated Cost (₹ INR)": "అంచనా ధర (₹ INR)",
        "Notes": "గమనికలు",
        "Zero-Waste Recipes": "శూన్య-వృధా వంటకాలు",
        "Clever meal ideas automatically matched with ingredients waiting in your kitchen.": "మీ వంటగదిలోని పదార్థాలతో ఆటోమేటిక్‌గా సరిపోలే భోజన ఆలోచనలు.",
        "Search recipe or ingredient...": "వంటకం లేదా పదార్థం కోసం శోధించండి...",
        "In Stock": "స్టాక్‌లో ఉంది",
        "Uses your inventory:": "మీ ఇన్వెంటరీని ఉపయోగిస్తుంది:",
        "Cook This": "దీన్ని వండండి",
        "Ingredients": "పదార్థాలు",
        "Instructions": "సూచనలు",
        "Preparation Time": "తయారీ సమయం",
        "Prep Time": "తయారీ సమయం",
        "Difficulty": "కష్టం స్థాయి",
        "Servings": "సర్వింగ్‌లు",
        "mins": "నిమిషాలు",
        "Waste & Impact Analytics": "వృధా మరియు ప్రభావ విశ్లేషణ",
        "Real-time database analytics quantifying your household food savings and habits.": "మీ ఆహార పొదుపు మరియు అలవాట్లను కొలిచే నిజ-సమయ విశ్లేషణలు.",
        "Download Audit CSV": "ఆడిట్ CSV డౌన్‌లోడ్ చేయండి",
        "Value Saved": "ఆదా చేసిన విలువ",
        "Financial Waste": "ఆర్థిక వృధా",
        "Prevention Rate": "నివారణ రేటు",
        "Prevented from grocery waste": "కిరాణా వృధా నుండి నివారించబడింది",
        "Estimated grocery loss": "అంచనా వేసిన కిరాణా నష్టం",
        "Efficiency rating": "సామర్థ్య రేటింగ్",
        "Monthly Action Trends (Past 6 Months)": "నెలవారీ చర్యల పోకడలు (గత 6 నెలలు)",
        "Active Inventory by Category": "వర్గం వారీగా క్రియాశీల ఇన్వెంటరీ",
        "Storage Location Distribution": "నిల్వ స్థానాల పంపిణీ",
        "Cumulative Financial Balance (₹)": "మొత్తం ఆర్థిక నిల్వ (₹)",
        "Food Action History": "ఆహార చర్యల చరిత్ర",
        "Action & Waste Audit History": "చర్య & వృధా ఆడిట్ చరిత్ర",
        "Audit log of consumed, donated, and wasted groceries with calculated financial impact.": "తీసుకున్న, విరాళం ఇచ్చిన, వృధా అయిన ఆహార ఆడిట్ లాగ్.",
        "Export History CSV": "చరిత్ర CSV ఎగుమతి",
        "Total Value Saved": "మొత్తం ఆదా చేసిన విలువ",
        "Financial Loss (Wasted)": "ఆర్థిక నష్టం (వృధా)",
        "Financial Impact": "ఆర్థిక ప్రభావం",
        "Percentage of items saved": "ఆదా చేయబడిన వస్తువుల శాతం",
        "items lost to waste": "వృధాగా పోయిన వస్తువులు",
        "consumed": "తీసుకున్నారు",
        "donated": "దానం చేశారు",
        "wasted": "వృధా అయింది",
        "Official User Profile & Identity Dossier": "అధికారిక యూజర్ ప్రొఫైల్ & గుర్తింపు రికార్డు",
        "Official Digital Household Identity Card": "అధికారిక డిజిటల్ గృహ గుర్తింపు కార్డు",
        "FoodGuard National Food Security & Waste Prevention Registry": "FoodGuard జాతీయ ఆహార భద్రత & వృధా నివారణ రిజిస్ట్రీ",
        "VERIFIED & ACTIVE": "ధృవీకరించబడింది & యాక్టివ్",
        "Primary Household Administrator": "ప్రాథమిక గృహ నిర్వాహకుడు",
        "Authorized digital identity credential for zero-waste compliance and household registry.": "సున్నా-వృధా రిజిస్ట్రీ కోసం అధీకృత డిజిటల్ గుర్తింపు.",
        "Print Official ID Card": "అధికారిక ID కార్డును ప్రింట్ చేయండి",
        "Print ID Card": "ID కార్డును ప్రింట్ చేయండి",
        "Export Account Dossier": "ఖాతా రికార్డును ఎగుమతి చేయండి",
        "FoodGuard Official Credential": "FoodGuard అధికారిక గుర్తింపు పత్రం",
        "REPUBLIC OF INDIA • CITIZEN REGISTRY": "భారత గణతంత్ర రాజ్యం • పౌర రిజిస్ట్రీ",
        "OFFICIAL HOLDER": "అధికారిక హోల్డర్",
        "Official Full Name": "అధికారిక పూర్తి పేరు",
        "Unique Identity Number (UID)": "ప్రత్యేక గుర్తింపు సంఖ్య (UID)",
        "Designation / Role": "హోదా / పాత్ర",
        "Registered Email": "నమోదిత ఇమెయిల్",
        "Date of Issue": "జారీ చేసిన తేదీ",
        "Enrolled": "చేరిన తేదీ",
        "Security": "భద్రత",
        "Active Kitchen Items": "యాక్టివ్ కిచెన్ అంశాలు",
        "Safely Consumed": "సురక్షితంగా వినియోగించారు",
        "Community Donations": "కమ్యూనిటీ విరాళాలు",
        "Verified Savings": "ధృవీకరించబడిన పొదుపు",
        "Account Settings": "ఖాతా సెట్టింగ్‌లు",
        "Profile & Expiry Alert Preferences": "ప్రొఫైల్ & హెచ్చరిక ప్రాధాన్యతలు",
        "Email Address": "ఇమెయిల్ చిరునామా",
        "Email Address (Account ID)": "ఇమెయిల్ చిరునామా (ఖాతా ID)",
        "Full Name": "పూర్తి పేరు",
        "Expiry Warning Window (Days Before Expiration)": "గడువు హెచ్చరిక రోజులు (ముగియడానికి ముందు)",
        "Send me automated email notifications when items are about to expire": "ఆహారం ముగియబోతున్నప్పుడు ఆటోమేటెడ్ ఇమెయిల్ నోటిఫికేషన్‌లను పంపండి",
        "Save Preferences": "ప్రాధాన్యతలను సేవ్ చేయండి",
        "Change Password": "పాస్‌వర్డ్‌ను మార్చండి",
        "Current Password": "ప్రస్తుత పాస్‌వర్డ్",
        "New Password": "కొత్త పాస్‌వర్డ్",
        "Confirm New Password": "కొత్త పాస్‌వర్డ్‌ను నిర్ధారించండి",
        "Update Password": "పాస్‌వర్డ్‌ను నవీకరించండి",
        "Account Session": "ఖాతా సెషన్",
        "Log Out of FoodGuard": "FoodGuard నుండి లాగ్ అవుట్ చేయండి",
        "Sign In": "సైన్ ఇన్",
        "Sign In – FoodGuard": "సైన్ ఇన్ – FoodGuard",
        "Welcome Back": "తిరిగి స్వాగతం",
        "Sign in to manage your food inventory": "మీ ఆహార ఇన్వెంటరీని నిర్వహించడానికి సైన్ ఇన్ చేయండి",
        "Sign In to FoodGuard": "FoodGuard లోకి సైన్ ఇన్ అవ్వండి",
        "Instant Demo Login": "తక్షణ డెమో లాగిన్",
        "Use Demo Account (Alex Green)": "డెమో ఖాతాను ఉపయోగించండి (Alex Green)",
        "Don't have an account yet?": "ఇంకా ఖాతా లేదా?",
        "Sign Up": "సైన్ అప్ చేయండి",
        "Create an Account": "ఖాతాను సృష్టించండి",
        "Already have an account?": "ఇప్పటికే ఖాతా ఉందా?",
        "Mark All as Read": "అన్నీ చదివినట్లుగా గుర్తించండి",
        "No notifications": "నోటిఫికేషన్‌లు లేవు",
        "You have no alerts at this time.": "ఈ సమయంలో మీకు ఎలాంటి హెచ్చరికలు లేవు.",
        "Empowering households and communities to eliminate food waste, save money, and cook delicious meals before ingredients expire.": "ఆహార వృధాను అరికట్టడానికి, డబ్బు ఆదా చేయడానికి మరియు ఆహారం పాడవక ముందే రుచికరమైన భోజనం వండడానికి సహాయం చేస్తుంది.",
        "Quick Navigation": "త్వరిత నావిగేషన్",
        "System Info": "సిస్టమ్ సమాచారం",
        "All rights reserved.": "సర్వహక్కులూ ప్రత్యేకించబడినవి.",
        "Fruits & Vegetables": "పండ్లు & కూరగాయలు",
        "Dairy & Eggs": "డైరీ & గుడ్లు",
        "Meat & Poultry": "మాంసం & పౌల్ట్రీ",
        "Fish & Seafood": "చేపలు & సీఫుడ్",
        "Bakery & Bread": "బేకరీ & బ్రెడ్",
        "Grains, Pasta & Rice": "ధాన్యాలు & బియ్యం",
        "Canned & Preserved": "తయారుచేసిన ఆహారాలు",
        "Condiments & Sauces": "మసాలాలు & సాస్‌లు",
        "Beverages": "పానీయాలు",
        "Snacks & Sweets": "స్నాక్స్ & స్వీట్స్",
        "Frozen Foods": "ఫ్రోజెన్ ఫుడ్స్",
        "Other": "ఇతర",
        "Refrigerator": "రిఫ్రిజిరేటర్ (ఫ్రిజ్)",
        "Fridge": "ఫ్రిజ్",
        "Freezer": "ఫ్రీజర్",
        "Pantry": "ప్యాంట్రీ",
        "Countertop": "కౌంటర్‌టాప్"
    },
    ta: {
        "FoodGuard": "FoodGuard",
        "Dashboard": "டாஷ்போர்டு",
        "Inventory": "சரக்கு",
        "History": "வரலாறு",
        "Recipes": "சமையல் குறிப்புகள்",
        "Analytics": "பகுப்பாய்வு",
        "Notifications": "அறிவிப்புகள்",
        "Alerts & Notices": "எச்சரிக்கைகள் & குறிப்புகள்",
        "Alerts & Notifications": "எச்சரிக்கைகள் & அறிவிப்புகள்",
        "Login": "உள்நுழைக",
        "Register": "பதிவு செய்க",
        "Logout": "வெளியேறு",
        "Sign Out": "வெளியேறு",
        "Account": "கணக்கு",
        "My Inventory": "எனது சரக்கு",
        "Official Analytics": "அதிகாரப்பூர்வ பகுப்பாய்வு",
        "Official Profile & ID": "அதிகாரப்பூர்வ சுயவிவரம் & ID",
        "Verified Official Account": "சரிபார்க்கப்பட்ட அதிகாரப்பூர்வ கணக்கு",
        "Sign In to Your Account": "உங்கள் கணக்கில் உள்நுழைக",
        "Create a Free Account": "இலவச கணக்கை உருவாக்குங்கள்",
        "Select Language": "மொழியைத் தேர்ந்தெடுக்கவும்",
        "Smart Kitchen Waste Prevention": "சமையலறை உணவு கழிவு தடுப்பு",
        "Protect Your Food, Save Your Money & Cut Waste.": "உங்கள் உணவைப் பாதுகாக்கவும், பணத்தைச் சேமிக்கவும், கழிவைக் குறைக்கவும்.",
        "Protect Your Food,": "உங்கள் உணவைப் பாதுகாக்கவும்,",
        "Save Your Money": "பணத்தைச் சேமிக்கவும்",
        "& Cut Waste.": "& கழிவைக் குறைக்கவும்.",
        "Start Free Today": "இன்றே இலவசமாக தொடங்குங்கள்",
        "Go to Dashboard": "டாஷ்போர்டிற்குச் செல்லவும்",
        "Avg. Food Waste Reduced": "சராசரி உணவு கழிவு குறைப்பு",
        "Annual Household Savings": "ஆண்டு குடும்ப சேமிப்பு",
        "Dashboard Overview": "டாஷ்போர்டு கண்ணோட்டம்",
        "Welcome back": "மீண்டும் வருக",
        "Here is your kitchen inventory status today.": "இன்று உங்கள் சமையலறை சரக்கு நிலை இதோ.",
        "Active Items": "செயலில் உள்ள பொருட்கள்",
        "Expiring Soon": "விரைவில் காலாவதியாகிறது",
        "Expired Items": "காலாவதியான பொருட்கள்",
        "Expired": "காலாவதியானது",
        "Financial Saved": "சேமிக்கப்பட்ட தொகை",
        "fresh & safe": "புதியது & பாதுகாப்பானது",
        "Needs action within": "இதற்குள் நடவடிக்கை தேவை",
        "prevention rate": "தடுப்பு விகிதம்",
        "Items Requiring Immediate Attention": "உடனடி கவனம் தேவைப்படும் பொருட்கள்",
        "Items Expiring Soon": "விரைவில் காலாவதியாகும் பொருட்கள்",
        "View All Expiring": "அனைத்தையும் காண்க",
        "View All Inventory": "முழு சரக்கையும் காண்க",
        "No items expiring soon!": "விரைவில் காலாவதியாகும் பொருட்கள் எதுவுமில்லை!",
        "Waste-Preventing Recipes": "கழிவு தடுக்கும் சமையல் குறிப்புகள்",
        "Explore All": "அனைத்தையும் ஆராயுங்கள்",
        "Recent Actions Log": "சமீபத்திய நடவடிக்கைகள்",
        "Full History": "முழு வரலாறு",
        "Add Food Item": "உணவுப் பொருளைச் சேர்க்கவும்",
        "Export CSV": "CSV ஏற்றுமதி",
        "Export to CSV": "CSV இல் ஏற்றுமதி செய்க",
        "Recipe Ideas": "சமையல் யோசனைகள்",
        "Take / Cook": "எடு / சமைக்க",
        "Cook / Log": "சமைக்கவும் / பதிவு செய்யவும்",
        "Take / Use": "எடு / பயன்படுத்து",
        "Food Inventory": "உணவு சரக்கு",
        "Food Inventory Management": "உணவு சரக்கு மேலாண்மை",
        "Track, filter, and prevent food spoilage before expiration dates.": "உணவு கெட்டுப்போவதைத் தடுத்து காலாவதி தேதிகளைக் கண்காணிக்கவும்.",
        "Add New Item": "புதிய பொருளைச் சேர்க்கவும்",
        "Search Items": "பொருட்களைத் தேடுங்கள்",
        "Item or notes...": "பொருள் அல்லது குறிப்புகள்...",
        "Search by item name...": "பொருளின் பெயரால் தேடுங்கள்...",
        "Category": "வகை",
        "All Categories": "அனைத்து வகைகள்",
        "Storage Location": "சேமிப்பு இடம்",
        "All Locations": "அனைத்து இடங்கள்",
        "Expiry Status": "காலாவதி நிலை",
        "All Statuses": "அனைத்து நிலைகள்",
        "Fresh & Safe": "புதியது மற்றும் பாதுகாப்பானது",
        "Expiring Soon (≤3d)": "விரைவில் காலாவதியாகிறது (≤3 நாட்கள்)",
        "Apply Filter": "வடிகட்டியைப் பயன்படுத்து",
        "Reset Filters": "மீட்டமை",
        "Filter": "வடிகட்டு",
        "Clear": "அழி",
        "No inventory items found": "சரக்கு பொருட்கள் எதுவும் கிடைக்கவில்லை",
        "Add Your First Item": "உங்கள் முதல் பொருளைச் சேர்க்கவும்",
        "Item Name": "பொருளின் பெயர்",
        "Qty": "அளவு",
        "Quantity": "அளவு",
        "Storage": "சேமிப்பு",
        "Expiry Date": "காலாவதி தேதி",
        "Expiry Date (DD-MM-YYYY)": "காலாவதி தேதி (DD-MM-YYYY)",
        "Status": "நிலை",
        "Cost": "விலை",
        "Actions": "செயல்கள்",
        "Action": "செயல்",
        "Edit Item": "பொருளைத் திருத்து",
        "Delete Item": "பொருளை நீக்கு",
        "Edit": "திருத்து",
        "Delete": "நீக்கு",
        "Log": "பதிவு செய்",
        "Showing page": "பக்கத்தைக் காட்டுகிறது",
        "total items": "மொத்த பொருட்கள்",
        "Prev": "முந்தைய",
        "Next": "அடுத்தது",
        "Expires in": "காலாவதியாகிறது",
        "days ago": "நாட்களுக்கு முன்பு",
        "days": "நாட்கள்",
        "day": "நாள்",
        "Take / Use Stock (Kitchen & Hotel)": "சரக்கை எடுக்கவும் / பயன்படுத்தவும் (சமையலறை & ஹோட்டல்)",
        "Take / Use Stock (Restaurant & Kitchen)": "சரக்கை எடுக்கவும் / பயன்படுத்தவும் (உணவகம் & சமையலறை)",
        "Restaurant & Hotel Inventory Control • Deduct Partial Quantities (e.g. Half kg)": "உணவக சரக்கு கட்டுப்பாடு • பகுதி அளவை எடுக்கவும் (எ.கா. அரை கிலோ)",
        "Selected Kitchen Item": "தேர்ந்தெடுக்கப்பட்ட சமையலறை பொருள்",
        "Current In Stock": "தற்போது கையிருப்பில் உள்ளது",
        "Value:": "மதிப்பு:",
        "Quarter": "கால் பகுதி (25%)",
        "Take Half": "அரை பகுதி எடு (50%)",
        "Take Half kg": "அரை கிலோ எடுக்கவும்",
        "Take Half (50%)": "அரை பகுதி எடு (50%)",
        "Take All": "அனைத்தையும் எடு (100%)",
        "Quantity to Take / Deduct *": "எடுக்க வேண்டிய அளவு *",
        "Stock Change Live Preview": "கையிருப்பு மாற்ற முன்னோட்டம்",
        "Taking Now:": "இப்போது எடுப்பது:",
        "Remaining In Stock:": "மீதமுள்ள கையிருப்பு:",
        "Cost Impact:": "செலவு தாக்கம்:",
        "Remaining Value:": "மீதமுள்ள மதிப்பு:",
        "will stay available in your kitchen inventory.": "உங்கள் சமையலறை சரக்கில் கிடைக்கும்.",
        "Cancel": "ரத்துசெய்",
        "Take Stock & Update Inventory": "சரக்கை எடுத்து புதுப்பிக்கவும்",
        "Confirm & Save": "உறுதிசெய்து சேமிக்கவும்",
        "Add New Food Item": "புதிய உணவுப் பொருளைச் சேர்க்கவும்",
        "Edit Food Item": "உணவுப் பொருளைத் திருத்தவும்",
        "Add to Inventory": "சரக்கில் சேர்க்கவும்",
        "Update Item": "பொருளைப் புதுப்பிக்கவும்",
        "Estimated Cost (₹ INR)": "மதிப்பிடப்பட்ட விலை (₹ INR)",
        "Notes": "குறிப்புகள்",
        "Zero-Waste Recipes": "கழிவு தடுக்கும் சமையல் குறிப்புகள்",
        "In Stock": "கையிருப்பில்",
        "Uses your inventory:": "உங்கள் சரக்கைப் பயன்படுத்துகிறது:",
        "Cook This": "இதைச் சமைக்கவும்",
        "Ingredients": "பொருட்கள்",
        "Instructions": "வழிமுறைகள்",
        "Prep Time": "தயாரிப்பு நேரம்",
        "mins": "நிமிடங்கள்",
        "Waste & Impact Analytics": "கழிவு மற்றும் தாக்க பகுப்பாய்வு",
        "Download Audit CSV": "தணிக்கை CSV பதிவிறக்கவும்",
        "Value Saved": "சேமிக்கப்பட்ட மதிப்பு",
        "Financial Waste": "நிதி விரயம்",
        "Prevention Rate": "தடுப்பு விகிதம்",
        "Food Action History": "உணவு நடவடிக்கை வரலாறு",
        "Total Value Saved": "மொத்த சேமிப்பு மதிப்பு",
        "Financial Loss (Wasted)": "நிதி இழப்பு (கழிவு)",
        "Official Digital Household Identity Card": "அதிகாரப்பூர்வ டிஜிட்டல் குடும்ப அடையாள அட்டை",
        "Print Official ID Card": "அடையாள அட்டையை அச்சிடுக",
        "Print ID Card": "அடையாள அட்டை அச்சிடு",
        "Official Full Name": "அதிகாரப்பூர்வ முழு பெயர்",
        "Unique Identity Number (UID)": "தனித்துவ அடையாள எண் (UID)",
        "Designation / Role": "பதவி / பங்கு",
        "Registered Email": "பதிவு செய்யப்பட்ட மின்னஞ்சல்",
        "Active Kitchen Items": "செயலில் உள்ள பொருட்கள்",
        "Safely Consumed": "பாதுகாப்பாக உட்கொள்ளப்பட்டது",
        "Community Donations": "சமூக நன்கொடைகள்",
        "Verified Savings": "சரிபார்க்கப்பட்ட சேமிப்பு",
        "Account Settings": "கணக்கு அமைப்புகள்",
        "Profile & Expiry Alert Preferences": "சுயவிவர & எச்சரிக்கை விருப்பங்கள்",
        "Email Address": "மின்னஞ்சல் முகவரி",
        "Full Name": "முழு பெயர்",
        "Save Preferences": "விருப்பங்களைச் சேமிக்கவும்",
        "Change Password": "கடவுச்சொல்லை மாற்றவும்",
        "Current Password": "தற்போதைய கடவுச்சொல்",
        "New Password": "புதிய கடவுச்சொல்",
        "Confirm New Password": "புதிய கடவுச்சொல்லை உறுதிப்படுத்தவும்",
        "Update Password": "கடவுச்சொல்லைப் புதுப்பிக்கவும்",
        "Log Out of FoodGuard": "FoodGuard இலிருந்து வெளியேறவும்",
        "Sign In": "உள்நுழைக",
        "Welcome Back": "மீண்டும் வருக",
        "Sign in to manage your food inventory": "உங்கள் சரக்கை நிர்வகிக்க உள்நுழைக",
        "Sign In to FoodGuard": "FoodGuard இல் உள்நுழைக",
        "Instant Demo Login": "உடனடி டெமோ உள்நுழைவு",
        "Use Demo Account (Alex Green)": "டெமோ கணக்கைப் பயன்படுத்துங்கள் (Alex Green)",
        "Don't have an account yet?": "இன்னும் கணக்கு இல்லையா?",
        "Sign Up": "பதிவு செய்க",
        "Create an Account": "கணக்கை உருவாக்கவும்",
        "Already have an account?": "ஏற்கனவே கணக்கு உள்ளதா?",
        "Mark All as Read": "அனைத்தையும் படித்ததாகக் குறிக்கவும்",
        "No notifications": "அறிவிப்புகள் இல்லை",
        "You have no alerts at this time.": "உங்களுக்கு இப்போது எந்த எச்சரிக்கையும் இல்லை.",
        "Quick Navigation": "விரைவு வழிசெலுத்தல்",
        "System Info": "கணினி தகவல்",
        "All rights reserved.": "அனைத்து உரிமைகளும் பாதுகாக்கப்பட்டவை.",
        "Fruits & Vegetables": "பழங்கள் & காய்கறிகள்",
        "Dairy & Eggs": "பால் & முட்டை",
        "Meat & Poultry": "இறைச்சி & கோழி",
        "Fish & Seafood": "மீன் & கடல் உணவு",
        "Bakery & Bread": "பேக்கரி & ரொட்டி",
        "Grains, Pasta & Rice": "தானியங்கள் & அரிசி",
        "Canned & Preserved": "பதப்படுத்தப்பட்ட உணவு",
        "Condiments & Sauces": "மசாலா & சாஸ்கள்",
        "Beverages": "பானங்கள்",
        "Snacks & Sweets": "சிற்றுண்டி & இனிப்புகள்",
        "Frozen Foods": "உறைந்த உணவுகள்",
        "Other": "மற்றவை",
        "Refrigerator": "குளிர்சாதன பெட்டி",
        "Fridge": "பிரிட்ஜ்",
        "Freezer": "பிரீசர்",
        "Pantry": "அஞ்சறைப் பெட்டி",
        "Countertop": "கவுண்டர்டாப்"
    },
    kn: {
        "FoodGuard": "FoodGuard",
        "Dashboard": "ಡ್ಯಾಶ್‌ಬೋರ್ಡ್",
        "Inventory": "ದಾಸ್ತಾನು",
        "History": "ಇತಿಹಾಸ",
        "Recipes": "ಪಾಕವಿಧಾನಗಳು",
        "Analytics": "ವಿಶ್ಲೇಷಣೆ",
        "Notifications": "ಅಧಿಸೂಚನೆಗಳು",
        "Alerts & Notices": "ಎಚ್ಚರಿಕೆಗಳು & ಸೂಚನೆಗಳು",
        "Alerts & Notifications": "ಎಚ್ಚರಿಕೆಗಳು & ಅಧಿಸೂಚನೆಗಳು",
        "Login": "ಲಾಗಿನ್",
        "Register": "ನೋಂದಣಿ",
        "Logout": "ಲಾಗ್ ಔಟ್",
        "Sign Out": "ಸೈನ್ ಔಟ್",
        "Account": "ಖಾತೆ",
        "My Inventory": "ನನ್ನ ದಾಸ್ತಾನು",
        "Official Analytics": "ಅಧಿಕೃತ ವಿಶ್ಲೇಷಣೆ",
        "Official Profile & ID": "ಅಧಿಕೃತ ಪ್ರೊಫೈಲ್ & ID",
        "Verified Official Account": "ಪರಿಶೀಲಿಸಿದ ಅಧಿಕೃತ ಖಾತೆ",
        "Sign In to Your Account": "ನಿಮ್ಮ ಖಾತೆಗೆ ಸೈನ್ ಇನ್ ಮಾಡಿ",
        "Create a Free Account": "ಉಚಿತ ಖಾತೆಯನ್ನು ರಚಿಸಿ",
        "Select Language": "ಭಾಷೆಯನ್ನು ಆಯ್ಕೆಮಾಡಿ",
        "Smart Kitchen Waste Prevention": "ಸ್ಮಾರ್ಟ್ ಅಡುಗೆಮನೆ ತ್ಯಾಜ್ಯ ತಡೆಗಟ್ಟುವಿಕೆ",
        "Protect Your Food, Save Your Money & Cut Waste.": "ನಿಮ್ಮ ಆಹಾರವನ್ನು ರಕ್ಷಿಸಿ, ಹಣ ಉಳಿಸಿ & ತ್ಯಾಜ್ಯ ಕಡಿಮೆ ಮಾಡಿ.",
        "Protect Your Food,": "ನಿಮ್ಮ ಆಹಾರವನ್ನು ರಕ್ಷಿಸಿ,",
        "Save Your Money": "ಹಣ ಉಳಿಸಿ",
        "& Cut Waste.": "& ತ್ಯಾಜ್ಯ ಕಡಿಮೆ ಮಾಡಿ.",
        "Start Free Today": "ಇಂದೇ ಉಚಿತವಾಗಿ ಪ್ರಾರಂಭಿಸಿ",
        "Go to Dashboard": "ಡ್ಯಾಶ್‌ಬೋರ್ಡ್‌ಗೆ ಹೋಗಿ",
        "Avg. Food Waste Reduced": "ಸರಾಸರಿ ಆಹಾರ ತ್ಯಾಜ್ಯ ಕಡಿತ",
        "Annual Household Savings": "ವಾರ್ಷಿಕ ಮನೆ ಉಳಿತಾಯ",
        "Dashboard Overview": "ಡ್ಯಾಶ್‌ಬೋರ್ಡ್ ಅವಲೋಕನ",
        "Welcome back": "ಮರಳಿ ಸ್ವಾಗತ",
        "Here is your kitchen inventory status today.": "ಇಂದು ನಿಮ್ಮ ಅಡುಗೆಮನೆ ದಾಸ್ತಾನು ಸ್ಥಿತಿ ಇಲ್ಲಿದೆ.",
        "Active Items": "ಸಕ್ರಿಯ ವಸ್ತುಗಳು",
        "Expiring Soon": "ಶೀಘ್ರದಲ್ಲೇ ಮುಕ್ತಾಯಗೊಳ್ಳಲಿದೆ",
        "Expired Items": "ಮುಕ್ತಾಯಗೊಂಡ ವಸ್ತುಗಳು",
        "Expired": "ಮುಕ್ತಾಯಗೊಂಡಿದೆ",
        "Financial Saved": "ಹಣಕಾಸಿನ ಉಳಿತಾಯ",
        "fresh & safe": "ತಾಜಾ & ಸುರಕ್ಷಿತ",
        "Needs action within": "ಒಳಗೆ ಕ್ರಮ ಅಗತ್ಯವಿದೆ",
        "prevention rate": "ತಡೆಗಟ್ಟುವಿಕೆ ದರ",
        "Items Requiring Immediate Attention": "ತಕ್ಷಣದ ಗಮನ ಅಗತ್ಯವಿರುವ ವಸ್ತುಗಳು",
        "Items Expiring Soon": "ಶೀಘ್ರದಲ್ಲೇ ಮುಕ್ತಾಯಗೊಳ್ಳುವ ವಸ್ತುಗಳು",
        "View All Expiring": "ಎಲ್ಲಾ ಮುಕ್ತಾಯಗೊಳ್ಳುವ ವಸ್ತುಗಳನ್ನು ವೀಕ್ಷಿಸಿ",
        "View All Inventory": "ಪೂರ್ಣ ದಾಸ್ತಾನು ವೀಕ್ಷಿಸಿ",
        "No items expiring soon!": "ಯಾವುದೇ ವಸ್ತುಗಳು ಶೀಘ್ರದಲ್ಲೇ ಮುಕ್ತಾಯಗೊಳ್ಳುತ್ತಿಲ್ಲ!",
        "Waste-Preventing Recipes": "ತ್ಯಾಜ್ಯ ತಡೆಗಟ್ಟುವ ಪಾಕವಿಧಾನಗಳು",
        "Explore All": "ಎಲ್ಲವನ್ನೂ ಅನ್ವೇಷಿಸಿ",
        "Recent Actions Log": "ಇತ್ತೀಚಿನ ಕ್ರಮಗಳ ದಾಖಲೆ",
        "Full History": "ಪೂರ್ಣ ಇತಿಹಾಸ",
        "Add Food Item": "ಆಹಾರ ವಸ್ತುವನ್ನು ಸೇರಿಸಿ",
        "Export CSV": "CSV ರಫ್ತು",
        "Export to CSV": "CSV ಗೆ ರಫ್ತು ಮಾಡಿ",
        "Recipe Ideas": "ಪಾಕವಿಧಾನ ಕಲ್ಪನೆಗಳು",
        "Take / Cook": "ತೆಗೆದುಕೊಳ್ಳಿ / ಅಡುಗೆ ಮಾಡಿ",
        "Cook / Log": "ಅಡುಗೆ ಮಾಡಿ / ದಾಖಲಿಸಿ",
        "Take / Use": "ತೆಗೆದುಕೊಳ್ಳಿ / ಬಳಸಿ",
        "Food Inventory": "ಆಹಾರ ದಾಸ್ತಾನು",
        "Food Inventory Management": "ಆಹಾರ ದಾಸ್ತಾನು ನಿರ್ವಹಣೆ",
        "Track, filter, and prevent food spoilage before expiration dates.": "ಮುಕ್ತಾಯ ದಿನಾಂಕಗಳನ್ನು ಟ್ರ್ಯಾಕ್ ಮಾಡಿ ಮತ್ತು ಹಾಳಾಗುವುದನ್ನು ತಡೆಯಿರಿ.",
        "Add New Item": "ಹೊಸ ವಸ್ತುವನ್ನು ಸೇರಿಸಿ",
        "Search Items": "ವಸ್ತುಗಳನ್ನು ಹುಡುಕಿ",
        "Item or notes...": "ವಸ್ತು ಅಥವಾ ಟಿಪ್ಪಣಿಗಳು...",
        "Search by item name...": "ವಸ್ತುವಿನ ಹೆಸರಿನಿಂದ ಹುಡುಕಿ...",
        "Category": "ವರ್ಗ",
        "All Categories": "ಎಲ್ಲಾ ವರ್ಗಗಳು",
        "Storage Location": "ಶೇಖರಣಾ ಸ್ಥಳ",
        "All Locations": "ಎಲ್ಲಾ ಸ್ಥಳಗಳು",
        "Expiry Status": "ಮುಕ್ತಾಯ ಸ್ಥಿತಿ",
        "All Statuses": "ಎಲ್ಲಾ ಸ್ಥಿತಿಗಳು",
        "Fresh & Safe": "ತಾಜಾ ಮತ್ತು ಸುರಕ್ಷಿತ",
        "Expiring Soon (≤3d)": "ಶೀಘ್ರದಲ್ಲೇ ಮುಕ್ತಾಯ (≤3 ದಿನ)",
        "Apply Filter": "ಫಿಲ್ಟರ್ ಅನ್ವಯಿಸಿ",
        "Reset Filters": "ಫಿಲ್ಟರ್ ಮರುಹೊಂದಿಸಿ",
        "Filter": "ಫಿಲ್ಟರ್",
        "Clear": "ತೆರವುಗೊಳಿಸಿ",
        "No inventory items found": "ಯಾವುದೇ ದಾಸ್ತಾನು ವಸ್ತುಗಳು ಕಂಡುಬಂದಿಲ್ಲ",
        "Add Your First Item": "ನಿಮ್ಮ ಮೊದಲ ವಸ್ತುವನ್ನು ಸೇರಿಸಿ",
        "Item Name": "ವಸ್ತುವಿನ ಹೆಸರು",
        "Qty": "ಪ್ರಮಾಣ",
        "Quantity": "ಪ್ರಮಾಣ",
        "Storage": "ಶೇಖರಣೆ",
        "Expiry Date": "ಮುಕ್ತಾಯ ದಿನಾಂಕ",
        "Expiry Date (DD-MM-YYYY)": "ಮುಕ್ತಾಯ ದಿನಾಂಕ (DD-MM-YYYY)",
        "Status": "ಸ್ಥಿತಿ",
        "Cost": "ವೆಚ್ಚ",
        "Actions": "ಕ್ರಮಗಳು",
        "Action": "ಕ್ರಮ",
        "Edit Item": "ವಸ್ತುವನ್ನು ತಿದ್ದಿ",
        "Delete Item": "ವಸ್ತುವನ್ನು ಅಳಿಸಿ",
        "Edit": "ತಿದ್ದಿ",
        "Delete": "ಅಳಿಸಿ",
        "Log": "ದಾಖಲಿಸಿ",
        "Showing page": "ಪುಟವನ್ನು ತೋರಿಸಲಾಗುತ್ತಿದೆ",
        "total items": "ಒಟ್ಟು ವಸ್ತುಗಳು",
        "Prev": "ಹಿಂದಿನ",
        "Next": "ಮುಂದಿನ",
        "Expires in": "ಮುಕ್ತಾಯಗೊಳ್ಳಲು",
        "days ago": "ದಿನಗಳ ಹಿಂದೆ",
        "days": "ದಿನಗಳು",
        "day": "ದಿನ",
        "Take / Use Stock (Kitchen & Hotel)": "ಸ್ಟಾಕ್ ತೆಗೆದುಕೊಳ್ಳಿ / ಬಳಸಿ (ಅಡುಗೆಮನೆ & ಹೋಟೆಲ್)",
        "Take / Use Stock (Restaurant & Kitchen)": "ಸ್ಟಾಕ್ ತೆಗೆದುಕೊಳ್ಳಿ / ಬಳಸಿ (ರೆಸ್ಟೋರೆಂಟ್ & ಅಡುಗೆಮನೆ)",
        "Restaurant & Hotel Inventory Control • Deduct Partial Quantities (e.g. Half kg)": "ರೆಸ್ಟೋರೆಂಟ್ ದಾಸ್ತಾನು ನಿಯಂತ್ರಣ • ಭಾಗಶಃ ಪ್ರಮಾಣವನ್ನು ಕಳೆಯಿರಿ (ಉದಾ. ಅರ್ಧ ಕೆಜಿ)",
        "Selected Kitchen Item": "ಆಯ್ಕೆಮಾಡಿದ ಅಡುಗೆಮನೆ ವಸ್ತು",
        "Current In Stock": "ಪ್ರಸ್ತುತ ದಾಸ್ತಾನಿನಲ್ಲಿರುವುದು",
        "Value:": "ಮೌಲ್ಯ:",
        "Quarter": "ಕಾಲು ಭಾಗ (25%)",
        "Take Half": "ಅರ್ಧ ತೆಗೆದುಕೊಳ್ಳಿ (50%)",
        "Take Half kg": "ಅರ್ಧ ಕೆಜಿ ತೆಗೆದುಕೊಳ್ಳಿ",
        "Take Half (50%)": "ಅರ್ಧ ತೆಗೆದುಕೊಳ್ಳಿ (50%)",
        "Take All": "ಎಲ್ಲವನ್ನೂ ತೆಗೆದುಕೊಳ್ಳಿ (100%)",
        "Quantity to Take / Deduct *": "ತೆಗೆದುಕೊಳ್ಳಬೇಕಾದ ಪ್ರಮಾಣ *",
        "Stock Change Live Preview": "ದಾಸ್ತಾನು ಬದಲಾವಣೆ ನೇರ ಮುನ್ನೋಟ",
        "Taking Now:": "ಈಗ ತೆಗೆದುಕೊಳ್ಳುತ್ತಿರುವುದು:",
        "Remaining In Stock:": "ಉಳಿದಿರುವ ದಾಸ್ತಾನು:",
        "Cost Impact:": "ವೆಚ್ಚದ ಪ್ರಭಾವ:",
        "Remaining Value:": "ಉಳಿದ ಮೌಲ್ಯ:",
        "will stay available in your kitchen inventory.": "ನಿಮ್ಮ ಅಡುಗೆಮನೆಯ ದಾಸ್ತಾನಿನಲ್ಲಿ ಲಭ್ಯವಿರುತ್ತದೆ.",
        "Cancel": "ರದ್ದುಮಾಡಿ",
        "Take Stock & Update Inventory": "ಸ್ಟಾಕ್ ತೆಗೆದುಕೊಂಡು ದಾಸ್ತಾನು ನವೀಕರಿಸಿ",
        "Confirm & Save": "ದೃಢೀಕರಿಸಿ ಮತ್ತು ಉಳಿಸಿ",
        "Add New Food Item": "ಹೊಸ ಆಹಾರ ವಸ್ತುವನ್ನು ಸೇರಿಸಿ",
        "Edit Food Item": "ಆಹಾರ ವಸ್ತುವನ್ನು ತಿದ್ದಿ",
        "Add to Inventory": "ದಾಸ್ತಾನಿಗೆ ಸೇರಿಸಿ",
        "Update Item": "ವಸ್ತುವನ್ನು ನವೀಕರಿಸಿ",
        "Estimated Cost (₹ INR)": "ಅಂದಾಜು ವೆಚ್ಚ (₹ INR)",
        "Notes": "ಟಿಪ್ಪಣಿಗಳು",
        "Zero-Waste Recipes": "ಶೂನ್ಯ-ತ್ಯಾಜ್ಯ ಪಾಕವಿಧಾನಗಳು",
        "In Stock": "ದಾಸ್ತಾನಿನಲ್ಲಿದೆ",
        "Uses your inventory:": "ನಿಮ್ಮ ದಾಸ್ತಾನು ಬಳಸುತ್ತದೆ:",
        "Cook This": "ಇದನ್ನು ಅಡುಗೆ ಮಾಡಿ",
        "Ingredients": "ಪದಾರ್ಥಗಳು",
        "Instructions": "ಸೂಚನೆಗಳು",
        "Prep Time": "ತಯಾರಿ ಸಮಯ",
        "mins": "ನಿಮಿಷಗಳು",
        "Waste & Impact Analytics": "ತ್ಯಾಜ್ಯ ಮತ್ತು ಪ್ರಭಾವದ ವಿಶ್ಲೇಷಣೆ",
        "Download Audit CSV": "ಆಡಿಟ್ CSV ಡೌನ್‌ಲೋಡ್ ಮಾಡಿ",
        "Value Saved": "ಉಳಿಸಿದ ಮೌಲ್ಯ",
        "Financial Waste": "ಹಣಕಾಸಿನ ತ್ಯಾಜ್ಯ",
        "Prevention Rate": "ತಡೆಗಟ್ಟುವಿಕೆ ದರ",
        "Food Action History": "ಆಹಾರ ಕ್ರಮದ ಇತಿಹಾಸ",
        "Total Value Saved": "ಒಟ್ಟು ಉಳಿಸಿದ ಮೌಲ್ಯ",
        "Financial Loss (Wasted)": "ಹಣಕಾಸಿನ ನಷ್ಟ (ವ್ಯರ್ಥ)",
        "Official Digital Household Identity Card": "ಅಧಿಕೃತ ಡಿಜಿಟಲ್ ಕುಟುಂಬ ಗುರುತಿನ ಚೀಟಿ",
        "Print Official ID Card": "ಗುರುತಿನ ಚೀಟಿಯನ್ನು ಮುದ್ರಿಸಿ",
        "Print ID Card": "ID ಕಾರ್ಡ್ ಮುದ್ರಿಸಿ",
        "Official Full Name": "ಅಧಿಕೃತ ಪೂರ್ಣ ಹೆಸರು",
        "Unique Identity Number (UID)": "ವಿಶಿಷ್ಟ ಗುರುತಿನ ಸಂಖ್ಯೆ (UID)",
        "Designation / Role": "ಹುದ್ದೆ / ಪಾತ್ರ",
        "Registered Email": "ನೋಂದಾಯಿತ ಇಮೇಲ್",
        "Active Kitchen Items": "ಸಕ್ರಿಯ ಅಡುಗೆ ವಸ್ತುಗಳು",
        "Safely Consumed": "ಸುರಕ್ಷಿತವಾಗಿ ಸೇವಿಸಲಾಗಿದೆ",
        "Community Donations": "ಸಮುದಾಯ ದಾನಗಳು",
        "Verified Savings": "ಪರಿಶೀಲಿಸಿದ ಉಳಿತಾಯ",
        "Account Settings": "ಖಾತೆ ಸೆಟ್ಟಿಂಗ್‌ಗಳು",
        "Profile & Expiry Alert Preferences": "ಪ್ರೊಫೈಲ್ & ಮುಕ್ತಾಯ ಎಚ್ಚರಿಕೆ ಆದ್ಯತೆಗಳು",
        "Email Address": "ಇಮೇಲ್ ವಿಳಾಸ",
        "Full Name": "ಪೂರ್ಣ ಹೆಸರು",
        "Save Preferences": "ಆದ್ಯತೆಗಳನ್ನು ಉಳಿಸಿ",
        "Change Password": "ಪಾಸ್‌ವರ್ಡ್ ಬದಲಾಯಿಸಿ",
        "Current Password": "ಪ್ರಸ್ತುತ ಪಾಸ್‌ವರ್ಡ್",
        "New Password": "ಹೊಸ ಪಾಸ್‌ವರ್ಡ್",
        "Confirm New Password": "ಹೊಸ ಪಾಸ್‌ವರ್ಡ್ ದೃಢೀಕರಿಸಿ",
        "Update Password": "ಪಾಸ್‌ವರ್ಡ್ ನವೀಕರಿಸಿ",
        "Log Out of FoodGuard": "FoodGuard ನಿಂದ ಲಾಗ್ ಔಟ್ ಮಾಡಿ",
        "Sign In": "ಸೈನ್ ಇನ್",
        "Welcome Back": "ಮರಳಿ ಸ್ವಾಗತ",
        "Sign in to manage your food inventory": "ನಿಮ್ಮ ದಾಸ್ತಾನು ನಿರ್ವಹಿಸಲು ಸೈನ್ ಇನ್ ಮಾಡಿ",
        "Sign In to FoodGuard": "FoodGuard ಗೆ ಸೈನ್ ಇನ್ ಮಾಡಿ",
        "Instant Demo Login": "ತ್ವರಿತ ಡೆಮೊ ಲಾಗಿನ್",
        "Use Demo Account (Alex Green)": "ಡೆಮೊ ಖಾತೆಯನ್ನು ಬಳಸಿ (Alex Green)",
        "Don't have an account yet?": "ಇನ್ನೂ ಖಾತೆ ಹೊಂದಿಲ್ಲವೇ?",
        "Sign Up": "ಸೈನ್ ಅಪ್ ಮಾಡಿ",
        "Create an Account": "ಖಾತೆಯನ್ನು ರಚಿಸಿ",
        "Already have an account?": "ಈಗಾಗಲೇ ಖಾತೆ ಇದೆಯೇ?",
        "Mark All as Read": "ಎಲ್ಲವನ್ನೂ ಓದಿದಂತೆ ಗುರುತಿಸಿ",
        "No notifications": "ಯಾವುದೇ ಅಧಿಸೂಚನೆಗಳಿಲ್ಲ",
        "You have no alerts at this time.": "ಈ ಸಮಯದಲ್ಲಿ ನಿಮಗೆ ಯಾವುದೇ ಎಚ್ಚರಿಕೆಗಳಿಲ್ಲ.",
        "Quick Navigation": "ತ್ವರಿತ ನ್ಯಾವಿಗೇಷನ್",
        "System Info": "ಸಿಸ್ಟಮ್ ಮಾಹಿತಿ",
        "All rights reserved.": "ಎಲ್ಲಾ ಹಕ್ಕುಗಳನ್ನು ಕಾಯ್ದಿರಿಸಲಾಗಿದೆ.",
        "Fruits & Vegetables": "ಹಣ್ಣುಗಳು ಮತ್ತು ತರಕಾರಿಗಳು",
        "Dairy & Eggs": "ಡೈರಿ ಮತ್ತು ಮೊಟ್ಟೆಗಳು",
        "Meat & Poultry": "ಮಾಂಸ ಮತ್ತು ಕೋಳಿ",
        "Fish & Seafood": "ಮೀನು ಮತ್ತು ಸಮುದ್ರಾಹಾರ",
        "Bakery & Bread": "ಬೇಕರಿ ಮತ್ತು ಬ್ರೆಡ್",
        "Grains, Pasta & Rice": "ಧಾನ್ಯಗಳು ಮತ್ತು ಅಕ್ಕಿ",
        "Canned & Preserved": "ಡಬ್ಬಿಯಲ್ಲಿಟ್ಟ ಆಹಾರ",
        "Condiments & Sauces": "ಮಸಾಲೆಗಳು ಮತ್ತು ಸಾಸ್‌ಗಳು",
        "Beverages": "ಪಾನೀಯಗಳು",
        "Snacks & Sweets": "ತಿಂಡಿಗಳು ಮತ್ತು ಸಿಹಿತಿಂಡಿಗಳು",
        "Frozen Foods": "ಘನೀಕೃತ ಆಹಾರಗಳು",
        "Other": "ಇತರೆ",
        "Refrigerator": "ರೆಫ್ರಿಜರೇಟರ್ (ಫ್ರಿಜ್)",
        "Fridge": "ಫ್ರಿಜ್",
        "Freezer": "ಫ್ರೀಜರ್",
        "Pantry": "ಪ್ಯಾಂಟ್ರಿ",
        "Countertop": "ಕೌಂಟರ್‌ಟಾಪ್"
    },
    es: {
        "FoodGuard": "FoodGuard",
        "Dashboard": "Panel",
        "Inventory": "Inventario",
        "History": "Historial",
        "Recipes": "Recetas",
        "Analytics": "Analítica",
        "Notifications": "Notificaciones",
        "Alerts & Notices": "Alertas y Avisos",
        "Alerts & Notifications": "Alertas y Notificaciones",
        "Login": "Iniciar sesión",
        "Register": "Registrarse",
        "Logout": "Cerrar sesión",
        "Sign Out": "Cerrar sesión",
        "Account": "Cuenta",
        "My Inventory": "Mi inventario",
        "Official Analytics": "Analítica oficial",
        "Official Profile & ID": "Perfil e ID oficial",
        "Verified Official Account": "Cuenta oficial verificada",
        "Sign In to Your Account": "Inicie sesión en su cuenta",
        "Create a Free Account": "Crear una cuenta gratis",
        "Select Language": "Seleccionar idioma",
        "Smart Kitchen Waste Prevention": "Prevención inteligente de residuos de cocina",
        "Protect Your Food, Save Your Money & Cut Waste.": "Proteja su comida, ahorre dinero y reduzca residuos.",
        "Protect Your Food,": "Proteja su comida,",
        "Save Your Money": "ahorre dinero",
        "& Cut Waste.": "y reduzca residuos.",
        "Start Free Today": "Comience gratis hoy",
        "Go to Dashboard": "Ir al panel",
        "Avg. Food Waste Reduced": "Desperdicio de comida reducido",
        "Annual Household Savings": "Ahorro anual del hogar",
        "Dashboard Overview": "Resumen del panel",
        "Welcome back": "Bienvenido de nuevo",
        "Here is your kitchen inventory status today.": "Este es el estado de su inventario hoy.",
        "Active Items": "Artículos activos",
        "Expiring Soon": "Próximo a caducar",
        "Expired Items": "Artículos caducados",
        "Expired": "Caducado",
        "Financial Saved": "Ahorro financiero",
        "fresh & safe": "fresco y seguro",
        "Needs action within": "Acción requerida en",
        "prevention rate": "tasa de prevención",
        "Items Requiring Immediate Attention": "Artículos que requieren atención",
        "Items Expiring Soon": "Artículos por caducar",
        "View All Expiring": "Ver todos por caducar",
        "View All Inventory": "Ver todo el inventario",
        "No items expiring soon!": "¡No hay artículos por caducar!",
        "Waste-Preventing Recipes": "Recetas para evitar desperdicio",
        "Explore All": "Explorar todo",
        "Recent Actions Log": "Registro de acciones recientes",
        "Full History": "Historial completo",
        "Add Food Item": "Agregar alimento",
        "Export CSV": "Exportar CSV",
        "Export to CSV": "Exportar a CSV",
        "Recipe Ideas": "Ideas de recetas",
        "Take / Cook": "Tomar / Cocinar",
        "Cook / Log": "Cocinar / Registrar",
        "Take / Use": "Tomar / Usar",
        "Food Inventory": "Inventario de alimentos",
        "Food Inventory Management": "Gestión de inventario de alimentos",
        "Track, filter, and prevent food spoilage before expiration dates.": "Controle y evite que la comida se eche a perder.",
        "Add New Item": "Agregar nuevo artículo",
        "Search Items": "Buscar artículos",
        "Item or notes...": "Artículo o notas...",
        "Search by item name...": "Buscar por nombre...",
        "Category": "Categoría",
        "All Categories": "Todas las categorías",
        "Storage Location": "Ubicación de almacenamiento",
        "All Locations": "Todas las ubicaciones",
        "Expiry Status": "Estado de caducidad",
        "All Statuses": "Todos los estados",
        "Fresh & Safe": "Fresco y seguro",
        "Expiring Soon (≤3d)": "Próximo a caducar (≤3d)",
        "Apply Filter": "Aplicar filtro",
        "Reset Filters": "Restablecer filtros",
        "Filter": "Filtrar",
        "Clear": "Limpiar",
        "No inventory items found": "No se encontraron alimentos",
        "Add Your First Item": "Agregue su primer artículo",
        "Item Name": "Nombre del artículo",
        "Qty": "Cant.",
        "Quantity": "Cantidad",
        "Storage": "Almacén",
        "Expiry Date": "Fecha de caducidad",
        "Expiry Date (DD-MM-YYYY)": "Fecha de caducidad (DD-MM-YYYY)",
        "Status": "Estado",
        "Cost": "Costo",
        "Actions": "Acciones",
        "Action": "Acción",
        "Edit Item": "Editar artículo",
        "Delete Item": "Eliminar artículo",
        "Edit": "Editar",
        "Delete": "Eliminar",
        "Log": "Registrar",
        "Showing page": "Mostrando página",
        "total items": "artículos totales",
        "Prev": "Anterior",
        "Next": "Siguiente",
        "Expires in": "Caduca en",
        "days ago": "días atrás",
        "days": "días",
        "day": "día",
        "Take / Use Stock (Kitchen & Hotel)": "Tomar / Usar stock (Cocina y Hotel)",
        "Take / Use Stock (Restaurant & Kitchen)": "Tomar / Usar stock (Restaurante y Cocina)",
        "Restaurant & Hotel Inventory Control • Deduct Partial Quantities (e.g. Half kg)": "Control de restaurante • Deducir cantidades parciales (ej. Medio kg)",
        "Selected Kitchen Item": "Alimento seleccionado",
        "Current In Stock": "Actualmente en stock",
        "Value:": "Valor:",
        "Quarter": "Un cuarto (25%)",
        "Take Half": "Tomar la mitad (50%)",
        "Take Half kg": "Tomar medio kg",
        "Take Half (50%)": "Tomar la mitad (50%)",
        "Take All": "Tomar todo (100%)",
        "Quantity to Take / Deduct *": "Cantidad a tomar / deducir *",
        "Stock Change Live Preview": "Vista previa de stock en vivo",
        "Taking Now:": "Tomando ahora:",
        "Remaining In Stock:": "Restante en stock:",
        "Cost Impact:": "Impacto de costo:",
        "Remaining Value:": "Valor restante:",
        "will stay available in your kitchen inventory.": "permanecerá disponible en su cocina.",
        "Cancel": "Cancelar",
        "Take Stock & Update Inventory": "Tomar stock y actualizar inventario",
        "Confirm & Save": "Confirmar y guardar",
        "Add New Food Item": "Agregar nuevo alimento",
        "Edit Food Item": "Editar alimento",
        "Add to Inventory": "Agregar al inventario",
        "Update Item": "Actualizar artículo",
        "Estimated Cost (₹ INR)": "Costo estimado (₹ INR)",
        "Notes": "Notas",
        "Zero-Waste Recipes": "Recetas sin desperdicio",
        "In Stock": "En stock",
        "Uses your inventory:": "Usa su inventario:",
        "Cook This": "Cocinar esto",
        "Ingredients": "Ingredientes",
        "Instructions": "Instrucciones",
        "Prep Time": "Tiempo de preparación",
        "mins": "min",
        "Waste & Impact Analytics": "Analítica de desperdicio e impacto",
        "Download Audit CSV": "Descargar CSV de auditoría",
        "Value Saved": "Valor ahorrado",
        "Financial Waste": "Desperdicio financiero",
        "Prevention Rate": "Tasa de prevención",
        "Food Action History": "Historial de acciones",
        "Total Value Saved": "Valor total ahorrado",
        "Financial Loss (Wasted)": "Pérdida financiera",
        "Official Digital Household Identity Card": "Tarjeta oficial de identidad digital",
        "Print Official ID Card": "Imprimir tarjeta de ID",
        "Print ID Card": "Imprimir ID",
        "Official Full Name": "Nombre completo oficial",
        "Unique Identity Number (UID)": "Número de identidad único (UID)",
        "Designation / Role": "Designación / Rol",
        "Registered Email": "Correo registrado",
        "Active Kitchen Items": "Artículos activos",
        "Safely Consumed": "Consumido con seguridad",
        "Community Donations": "Donaciones comunitarias",
        "Verified Savings": "Ahorros verificados",
        "Account Settings": "Configuración de la cuenta",
        "Profile & Expiry Alert Preferences": "Perfil y alertas de caducidad",
        "Email Address": "Correo electrónico",
        "Full Name": "Nombre completo",
        "Save Preferences": "Guardar preferencias",
        "Change Password": "Cambiar contraseña",
        "Current Password": "Contraseña actual",
        "New Password": "Nueva contraseña",
        "Confirm New Password": "Confirmar nueva contraseña",
        "Update Password": "Actualizar contraseña",
        "Log Out of FoodGuard": "Cerrar sesión en FoodGuard",
        "Sign In": "Iniciar sesión",
        "Welcome Back": "Bienvenido de nuevo",
        "Sign in to manage your food inventory": "Inicie sesión para gestionar su comida",
        "Sign In to FoodGuard": "Iniciar sesión en FoodGuard",
        "Instant Demo Login": "Inicio rápido de demo",
        "Use Demo Account (Alex Green)": "Usar cuenta de demo (Alex Green)",
        "Don't have an account yet?": "¿Aún no tiene una cuenta?",
        "Sign Up": "Registrarse",
        "Create an Account": "Crear una cuenta",
        "Already have an account?": "¿Ya tiene una cuenta?",
        "Mark All as Read": "Marcar todo como leído",
        "No notifications": "No hay notificaciones",
        "You have no alerts at this time.": "No tiene alertas en este momento.",
        "Quick Navigation": "Navegación rápida",
        "System Info": "Información del sistema",
        "All rights reserved.": "Todos los derechos reservados.",
        "Fruits & Vegetables": "Frutas y verduras",
        "Dairy & Eggs": "Lácteos y huevos",
        "Meat & Poultry": "Carne y aves",
        "Fish & Seafood": "Pescado y mariscos",
        "Bakery & Bread": "Panadería y pan",
        "Grains, Pasta & Rice": "Granos, pasta y arroz",
        "Canned & Preserved": "Enlatados y conservas",
        "Condiments & Sauces": "Condimentos y salsas",
        "Beverages": "Bebidas",
        "Snacks & Sweets": "Snacks y dulces",
        "Frozen Foods": "Alimentos congelados",
        "Other": "Otro",
        "Refrigerator": "Refrigerador",
        "Fridge": "Nevera",
        "Freezer": "Congelador",
        "Pantry": "Despensa",
        "Countertop": "Encimera"
    },
    fr: {
        "FoodGuard": "FoodGuard",
        "Dashboard": "Tableau de bord",
        "Inventory": "Inventaire",
        "History": "Historique",
        "Recipes": "Recettes",
        "Analytics": "Analytique",
        "Notifications": "Notifications",
        "Alerts & Notices": "Alertes et avis",
        "Alerts & Notifications": "Alertes et notifications",
        "Login": "Connexion",
        "Register": "S'inscrire",
        "Logout": "Déconnexion",
        "Sign Out": "Déconnexion",
        "Account": "Compte",
        "My Inventory": "Mon inventaire",
        "Official Analytics": "Analytique officielle",
        "Official Profile & ID": "Profil et ID officiel",
        "Verified Official Account": "Compte officiel vérifié",
        "Sign In to Your Account": "Connectez-vous à votre compte",
        "Create a Free Account": "Créer un compte gratuit",
        "Select Language": "Choisir la langue",
        "Smart Kitchen Waste Prevention": "Prévention intelligente du gaspillage alimentaire",
        "Protect Your Food, Save Your Money & Cut Waste.": "Protégez vos aliments, économisez et réduisez le gaspillage.",
        "Protect Your Food,": "Protégez vos aliments,",
        "Save Your Money": "économisez de l'argent",
        "& Cut Waste.": "et réduisez le gaspillage.",
        "Start Free Today": "Commencez gratuitement aujourd'hui",
        "Go to Dashboard": "Aller au tableau de bord",
        "Avg. Food Waste Reduced": "Réduction moy. du gaspillage",
        "Annual Household Savings": "Économies annuelles du foyer",
        "Dashboard Overview": "Vue d'ensemble du tableau de bord",
        "Welcome back": "Bienvenue",
        "Here is your kitchen inventory status today.": "Voici l'état de votre inventaire aujourd'hui.",
        "Active Items": "Articles actifs",
        "Expiring Soon": "Expire bientôt",
        "Expired Items": "Articles expirés",
        "Expired": "Expiré",
        "Financial Saved": "Économies financières",
        "fresh & safe": "frais et sûr",
        "Needs action within": "Action requise sous",
        "prevention rate": "taux de prévention",
        "Items Requiring Immediate Attention": "Articles nécessitant une attention urgente",
        "Items Expiring Soon": "Articles expirant bientôt",
        "View All Expiring": "Voir tous les expirants",
        "View All Inventory": "Voir tout l'inventaire",
        "No items expiring soon!": "Aucun article n'expire bientôt !",
        "Waste-Preventing Recipes": "Recettes anti-gaspillage",
        "Explore All": "Tout explorer",
        "Recent Actions Log": "Journal des actions récentes",
        "Full History": "Historique complet",
        "Add Food Item": "Ajouter un aliment",
        "Export CSV": "Exporter CSV",
        "Export to CSV": "Exporter en CSV",
        "Recipe Ideas": "Idées de recettes",
        "Take / Cook": "Prendre / Cuisiner",
        "Cook / Log": "Cuisiner / Enregistrer",
        "Take / Use": "Prendre / Utiliser",
        "Food Inventory": "Inventaire alimentaire",
        "Food Inventory Management": "Gestion des stocks alimentaires",
        "Track, filter, and prevent food spoilage before expiration dates.": "Suivez et évitez le gaspillage avant les dates d'expiration.",
        "Add New Item": "Ajouter un nouvel article",
        "Search Items": "Rechercher des articles",
        "Item or notes...": "Article ou notes...",
        "Search by item name...": "Recherche par nom...",
        "Category": "Catégorie",
        "All Categories": "Toutes les catégories",
        "Storage Location": "Emplacement de stockage",
        "All Locations": "Tous les emplacements",
        "Expiry Status": "Statut d'expiration",
        "All Statuses": "Tous les statuts",
        "Fresh & Safe": "Frais et sûr",
        "Expiring Soon (≤3d)": "Expire bientôt (≤3j)",
        "Apply Filter": "Appliquer le filtre",
        "Reset Filters": "Réinitialiser",
        "Filter": "Filtrer",
        "Clear": "Effacer",
        "No inventory items found": "Aucun aliment trouvé",
        "Add Your First Item": "Ajoutez votre premier aliment",
        "Item Name": "Nom de l'article",
        "Qty": "Qté",
        "Quantity": "Quantité",
        "Storage": "Stockage",
        "Expiry Date": "Date d'expiration",
        "Expiry Date (DD-MM-YYYY)": "Date d'expiration (DD-MM-YYYY)",
        "Status": "Statut",
        "Cost": "Coût",
        "Actions": "Actions",
        "Action": "Action",
        "Edit Item": "Modifier l'article",
        "Delete Item": "Supprimer l'article",
        "Edit": "Modifier",
        "Delete": "Supprimer",
        "Log": "Enregistrer",
        "Showing page": "Affichage de la page",
        "total items": "articles au total",
        "Prev": "Précédent",
        "Next": "Suivant",
        "Expires in": "Expire dans",
        "days ago": "jours plus tôt",
        "days": "jours",
        "day": "jour",
        "Take / Use Stock (Kitchen & Hotel)": "Prendre / Utiliser le stock (Cuisine & Hôtel)",
        "Take / Use Stock (Restaurant & Kitchen)": "Prendre / Utiliser le stock (Restaurant & Cuisine)",
        "Restaurant & Hotel Inventory Control • Deduct Partial Quantities (e.g. Half kg)": "Contrôle du stock • Déduire des portions partielles (ex. Demi-kg)",
        "Selected Kitchen Item": "Aliment sélectionné",
        "Current In Stock": "Actuellement en stock",
        "Value:": "Valeur :",
        "Quarter": "Un quart (25%)",
        "Take Half": "Prendre la moitié (50%)",
        "Take Half kg": "Prendre un demi-kg",
        "Take Half (50%)": "Prendre la moitié (50%)",
        "Take All": "Tout prendre (100%)",
        "Quantity to Take / Deduct *": "Quantité à prélever *",
        "Stock Change Live Preview": "Aperçu en direct du changement de stock",
        "Taking Now:": "Prélèvement :",
        "Remaining In Stock:": "Restant en stock :",
        "Cost Impact:": "Impact financier :",
        "Remaining Value:": "Valeur restante :",
        "will stay available in your kitchen inventory.": "restera disponible dans votre cuisine.",
        "Cancel": "Annuler",
        "Take Stock & Update Inventory": "Prélever et mettre à jour le stock",
        "Confirm & Save": "Confirmer et enregistrer",
        "Add New Food Item": "Ajouter un aliment",
        "Edit Food Item": "Modifier l'aliment",
        "Add to Inventory": "Ajouter à l'inventaire",
        "Update Item": "Mettre à jour",
        "Estimated Cost (₹ INR)": "Coût estimé (₹ INR)",
        "Notes": "Notes",
        "Zero-Waste Recipes": "Recettes anti-gaspillage",
        "In Stock": "En stock",
        "Uses your inventory:": "Utilise vos stocks :",
        "Cook This": "Cuisiner ceci",
        "Ingredients": "Ingrédients",
        "Instructions": "Instructions",
        "Prep Time": "Temps de préparation",
        "mins": "min",
        "Waste & Impact Analytics": "Analytique du gaspillage et de l'impact",
        "Download Audit CSV": "Télécharger le CSV d'audit",
        "Value Saved": "Valeur sauvée",
        "Financial Waste": "Gaspillage financier",
        "Prevention Rate": "Taux de prévention",
        "Food Action History": "Historique des actions",
        "Total Value Saved": "Valeur totale sauvée",
        "Financial Loss (Wasted)": "Perte financière (Gaspillage)",
        "Official Digital Household Identity Card": "Carte d'identité numérique officielle du foyer",
        "Print Official ID Card": "Imprimer la carte d'identité",
        "Print ID Card": "Imprimer l'ID",
        "Official Full Name": "Nom officiel complet",
        "Unique Identity Number (UID)": "Numéro d'identité unique (UID)",
        "Designation / Role": "Désignation / Rôle",
        "Registered Email": "E-mail enregistré",
        "Active Kitchen Items": "Aliments actifs",
        "Safely Consumed": "Consommé en toute sécurité",
        "Community Donations": "Dons à la communauté",
        "Verified Savings": "Économies vérifiées",
        "Account Settings": "Paramètres du compte",
        "Profile & Expiry Alert Preferences": "Préférences d'alerte et de profil",
        "Email Address": "Adresse e-mail",
        "Full Name": "Nom complet",
        "Save Preferences": "Enregistrer les préférences",
        "Change Password": "Changer le mot de passe",
        "Current Password": "Mot de passe actuel",
        "New Password": "Nouveau mot de passe",
        "Confirm New Password": "Confirmer le nouveau mot de passe",
        "Update Password": "Mettre à jour le mot de passe",
        "Log Out of FoodGuard": "Se déconnecter de FoodGuard",
        "Sign In": "Connexion",
        "Welcome Back": "Bienvenue",
        "Sign in to manage your food inventory": "Connectez-vous pour gérer vos stocks",
        "Sign In to FoodGuard": "Se connecter à FoodGuard",
        "Instant Demo Login": "Connexion démo instantanée",
        "Use Demo Account (Alex Green)": "Utiliser le compte démo (Alex Green)",
        "Don't have an account yet?": "Pas encore de compte ?",
        "Sign Up": "S'inscrire",
        "Create an Account": "Créer un compte",
        "Already have an account?": "Vous avez déjà un compte ?",
        "Mark All as Read": "Tout marquer comme lu",
        "No notifications": "Aucune notification",
        "You have no alerts at this time.": "Vous n'avez aucune alerte actuellement.",
        "Quick Navigation": "Navigation rapide",
        "System Info": "Infos système",
        "All rights reserved.": "Tous droits réservés.",
        "Fruits & Vegetables": "Fruits et légumes",
        "Dairy & Eggs": "Produits laitiers et œufs",
        "Meat & Poultry": "Viande et volaille",
        "Fish & Seafood": "Poissons et fruits de mer",
        "Bakery & Bread": "Boulangerie et pain",
        "Grains, Pasta & Rice": "Céréales, pâtes et riz",
        "Canned & Preserved": "Conserves et bocaux",
        "Condiments & Sauces": "Condiments et sauces",
        "Beverages": "Boissons",
        "Snacks & Sweets": "Snacks et douceurs",
        "Frozen Foods": "Surgelés",
        "Other": "Autre",
        "Refrigerator": "Réfrigérateur",
        "Fridge": "Frigo",
        "Freezer": "Congélateur",
        "Pantry": "Garde-manger",
        "Countertop": "Plan de travail"
    }
};

/**
 * Initialize Language Selector across all web pages and templates
 */
function initLanguageSelector() {
    const savedLang = localStorage.getItem('foodguard_lang') || getCookie('foodguard_lang') || 'en';
    const select = document.getElementById('languageSelect');
    if (select) {
        select.value = savedLang;
    }
    if (savedLang && savedLang !== 'en') {
        applyLanguage(savedLang);
    }
    initTranslationObserver();
}

/**
 * Switch global application language and persist across all routes
 */
function changeFoodGuardLanguage(lang) {
    if (!lang) lang = 'en';
    localStorage.setItem('foodguard_lang', lang);
    document.cookie = `foodguard_lang=${lang};path=/;max-age=31536000`;
    
    // Set Google Translate cookie
    const transVal = (lang === 'en') ? '/en/en' : `/en/${lang}`;
    document.cookie = `googtrans=${transVal};path=/;max-age=31536000`;
    try {
        document.cookie = `googtrans=${transVal};path=/;domain=${window.location.hostname};max-age=31536000`;
    } catch(e) {}

    const select = document.getElementById('languageSelect');
    if (select) select.value = lang;
    
    applyLanguage(lang);
}

function getCookie(name) {
    const v = document.cookie.match('(^|;) ?' + name + '=([^;]*)(;|$)');
    return v ? v[2] : null;
}

/**
 * Restore original English content before reapplying translations
 */
function restoreEnglishText() {
    const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT, null, false);
    let node;
    while ((node = walker.nextNode())) {
        if (node._origText !== undefined) {
            node.nodeValue = node._origText;
        }
    }
    document.querySelectorAll('input[placeholder], textarea[placeholder]').forEach(el => {
        if (el._origPh !== undefined) el.setAttribute('placeholder', el._origPh);
    });
    document.querySelectorAll('[title]').forEach(el => {
        if (el._origTitle !== undefined) el.setAttribute('title', el._origTitle);
    });
    document.querySelectorAll('input[type="submit"], input[type="button"]').forEach(el => {
        if (el._origVal !== undefined) el.value = el._origVal;
    });
}

/**
 * Apply selected language translation to whole website
 */
function applyLanguage(lang) {
    restoreEnglishText();
    
    // Synchronize headless Google Translate
    syncGoogleTranslate(lang);

    if (!lang || lang === 'en') {
        return;
    }

    const dict = FOODGUARD_TRANSLATIONS[lang];
    if (!dict) return;

    // Sort phrases by descending character length to ensure longest sentences match first
    const sortedKeys = Object.keys(dict).sort((a, b) => b.length - a.length);

    // 1. Walk DOM text nodes
    const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT, null, false);
    let node;
    while ((node = walker.nextNode())) {
        const parent = node.parentElement;
        if (!parent) continue;
        
        const tagName = parent.tagName ? parent.tagName.toLowerCase() : '';
        if (tagName === 'script' || tagName === 'style' || tagName === 'noscript' || 
            tagName === 'svg' || tagName === 'code' || tagName === 'pre') {
            continue;
        }
        if (parent.closest('#languageSelect') || parent.closest('.notranslate') || parent.closest('#google_translate_element')) {
            continue;
        }

        const raw = node.nodeValue;
        if (!raw || !raw.trim()) continue;

        if (node._origText === undefined) {
            node._origText = raw;
        }

        let current = node._origText;
        const trimmed = current.trim();

        // Exact match
        if (dict[trimmed]) {
            node.nodeValue = current.replace(trimmed, dict[trimmed]);
            continue;
        }

        // Substring / phrase multi-word match
        let modified = current;
        for (let i = 0; i < sortedKeys.length; i++) {
            const key = sortedKeys[i];
            if (key.length < 2) continue;
            if (modified.indexOf(key) !== -1) {
                modified = modified.split(key).join(dict[key]);
            }
        }
        if (modified !== current) {
            node.nodeValue = modified;
        }
    }

    // 2. Placeholders in input and textarea
    document.querySelectorAll('input[placeholder], textarea[placeholder]').forEach(el => {
        const ph = el.getAttribute('placeholder');
        if (ph) {
            if (el._origPh === undefined) el._origPh = ph;
            let val = el._origPh;
            if (dict[val.trim()]) {
                el.setAttribute('placeholder', dict[val.trim()]);
            } else {
                for (let i = 0; i < sortedKeys.length; i++) {
                    const key = sortedKeys[i];
                    if (val.indexOf(key) !== -1) {
                        val = val.split(key).join(dict[key]);
                    }
                }
                el.setAttribute('placeholder', val);
            }
        }
    });

    // 3. Titles and tooltips
    document.querySelectorAll('[title]').forEach(el => {
        if (el.id === 'languageSelect' || el.closest('#languageSelect')) return;
        const t = el.getAttribute('title');
        if (t) {
            if (el._origTitle === undefined) el._origTitle = t;
            let val = el._origTitle;
            if (dict[val.trim()]) {
                el.setAttribute('title', dict[val.trim()]);
            } else {
                for (let i = 0; i < sortedKeys.length; i++) {
                    const key = sortedKeys[i];
                    if (val.indexOf(key) !== -1) {
                        val = val.split(key).join(dict[key]);
                    }
                }
                el.setAttribute('title', val);
            }
        }
    });

    // 4. Form buttons
    document.querySelectorAll('input[type="submit"], input[type="button"]').forEach(el => {
        const val = el.value;
        if (val) {
            if (el._origVal === undefined) el._origVal = val;
            if (dict[el._origVal]) {
                el.value = dict[el._origVal];
            }
        }
    });
}

/**
 * Headless Google Website Translator Synchronizer
 */
function syncGoogleTranslate(lang) {
    function triggerCombo() {
        const combo = document.querySelector('.goog-te-combo');
        if (combo) {
            if (combo.value !== lang) {
                combo.value = (lang === 'en') ? '' : lang;
                combo.dispatchEvent(new Event('change'));
            }
            return true;
        }
        return false;
    }

    if (!triggerCombo()) {
        let attempts = 0;
        const poll = setInterval(() => {
            attempts++;
            if (triggerCombo() || attempts > 10) {
                clearInterval(poll);
            }
        }, 200);
    }
}

/**
 * Live DOM MutationObserver to ensure dynamically injected elements
 * (modals, restaurant stock portions, notifications) are auto-translated
 */
let _observerActive = false;
function initTranslationObserver() {
    if (_observerActive) return;
    _observerActive = true;

    const observer = new MutationObserver((mutations) => {
        const savedLang = localStorage.getItem('foodguard_lang') || getCookie('foodguard_lang') || 'en';
        if (savedLang === 'en') return;

        let hasNew = false;
        for (const m of mutations) {
            if (m.addedNodes.length > 0) {
                for (const node of m.addedNodes) {
                    if (node.nodeType === 1 && 
                        !node.classList?.contains('goog-te-banner-frame') && 
                        !node.classList?.contains('skiptranslate') &&
                        !node.closest?.('#languageSelect')) {
                        hasNew = true;
                        break;
                    }
                }
            }
            if (hasNew) break;
        }

        if (hasNew) {
            clearTimeout(window._transTimer);
            window._transTimer = setTimeout(() => {
                applyLanguage(savedLang);
            }, 60);
        }
    });

    observer.observe(document.body, { childList: true, subtree: true });
}
