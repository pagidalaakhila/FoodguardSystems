/**
 * FoodGuard - Analytics & Visual Dashboards powered by Chart.js
 */

document.addEventListener('DOMContentLoaded', () => {
    initAnalyticsCharts();
});

function initAnalyticsCharts() {
    const monthlyCanvas = document.getElementById('monthlyTrendChart');
    const categoryCanvas = document.getElementById('categoryDoughnutChart');
    const storageCanvas = document.getElementById('storageBarChart');
    const financialCanvas = document.getElementById('financialChart');

    if (!monthlyCanvas && !categoryCanvas && !storageCanvas && !financialCanvas) {
        return;
    }

    // Fetch live aggregated data from API endpoint
    fetch('/api/analytics/data')
        .then(res => res.json())
        .then(data => {
            if (monthlyCanvas) renderMonthlyTrend(monthlyCanvas, data);
            if (categoryCanvas) renderCategoryChart(categoryCanvas, data);
            if (storageCanvas) renderStorageChart(storageCanvas, data);
            if (financialCanvas) renderFinancialChart(financialCanvas, data);
        })
        .catch(err => {
            console.error('Failed to load chart analytics data:', err);
        });
}

function renderMonthlyTrend(canvas, data) {
    new Chart(canvas, {
        type: 'bar',
        data: {
            labels: data.monthlyLabels || [],
            datasets: [
                {
                    label: 'Consumed (Saved)',
                    data: data.monthlyConsumed || [],
                    backgroundColor: '#40916c',
                    borderRadius: 6,
                    borderSkipped: false
                },
                {
                    label: 'Donated (Community)',
                    data: data.monthlyDonated || [],
                    backgroundColor: '#6366f1',
                    borderRadius: 6,
                    borderSkipped: false
                },
                {
                    label: 'Wasted (Spoiled)',
                    data: data.monthlyWasted || [],
                    backgroundColor: '#ef4444',
                    borderRadius: 6,
                    borderSkipped: false
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'top',
                    labels: {
                        boxWidth: 14,
                        font: { family: 'Inter', weight: 600 }
                    }
                },
                tooltip: {
                    padding: 10,
                    cornerRadius: 8
                }
            },
            scales: {
                x: {
                    grid: { display: false }
                },
                y: {
                    beginAtZero: true,
                    ticks: { precision: 0 },
                    grid: { color: '#f1f5f9' }
                }
            }
        }
    });
}

function renderCategoryChart(canvas, data) {
    const colors = [
        '#10B981', '#F59E0B', '#EF4444', '#D97706',
        '#8B5CF6', '#06B6D4', '#3B82F6', '#64748B'
    ];

    new Chart(canvas, {
        type: 'doughnut',
        data: {
            labels: data.categoryLabels || [],
            datasets: [{
                data: data.categoryCounts || [],
                backgroundColor: colors,
                borderWidth: 2,
                borderColor: '#ffffff'
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'right',
                    labels: {
                        boxWidth: 12,
                        font: { family: 'Inter', size: 12 }
                    }
                }
            },
            cutout: '70%'
        }
    });
}

function renderStorageChart(canvas, data) {
    new Chart(canvas, {
        type: 'bar',
        data: {
            labels: data.storageLabels || [],
            datasets: [{
                label: 'Items Stored',
                data: data.storageCounts || [],
                backgroundColor: '#2d6a4f',
                borderRadius: 6
            }]
        },
        options: {
            indexAxis: 'y',
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { display: false }
            },
            scales: {
                x: {
                    beginAtZero: true,
                    ticks: { precision: 0 },
                    grid: { color: '#f1f5f9' }
                },
                y: {
                    grid: { display: false }
                }
            }
        }
    });
}

function renderFinancialChart(canvas, data) {
    const saved = data.totalMoneySaved || 0;
    const lost = data.totalMoneyLost || 0;

    new Chart(canvas, {
        type: 'bar',
        data: {
            labels: ['Money Saved (Consumed/Donated)', 'Financial Loss (Wasted)'],
            datasets: [{
                data: [saved, lost],
                backgroundColor: ['#2d6a4f', '#ef4444'],
                borderRadius: 8
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { display: false },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            return ' ₹' + Number(context.raw).toFixed(2);
                        }
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        callback: function(val) {
                            return '₹' + val;
                        }
                    },
                    grid: { color: '#f1f5f9' }
                },
                x: {
                    grid: { display: false }
                }
            }
        }
    });
}
