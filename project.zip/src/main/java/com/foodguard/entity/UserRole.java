package com.foodguard.entity;

public enum UserRole {
    ROLE_ADMIN("Admin / General Manager", "badge-primary", "Full administrative access, user permissions, and configuration"),
    ROLE_RESTAURANT_MANAGER("Restaurant Manager", "badge-success", "Full food operations, approvals, analytics, and donations"),
    ROLE_KITCHEN_STAFF("Kitchen Staff", "badge-info", "Daily food prep logging, stock tracking, and waste recording");

    private final String displayName;
    private final String badgeClass;
    private final String description;

    UserRole(String displayName, String badgeClass, String description) {
        this.displayName = displayName;
        this.badgeClass = badgeClass;
        this.description = description;
    }

    public String getDisplayName() {
        return displayName;
    }

    public String getBadgeClass() {
        return badgeClass;
    }

    public String getDescription() {
        return description;
    }
}
