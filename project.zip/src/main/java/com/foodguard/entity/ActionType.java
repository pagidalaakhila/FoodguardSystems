package com.foodguard.entity;

public enum ActionType {
    PURCHASED("Purchased / Received", "fas fa-cart-plus", "#3B82F6", "Stock purchased and stored in restaurant inventory"),
    PREPARED("Prepared in Kitchen", "fas fa-utensils", "#8B5CF6", "Dish prepared in kitchen batch production"),
    CONSUMED("Sold / Served", "fas fa-concierge-bell", "#10B981", "Portions consumed or sold to diners"),
    DONATED("Donated", "fas fa-hand-holding-heart", "#F59E0B", "Safe surplus donated to registered orphanages / shelters"),
    WASTED("Wasted / Discarded", "fas fa-trash-alt", "#EF4444", "Unusable food discarded with recorded waste reason");

    private final String displayName;
    private final String iconClass;
    private final String colorCode;
    private final String description;

    ActionType(String displayName, String iconClass, String colorCode, String description) {
        this.displayName = displayName;
        this.iconClass = iconClass;
        this.colorCode = colorCode;
        this.description = description;
    }

    public String getDisplayName() {
        return displayName;
    }

    public String getIconClass() {
        return iconClass;
    }

    public String getColorCode() {
        return colorCode;
    }

    public String getDescription() {
        return description;
    }
}
