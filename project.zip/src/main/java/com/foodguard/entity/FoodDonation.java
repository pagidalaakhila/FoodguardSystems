package com.foodguard.entity;

import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

@Entity
@Table(name = "food_donations")
public class FoodDonation {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "restaurant_user_id", nullable = false)
    private User restaurantUser;

    @Column(name = "restaurant_name", nullable = false, length = 120)
    private String restaurantName;

    @Column(name = "restaurant_phone", nullable = false, length = 30)
    private String restaurantPhone;

    @Column(name = "restaurant_address", nullable = false, length = 255)
    private String restaurantAddress;

    @Column(name = "food_item_id")
    private Long foodItemId;

    @Column(name = "food_title", nullable = false, length = 150)
    private String foodTitle;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 50)
    private FoodCategory category = FoodCategory.OTHER;

    @Column(nullable = false, precision = 10, scale = 2)
    private BigDecimal quantity;

    @Column(nullable = false, length = 30)
    private String unit = "kg";

    @Column(name = "estimated_meals", nullable = false)
    private int estimatedMeals = 10;

    @Column(name = "food_condition", length = 150)
    private String foodCondition = "Freshly Prepared Surplus Food";

    @Column(name = "storage_temperature", length = 50)
    private String storageTemperature = "Warm / Hot";

    @Column(name = "consume_by_hours", nullable = false)
    private int consumeByHours = 6;

    @Column(name = "cost_value", nullable = false, precision = 10, scale = 2)
    private BigDecimal costValue = BigDecimal.ZERO;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 40)
    private DonationStatus status = DonationStatus.AVAILABLE;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "claimed_by_orphanage_id")
    private Orphanage claimedByOrphanage;

    @Column(name = "pickup_scheduled_time", length = 100)
    private String pickupScheduledTime;

    @Column(name = "pickup_notes", length = 255)
    private String pickupNotes;

    @Column(name = "collected_at")
    private LocalDateTime collectedAt;

    @Column(name = "verification_otp", length = 10)
    private String verificationOtp;

    @Column(name = "food_prep_id")
    private Long foodPrepId;

    @Column(name = "serving_size_grams", precision = 8, scale = 2)
    private BigDecimal servingSizeGrams = new BigDecimal("200.0");

    @Column(columnDefinition = "TEXT")
    private String notes;

    @Column(name = "created_at", nullable = false, updatable = false)
    private LocalDateTime createdAt = LocalDateTime.now();

    public FoodDonation() {
    }

    public FoodDonation(User restaurantUser, String restaurantName, String restaurantPhone,
                        String restaurantAddress, Long foodItemId, String foodTitle,
                        FoodCategory category, BigDecimal quantity, String unit,
                        int estimatedMeals, String foodCondition, String storageTemperature,
                        int consumeByHours, BigDecimal costValue, String notes) {
        this.restaurantUser = restaurantUser;
        this.restaurantName = restaurantName;
        this.restaurantPhone = restaurantPhone;
        this.restaurantAddress = restaurantAddress;
        this.foodItemId = foodItemId;
        this.foodTitle = foodTitle;
        this.category = category;
        this.quantity = quantity;
        this.unit = unit;
        this.estimatedMeals = estimatedMeals;
        this.foodCondition = foodCondition;
        this.storageTemperature = storageTemperature;
        this.consumeByHours = consumeByHours;
        this.costValue = costValue;
        this.notes = notes;
        this.status = DonationStatus.AVAILABLE;
        this.createdAt = LocalDateTime.now();
        this.verificationOtp = String.valueOf((int) (Math.random() * 9000) + 1000);
    }

    @PrePersist
    protected void onCreate() {
        if (this.createdAt == null) {
            this.createdAt = LocalDateTime.now();
        }
        if (this.verificationOtp == null) {
            this.verificationOtp = String.valueOf((int) (Math.random() * 9000) + 1000);
        }
    }

    private static final DateTimeFormatter FORMATTER = DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm");

    @Transient
    public String getFormattedCreatedAt() {
        return createdAt != null ? createdAt.format(FORMATTER) : "";
    }

    @Transient
    public String getFormattedCollectedAt() {
        return collectedAt != null ? collectedAt.format(FORMATTER) : "";
    }

    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public User getRestaurantUser() {
        return restaurantUser;
    }

    public void setRestaurantUser(User restaurantUser) {
        this.restaurantUser = restaurantUser;
    }

    public String getRestaurantName() {
        return restaurantName;
    }

    public void setRestaurantName(String restaurantName) {
        this.restaurantName = restaurantName;
    }

    public String getRestaurantPhone() {
        return restaurantPhone;
    }

    public void setRestaurantPhone(String restaurantPhone) {
        this.restaurantPhone = restaurantPhone;
    }

    public String getRestaurantAddress() {
        return restaurantAddress;
    }

    public void setRestaurantAddress(String restaurantAddress) {
        this.restaurantAddress = restaurantAddress;
    }

    public Long getFoodItemId() {
        return foodItemId;
    }

    public void setFoodItemId(Long foodItemId) {
        this.foodItemId = foodItemId;
    }

    public String getFoodTitle() {
        return foodTitle;
    }

    public void setFoodTitle(String foodTitle) {
        this.foodTitle = foodTitle;
    }

    public FoodCategory getCategory() {
        return category;
    }

    public void setCategory(FoodCategory category) {
        this.category = category;
    }

    public BigDecimal getQuantity() {
        return quantity;
    }

    public void setQuantity(BigDecimal quantity) {
        this.quantity = quantity;
    }

    public String getUnit() {
        return unit;
    }

    public void setUnit(String unit) {
        this.unit = unit;
    }

    public int getEstimatedMeals() {
        return estimatedMeals;
    }

    public void setEstimatedMeals(int estimatedMeals) {
        this.estimatedMeals = estimatedMeals;
    }

    public String getFoodCondition() {
        return foodCondition;
    }

    public void setFoodCondition(String foodCondition) {
        this.foodCondition = foodCondition;
    }

    public String getStorageTemperature() {
        return storageTemperature;
    }

    public void setStorageTemperature(String storageTemperature) {
        this.storageTemperature = storageTemperature;
    }

    public int getConsumeByHours() {
        return consumeByHours;
    }

    public void setConsumeByHours(int consumeByHours) {
        this.consumeByHours = consumeByHours;
    }

    public BigDecimal getCostValue() {
        return costValue;
    }

    public void setCostValue(BigDecimal costValue) {
        this.costValue = costValue;
    }

    public DonationStatus getStatus() {
        return status;
    }

    public void setStatus(DonationStatus status) {
        this.status = status;
    }

    public Orphanage getClaimedByOrphanage() {
        return claimedByOrphanage;
    }

    public void setClaimedByOrphanage(Orphanage claimedByOrphanage) {
        this.claimedByOrphanage = claimedByOrphanage;
    }

    public String getPickupScheduledTime() {
        return pickupScheduledTime;
    }

    public void setPickupScheduledTime(String pickupScheduledTime) {
        this.pickupScheduledTime = pickupScheduledTime;
    }

    public String getPickupNotes() {
        return pickupNotes;
    }

    public void setPickupNotes(String pickupNotes) {
        this.pickupNotes = pickupNotes;
    }

    public LocalDateTime getCollectedAt() {
        return collectedAt;
    }

    public void setCollectedAt(LocalDateTime collectedAt) {
        this.collectedAt = collectedAt;
    }

    public String getVerificationOtp() {
        return verificationOtp;
    }

    public void setVerificationOtp(String verificationOtp) {
        this.verificationOtp = verificationOtp;
    }

    public String getNotes() {
        return notes;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }

    public Long getFoodPrepId() {
        return foodPrepId;
    }

    public void setFoodPrepId(Long foodPrepId) {
        this.foodPrepId = foodPrepId;
    }

    public BigDecimal getServingSizeGrams() {
        return servingSizeGrams != null ? servingSizeGrams : new BigDecimal("200.0");
    }

    public void setServingSizeGrams(BigDecimal servingSizeGrams) {
        this.servingSizeGrams = servingSizeGrams;
    }

    @Transient
    public String getSurplusServingText() {
        return quantity + " " + unit + " surplus food can serve approximately " + estimatedMeals + " people.";
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }
}
