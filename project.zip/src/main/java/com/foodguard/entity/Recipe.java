package com.foodguard.entity;

import jakarta.persistence.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@Entity
@Table(name = "recipes")
public class Recipe {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, length = 150)
    private String title;

    @Column(nullable = false, columnDefinition = "TEXT")
    private String description;

    @Column(nullable = false, length = 50)
    private String category;

    @Column(name = "prep_time_minutes", nullable = false)
    private int prepTimeMinutes = 20;

    @Column(name = "ingredients_text", nullable = false, columnDefinition = "TEXT")
    private String ingredientsText;

    @Column(nullable = false, columnDefinition = "TEXT")
    private String instructions;

    @Column(name = "image_url")
    private String imageUrl;

    @Column(name = "is_custom", nullable = false)
    private boolean isCustom = false;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "created_by_user_id")
    private User createdBy;

    @Transient
    private int matchedIngredientsCount = 0;

    @Transient
    private List<String> matchedItemNames = new ArrayList<>();

    public Recipe() {
    }

    public Recipe(String title, String description, String category, int prepTimeMinutes,
                  String ingredientsText, String instructions, String imageUrl) {
        this.title = title;
        this.description = description;
        this.category = category;
        this.prepTimeMinutes = prepTimeMinutes;
        this.ingredientsText = ingredientsText;
        this.instructions = instructions;
        this.imageUrl = imageUrl;
    }

    public Recipe(String title, String description, String category, int prepTimeMinutes,
                  String ingredientsText, String instructions, String imageUrl,
                  boolean isCustom, User createdBy) {
        this(title, description, category, prepTimeMinutes, ingredientsText, instructions, imageUrl);
        this.isCustom = isCustom;
        this.createdBy = createdBy;
    }

    @Transient
    public List<String> getIngredientsList() {
        if (ingredientsText == null || ingredientsText.isBlank()) {
            return List.of();
        }
        return Arrays.stream(ingredientsText.split(","))
                .map(String::trim)
                .filter(s -> !s.isEmpty())
                .toList();
    }

    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public int getPrepTimeMinutes() {
        return prepTimeMinutes;
    }

    public void setPrepTimeMinutes(int prepTimeMinutes) {
        this.prepTimeMinutes = prepTimeMinutes;
    }

    public String getIngredientsText() {
        return ingredientsText;
    }

    public void setIngredientsText(String ingredientsText) {
        this.ingredientsText = ingredientsText;
    }

    public String getInstructions() {
        return instructions;
    }

    public void setInstructions(String instructions) {
        this.instructions = instructions;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public int getMatchedIngredientsCount() {
        return matchedIngredientsCount;
    }

    public void setMatchedIngredientsCount(int matchedIngredientsCount) {
        this.matchedIngredientsCount = matchedIngredientsCount;
    }

    public List<String> getMatchedItemNames() {
        return matchedItemNames;
    }

    public void setMatchedItemNames(List<String> matchedItemNames) {
        this.matchedItemNames = matchedItemNames;
    }

    public boolean isCustom() {
        return isCustom;
    }

    public void setCustom(boolean custom) {
        isCustom = custom;
    }

    public User getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(User createdBy) {
        this.createdBy = createdBy;
    }
}
