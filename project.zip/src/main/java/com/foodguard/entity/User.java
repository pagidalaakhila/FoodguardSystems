package com.foodguard.entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "users")
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, unique = true, length = 150)
    private String email;

    @Column(nullable = false)
    private String password;

    @Column(nullable = false, length = 100)
    private String fullName;

    @Column(nullable = false, length = 50)
    private String role = "ROLE_RESTAURANT_MANAGER";

    @Column(name = "restaurant_name", length = 150)
    private String restaurantName = "FoodGuard Grand Bistro";

    @Column(name = "phone_number", length = 30)
    private String phoneNumber = "+91 98450 11223";

    @Column(name = "alert_days_before", nullable = false)
    private int alertDaysBefore = 3;

    @Column(name = "email_alerts_enabled", nullable = false)
    private boolean emailAlertsEnabled = false;

    @Column(name = "created_at", nullable = false, updatable = false)
    private LocalDateTime createdAt = LocalDateTime.now();

    @Column(name = "updated_at")
    private LocalDateTime updatedAt = LocalDateTime.now();

    @OneToMany(mappedBy = "user", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<FoodItem> foodItems = new ArrayList<>();

    @OneToMany(mappedBy = "user", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<FoodAction> foodActions = new ArrayList<>();

    @OneToMany(mappedBy = "user", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Notification> notifications = new ArrayList<>();

    public User() {
    }

    public User(String email, String password, String fullName) {
        this.email = email;
        this.password = password;
        this.fullName = fullName;
    }

    @PrePersist
    protected void onCreate() {
        this.createdAt = LocalDateTime.now();
        this.updatedAt = LocalDateTime.now();
    }

    @PreUpdate
    protected void onUpdate() {
        this.updatedAt = LocalDateTime.now();
    }

    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public int getAlertDaysBefore() {
        return alertDaysBefore;
    }

    public void setAlertDaysBefore(int alertDaysBefore) {
        this.alertDaysBefore = alertDaysBefore;
    }

    public boolean isEmailAlertsEnabled() {
        return emailAlertsEnabled;
    }

    public void setEmailAlertsEnabled(boolean emailAlertsEnabled) {
        this.emailAlertsEnabled = emailAlertsEnabled;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public LocalDateTime getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(LocalDateTime updatedAt) {
        this.updatedAt = updatedAt;
    }

    public List<FoodItem> getFoodItems() {
        return foodItems;
    }

    public void setFoodItems(List<FoodItem> foodItems) {
        this.foodItems = foodItems;
    }

    public List<FoodAction> getFoodActions() {
        return foodActions;
    }

    public void setFoodActions(List<FoodAction> foodActions) {
        this.foodActions = foodActions;
    }

    public String getRestaurantName() {
        return restaurantName != null ? restaurantName : "FoodGuard Grand Bistro";
    }

    public void setRestaurantName(String restaurantName) {
        this.restaurantName = restaurantName;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    @Transient
    public String getRoleDisplayName() {
        if ("ROLE_ADMIN".equalsIgnoreCase(role)) return "Admin / General Manager";
        if ("ROLE_RESTAURANT_MANAGER".equalsIgnoreCase(role)) return "Restaurant Manager";
        if ("ROLE_KITCHEN_STAFF".equalsIgnoreCase(role)) return "Kitchen Staff";
        return "Staff Member";
    }

    @Transient
    public String getRoleBadgeClass() {
        if ("ROLE_ADMIN".equalsIgnoreCase(role)) return "badge-primary";
        if ("ROLE_RESTAURANT_MANAGER".equalsIgnoreCase(role)) return "badge-success";
        if ("ROLE_KITCHEN_STAFF".equalsIgnoreCase(role)) return "badge-info";
        return "badge-secondary";
    }

    public List<Notification> getNotifications() {
        return notifications;
    }

    public void setNotifications(List<Notification> notifications) {
        this.notifications = notifications;
    }
}
