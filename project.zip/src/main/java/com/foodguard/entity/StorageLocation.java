package com.foodguard.entity;

public enum StorageLocation {
    FRIDGE("Refrigerator", "fas fa-temperature-low"),
    FREEZER("Freezer", "fas fa-snowflake"),
    PANTRY("Pantry Cupboard", "fas fa-archive"),
    COUNTERTOP("Countertop", "fas fa-layer-group");

    private final String displayName;
    private final String iconClass;

    StorageLocation(String displayName, String iconClass) {
        this.displayName = displayName;
        this.iconClass = iconClass;
    }

    public String getDisplayName() {
        return displayName;
    }

    public String getIconClass() {
        return iconClass;
    }
}
