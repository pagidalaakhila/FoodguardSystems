package com.foodguard.entity;

public enum ExpiryStatus {
    FRESH("Fresh & Safe", "badge-fresh", "text-emerald-700 bg-emerald-100"),
    EXPIRING_SOON("Expiring Soon", "badge-expiring", "text-amber-700 bg-amber-100"),
    EXPIRED("Expired", "badge-expired", "text-rose-700 bg-rose-100"),
    LOW_STOCK("Low Stock", "badge-warning", "text-orange-700 bg-orange-100");

    private final String label;
    private final String cssClass;
    private final String tailwindStyle;

    ExpiryStatus(String label, String cssClass, String tailwindStyle) {
        this.label = label;
        this.cssClass = cssClass;
        this.tailwindStyle = tailwindStyle;
    }

    public String getLabel() {
        return label;
    }

    public String getCssClass() {
        return cssClass;
    }

    public String getTailwindStyle() {
        return tailwindStyle;
    }
}
