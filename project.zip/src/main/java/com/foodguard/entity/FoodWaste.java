package com.foodguard.entity;

import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

@Entity
@Table(name = "food_waste")
public class FoodWaste {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.EAGER, optional = false)
    @JoinColumn(name = "user_id", nullable = false)
    private User user;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "food_prep_id")
    private FoodPreparation foodPreparation;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "food_item_id")
    private FoodItem foodItem;

    @Column(name = "food_name", nullable = false, length = 150)
    private String foodName;

    @Enumerated(EnumType.STRING)
    @Column(name = "category", nullable = false, length = 50)
    private FoodCategory category = FoodCategory.OTHER;

    @Column(name = "quantity_wasted", nullable = false, precision = 10, scale = 2)
    private BigDecimal quantityWasted;

    @Column(nullable = false, length = 30)
    private String unit = "kg";

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 50)
    private WasteReason reason;

    @Column(name = "cost_per_unit", precision = 10, scale = 2)
    private BigDecimal costPerUnit = BigDecimal.ZERO;

    @Column(name = "estimated_cost_loss", nullable = false, precision = 10, scale = 2)
    private BigDecimal estimatedCostLoss = BigDecimal.ZERO;

    @Column(name = "waste_date", nullable = false)
    private LocalDateTime wasteDate = LocalDateTime.now();

    @Column(name = "action_taken", length = 100)
    private String actionTaken = "Discarded / Organic Bin"; // Composted, Organic Bin, Landfill, Kitchen Logged

    @Column(columnDefinition = "TEXT")
    private String notes;

    public FoodWaste() {
    }

    public FoodWaste(User user, FoodPreparation foodPreparation, FoodItem foodItem,
                     String foodName, FoodCategory category, BigDecimal quantityWasted,
                     String unit, WasteReason reason, BigDecimal costPerUnit, String notes) {
        this.user = user;
        this.foodPreparation = foodPreparation;
        this.foodItem = foodItem;
        this.foodName = foodName;
        this.category = (category != null) ? category : FoodCategory.OTHER;
        this.quantityWasted = quantityWasted;
        this.unit = (unit != null) ? unit : "kg";
        this.reason = (reason != null) ? reason : WasteReason.EXPIRED;
        this.costPerUnit = (costPerUnit != null) ? costPerUnit : BigDecimal.ZERO;
        this.estimatedCostLoss = this.quantityWasted.multiply(this.costPerUnit);
        this.notes = notes;
        this.wasteDate = LocalDateTime.now();
    }

    @PrePersist
    protected void onCreate() {
        if (this.wasteDate == null) {
            this.wasteDate = LocalDateTime.now();
        }
        if (this.estimatedCostLoss == null || this.estimatedCostLoss.compareTo(BigDecimal.ZERO) == 0) {
            if (this.quantityWasted != null && this.costPerUnit != null) {
                this.estimatedCostLoss = this.quantityWasted.multiply(this.costPerUnit);
            }
        }
    }

    private static final DateTimeFormatter FORMATTER = DateTimeFormatter.ofPattern("dd-MM-yyyy hh:mm a");

    @Transient
    public String getFormattedWasteDate() {
        return wasteDate != null ? wasteDate.format(FORMATTER) : "";
    }

    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public FoodPreparation getFoodPreparation() {
        return foodPreparation;
    }

    public void setFoodPreparation(FoodPreparation foodPreparation) {
        this.foodPreparation = foodPreparation;
    }

    public FoodItem getFoodItem() {
        return foodItem;
    }

    public void setFoodItem(FoodItem foodItem) {
        this.foodItem = foodItem;
    }

    public String getFoodName() {
        return foodName;
    }

    public void setFoodName(String foodName) {
        this.foodName = foodName;
    }

    public FoodCategory getCategory() {
        return category;
    }

    public void setCategory(FoodCategory category) {
        this.category = category;
    }

    public BigDecimal getQuantityWasted() {
        return quantityWasted;
    }

    public void setQuantityWasted(BigDecimal quantityWasted) {
        this.quantityWasted = quantityWasted;
    }

    public String getUnit() {
        return unit;
    }

    public void setUnit(String unit) {
        this.unit = unit;
    }

    public WasteReason getReason() {
        return reason;
    }

    public void setReason(WasteReason reason) {
        this.reason = reason;
    }

    public BigDecimal getCostPerUnit() {
        return costPerUnit;
    }

    public void setCostPerUnit(BigDecimal costPerUnit) {
        this.costPerUnit = costPerUnit;
    }

    public BigDecimal getEstimatedCostLoss() {
        return estimatedCostLoss;
    }

    public void setEstimatedCostLoss(BigDecimal estimatedCostLoss) {
        this.estimatedCostLoss = estimatedCostLoss;
    }

    public LocalDateTime getWasteDate() {
        return wasteDate;
    }

    public void setWasteDate(LocalDateTime wasteDate) {
        this.wasteDate = wasteDate;
    }

    public String getActionTaken() {
        return actionTaken;
    }

    public void setActionTaken(String actionTaken) {
        this.actionTaken = actionTaken;
    }

    public String getNotes() {
        return notes;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }
}
