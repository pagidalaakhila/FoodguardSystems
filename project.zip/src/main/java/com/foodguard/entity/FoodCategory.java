package com.foodguard.entity;

public enum FoodCategory {
    PRODUCE("Fruits & Vegetables", "fas fa-apple-alt", "#10B981"),
    DAIRY("Dairy & Eggs", "fas fa-cheese", "#F59E0B"),
    MEAT("Meat & Seafood", "fas fa-drumstick-bite", "#EF4444"),
    BAKERY("Bakery & Grains", "fas fa-bread-slice", "#D97706"),
    PANTRY("Pantry Staples", "fas fa-box-open", "#8B5CF6"),
    BEVERAGES("Beverages", "fas fa-wine-bottle", "#06B6D4"),
    FROZEN("Frozen Foods", "fas fa-snowflake", "#3B82F6"),
    OTHER("Other", "fas fa-utensils", "#64748B");

    private final String displayName;
    private final String iconClass;
    private final String colorCode;

    FoodCategory(String displayName, String iconClass, String colorCode) {
        this.displayName = displayName;
        this.iconClass = iconClass;
        this.colorCode = colorCode;
    }

    public String getDisplayName() {
        return displayName;
    }

    public String getIconClass() {
        return iconClass;
    }

    public String getColorCode() {
        return colorCode;
    }
}
