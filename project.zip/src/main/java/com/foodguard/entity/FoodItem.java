package com.foodguard.entity;

import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;

@Entity
@Table(name = "food_items")
public class FoodItem {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.EAGER, optional = false)
    @JoinColumn(name = "user_id", nullable = false)
    private User user;

    @Column(nullable = false, length = 120)
    private String name;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 50)
    private FoodCategory category;

    @Column(nullable = false, precision = 10, scale = 2)
    private BigDecimal quantity;

    @Column(nullable = false, length = 30)
    private String unit;

    @Column(name = "purchase_date", nullable = false)
    private LocalDate purchaseDate;

    @Column(name = "expiry_date", nullable = false)
    private LocalDate expiryDate;

    @Enumerated(EnumType.STRING)
    @Column(name = "storage_location", nullable = false, length = 50)
    private StorageLocation storageLocation;

    @Column(name = "mfg_date")
    private LocalDate mfgDate;

    @Column(name = "current_available_quantity", precision = 10, scale = 2)
    private BigDecimal currentAvailableQuantity;

    @Column(name = "min_stock_level", precision = 10, scale = 2)
    private BigDecimal minStockLevel = new BigDecimal("5.0");

    @Column(name = "storage_type", length = 50)
    private String storageType = "Refrigerator";

    @Column(name = "supplier_name", length = 150)
    private String supplierName = "Metro Restaurant Supplies";

    @Column(nullable = false, precision = 10, scale = 2)
    private BigDecimal cost = BigDecimal.ZERO;

    @Column(columnDefinition = "TEXT")
    private String notes;

    @Column(name = "created_at", nullable = false, updatable = false)
    private LocalDateTime createdAt = LocalDateTime.now();

    @Column(name = "updated_at")
    private LocalDateTime updatedAt = LocalDateTime.now();

    public FoodItem() {
    }

    public FoodItem(User user, String name, FoodCategory category, BigDecimal quantity, String unit,
                    LocalDate purchaseDate, LocalDate expiryDate, StorageLocation storageLocation,
                    BigDecimal cost, String notes) {
        this.user = user;
        this.name = name;
        this.category = category;
        this.quantity = quantity;
        this.unit = unit;
        this.purchaseDate = purchaseDate;
        this.expiryDate = expiryDate;
        this.storageLocation = storageLocation;
        this.cost = (cost != null) ? cost : BigDecimal.ZERO;
        this.notes = notes;
    }

    @PrePersist
    protected void onCreate() {
        this.createdAt = LocalDateTime.now();
        this.updatedAt = LocalDateTime.now();
        if (this.currentAvailableQuantity == null) {
            this.currentAvailableQuantity = this.quantity;
        }
        if (this.mfgDate == null) {
            this.mfgDate = this.purchaseDate;
        }
        if (this.minStockLevel == null) {
            this.minStockLevel = new BigDecimal("5.0");
        }
    }

    @PreUpdate
    protected void onUpdate() {
        this.updatedAt = LocalDateTime.now();
    }

    @Transient
    public BigDecimal getEffectiveAvailableQuantity() {
        return (currentAvailableQuantity != null) ? currentAvailableQuantity : quantity;
    }

    @Transient
    public boolean isLowStock() {
        BigDecimal avail = getEffectiveAvailableQuantity();
        BigDecimal min = (minStockLevel != null) ? minStockLevel : BigDecimal.ZERO;
        return avail != null && avail.compareTo(min) <= 0;
    }

    /**
     * Calculates days until expiry from today.
     * Positive = days remaining, 0 = expires today, Negative = expired N days ago.
     */
    @Transient
    public long getDaysUntilExpiry() {
        if (expiryDate == null) {
            return 0;
        }
        return ChronoUnit.DAYS.between(LocalDate.now(), expiryDate);
    }

    /**
     * Evaluates expiry and inventory status:
     * - < 0 days: EXPIRED
     * - low stock: LOW_STOCK
     * - 0 to 3 days: EXPIRING_SOON
     * - > 3 days: FRESH
     */
    @Transient
    public ExpiryStatus getStatus() {
        long days = getDaysUntilExpiry();
        if (days < 0) {
            return ExpiryStatus.EXPIRED;
        } else if (isLowStock()) {
            return ExpiryStatus.LOW_STOCK;
        } else if (days <= 3) {
            return ExpiryStatus.EXPIRING_SOON;
        } else {
            return ExpiryStatus.FRESH;
        }
    }

    /**
     * Returns formatted countdown badge text:
     * e.g. "Expires in 2 days", "Expires today!", "Expired 1 day ago"
     */
    @Transient
    public String getExpiryBadgeText() {
        long days = getDaysUntilExpiry();
        if (days < -1) {
            return "Expired " + Math.abs(days) + " days ago";
        } else if (days == -1) {
            return "Expired yesterday";
        } else if (days == 0) {
            return "Expires today!";
        } else if (days == 1) {
            return "Expires tomorrow";
        } else {
            return "Expires in " + days + " days";
        }
    }

    private static final DateTimeFormatter DATE_FORMATTER = DateTimeFormatter.ofPattern("dd-MM-yyyy");

    @Transient
    public String getFormattedExpiryDate() {
        return expiryDate != null ? expiryDate.format(DATE_FORMATTER) : "";
    }

    @Transient
    public String getFormattedPurchaseDate() {
        return purchaseDate != null ? purchaseDate.format(DATE_FORMATTER) : "";
    }

    @Transient
    public String getFormattedMfgDate() {
        return getMfgDate() != null ? getMfgDate().format(DATE_FORMATTER) : "";
    }

    @Transient
    public String getDisplayQuantity() {
        if (quantity == null) {
            return "0";
        }
        return quantity.stripTrailingZeros().toPlainString();
    }

    @Transient
    public String getDisplayAvailableQuantity() {
        BigDecimal avail = getCurrentAvailableQuantity();
        if (avail == null) {
            return "0";
        }
        return avail.stripTrailingZeros().toPlainString();
    }

    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public FoodCategory getCategory() {
        return category;
    }

    public void setCategory(FoodCategory category) {
        this.category = category;
    }

    public BigDecimal getQuantity() {
        return quantity;
    }

    public void setQuantity(BigDecimal quantity) {
        this.quantity = quantity;
    }

    public String getUnit() {
        return unit;
    }

    public void setUnit(String unit) {
        this.unit = unit;
    }

    public LocalDate getPurchaseDate() {
        return purchaseDate;
    }

    public void setPurchaseDate(LocalDate purchaseDate) {
        this.purchaseDate = purchaseDate;
    }

    public LocalDate getExpiryDate() {
        return expiryDate;
    }

    public void setExpiryDate(LocalDate expiryDate) {
        this.expiryDate = expiryDate;
    }

    public StorageLocation getStorageLocation() {
        return storageLocation;
    }

    public void setStorageLocation(StorageLocation storageLocation) {
        this.storageLocation = storageLocation;
    }

    public BigDecimal getCost() {
        return cost;
    }

    public void setCost(BigDecimal cost) {
        this.cost = (cost != null) ? cost : BigDecimal.ZERO;
    }

    public String getNotes() {
        return notes;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }

    public LocalDate getMfgDate() {
        return mfgDate != null ? mfgDate : purchaseDate;
    }

    public void setMfgDate(LocalDate mfgDate) {
        this.mfgDate = mfgDate;
    }

    public BigDecimal getCurrentAvailableQuantity() {
        return currentAvailableQuantity != null ? currentAvailableQuantity : quantity;
    }

    public void setCurrentAvailableQuantity(BigDecimal currentAvailableQuantity) {
        this.currentAvailableQuantity = currentAvailableQuantity;
    }

    public BigDecimal getMinStockLevel() {
        return minStockLevel != null ? minStockLevel : new BigDecimal("5.0");
    }

    public void setMinStockLevel(BigDecimal minStockLevel) {
        this.minStockLevel = minStockLevel;
    }

    public String getStorageType() {
        return storageType != null ? storageType : (storageLocation != null ? storageLocation.getDisplayName() : "Refrigerator");
    }

    public void setStorageType(String storageType) {
        this.storageType = storageType;
    }

    public String getSupplierName() {
        return supplierName != null ? supplierName : "Metro Restaurant Supplies";
    }

    public void setSupplierName(String supplierName) {
        this.supplierName = supplierName;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public LocalDateTime getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(LocalDateTime updatedAt) {
        this.updatedAt = updatedAt;
    }
}
