package com.foodguard.entity;

public enum WasteReason {
    EXPIRED("Expired Past Date", "badge-danger", "#EF4444"),
    OVERPRODUCTION("Overproduction / Surplus", "badge-warning", "#F59E0B"),
    SPOILED("Spoiled / Bad Quality", "badge-danger", "#DC2626"),
    DAMAGED("Damaged / Broken", "badge-warning", "#D97706"),
    CUSTOMER_RETURN("Customer Return", "badge-info", "#6366F1"),
    PREPARATION_ERROR("Preparation / Kitchen Error", "badge-secondary", "#8B5CF6"),
    STORAGE_PROBLEM("Storage / Chiller Breakdown", "badge-danger", "#059669");

    private final String displayName;
    private final String badgeClass;
    private final String colorCode;

    WasteReason(String displayName, String badgeClass, String colorCode) {
        this.displayName = displayName;
        this.badgeClass = badgeClass;
        this.colorCode = colorCode;
    }

    public String getDisplayName() {
        return displayName;
    }

    public String getBadgeClass() {
        return badgeClass;
    }

    public String getColorCode() {
        return colorCode;
    }
}
