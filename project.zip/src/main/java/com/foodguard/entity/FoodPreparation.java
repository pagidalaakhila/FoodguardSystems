package com.foodguard.entity;

import jakarta.persistence.*;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;

@Entity
@Table(name = "food_preparations")
public class FoodPreparation {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.EAGER, optional = false)
    @JoinColumn(name = "user_id", nullable = false)
    private User user;

    @Column(name = "prep_date", nullable = false)
    private LocalDate prepDate = LocalDate.now();

    @Column(name = "food_name", nullable = false, length = 150)
    private String foodName;

    @Column(name = "ingredients_used", columnDefinition = "TEXT")
    private String ingredientsUsed;

    @Column(name = "quantity_prepared", nullable = false, precision = 10, scale = 2)
    private BigDecimal quantityPrepared;

    @Column(nullable = false, length = 30)
    private String unit = "kg";

    @Column(name = "portions_prepared", nullable = false)
    private int portionsPrepared;

    @Column(name = "portions_sold", nullable = false)
    private int portionsSold = 0;

    @Column(name = "portions_donated", nullable = false)
    private int portionsDonated = 0;

    @Column(name = "portions_wasted", nullable = false)
    private int portionsWasted = 0;

    @Column(name = "serving_size_grams", precision = 8, scale = 2)
    private BigDecimal servingSizeGrams = new BigDecimal("200.0");

    @Column(name = "remaining_quantity", nullable = false, precision = 10, scale = 2)
    private BigDecimal remainingQuantity;

    @Column(name = "remaining_portions", nullable = false)
    private int remainingPortions;

    @Column(name = "prep_time", length = 30)
    private String prepTime = "11:30 AM";

    @Column(name = "expected_shelf_hours", nullable = false)
    private int expectedShelfHours = 8;

    @Column(name = "expiry_date_time", nullable = false)
    private LocalDateTime expiryDateTime;

    @Column(nullable = false, length = 50)
    private String status = "READY_TO_SERVE"; // READY_TO_SERVE, SURPLUS_AVAILABLE, FULLY_SERVED, EXPIRED, DONATED, WASTED

    @Column(name = "cost_per_portion", precision = 10, scale = 2)
    private BigDecimal costPerPortion = BigDecimal.ZERO;

    @Column(name = "selling_price_per_portion", precision = 10, scale = 2)
    private BigDecimal sellingPricePerPortion = BigDecimal.ZERO;

    @Column(name = "created_at", nullable = false, updatable = false)
    private LocalDateTime createdAt = LocalDateTime.now();

    @Column(name = "updated_at")
    private LocalDateTime updatedAt = LocalDateTime.now();

    public FoodPreparation() {
    }

    public FoodPreparation(User user, LocalDate prepDate, String foodName, String ingredientsUsed,
                           BigDecimal quantityPrepared, String unit, int portionsPrepared,
                           BigDecimal servingSizeGrams, String prepTime, int expectedShelfHours,
                           BigDecimal costPerPortion, BigDecimal sellingPricePerPortion) {
        this.user = user;
        this.prepDate = (prepDate != null) ? prepDate : LocalDate.now();
        this.foodName = foodName;
        this.ingredientsUsed = ingredientsUsed;
        this.quantityPrepared = quantityPrepared;
        this.unit = (unit != null) ? unit : "kg";
        this.portionsPrepared = portionsPrepared;
        this.servingSizeGrams = (servingSizeGrams != null) ? servingSizeGrams : new BigDecimal("200.0");
        this.prepTime = prepTime;
        this.expectedShelfHours = (expectedShelfHours > 0) ? expectedShelfHours : 8;
        this.costPerPortion = (costPerPortion != null) ? costPerPortion : BigDecimal.ZERO;
        this.sellingPricePerPortion = (sellingPricePerPortion != null) ? sellingPricePerPortion : BigDecimal.ZERO;
        this.portionsSold = 0;
        this.portionsDonated = 0;
        this.portionsWasted = 0;

        // Default expiry date time: now plus expectedShelfHours
        this.expiryDateTime = LocalDateTime.now().plusHours(this.expectedShelfHours);
        this.recalculate();
    }

    @PrePersist
    protected void onCreate() {
        this.createdAt = LocalDateTime.now();
        this.updatedAt = LocalDateTime.now();
        if (this.expiryDateTime == null) {
            this.expiryDateTime = LocalDateTime.now().plusHours(expectedShelfHours);
        }
        recalculate();
    }

    @PreUpdate
    protected void onUpdate() {
        this.updatedAt = LocalDateTime.now();
        recalculate();
    }

    /**
     * Automatically recalculates remaining portions, remaining quantity, and status.
     */
    public void recalculate() {
        this.remainingPortions = Math.max(0, this.portionsPrepared - this.portionsSold - this.portionsDonated - this.portionsWasted);
        if (this.portionsPrepared > 0) {
            this.remainingQuantity = this.quantityPrepared
                    .multiply(BigDecimal.valueOf(this.remainingPortions))
                    .divide(BigDecimal.valueOf(this.portionsPrepared), 2, RoundingMode.HALF_UP);
        } else {
            this.remainingQuantity = BigDecimal.ZERO;
        }

        if (this.remainingPortions == 0) {
            this.status = "FULLY_SERVED";
        } else if (this.expiryDateTime != null && LocalDateTime.now().isAfter(this.expiryDateTime)) {
            this.status = "EXPIRED";
        } else if (isSafeForDonation()) {
            this.status = "SURPLUS_AVAILABLE";
        } else {
            this.status = "READY_TO_SERVE";
        }
    }

    /**
     * Checks if remaining food is safe for donation.
     */
    @Transient
    public boolean isSafeForDonation() {
        return this.remainingPortions > 0 &&
               this.expiryDateTime != null &&
               LocalDateTime.now().isBefore(this.expiryDateTime);
    }

    /**
     * Calculates sold quantity.
     */
    @Transient
    public BigDecimal getSoldQuantity() {
        if (portionsPrepared <= 0) return BigDecimal.ZERO;
        return quantityPrepared.multiply(BigDecimal.valueOf(portionsSold))
                .divide(BigDecimal.valueOf(portionsPrepared), 2, RoundingMode.HALF_UP);
    }

    /**
     * Calculates donated quantity.
     */
    @Transient
    public BigDecimal getDonatedQuantity() {
        if (portionsPrepared <= 0) return BigDecimal.ZERO;
        return quantityPrepared.multiply(BigDecimal.valueOf(portionsDonated))
                .divide(BigDecimal.valueOf(portionsPrepared), 2, RoundingMode.HALF_UP);
    }

    /**
     * Calculates wasted quantity.
     */
    @Transient
    public BigDecimal getWastedQuantity() {
        if (portionsPrepared <= 0) return BigDecimal.ZERO;
        return quantityPrepared.multiply(BigDecimal.valueOf(portionsWasted))
                .divide(BigDecimal.valueOf(portionsPrepared), 2, RoundingMode.HALF_UP);
    }

    /**
     * Hours until expiry. Negative if expired.
     */
    @Transient
    public long getHoursUntilExpiry() {
        if (expiryDateTime == null) return 0;
        return ChronoUnit.HOURS.between(LocalDateTime.now(), expiryDateTime);
    }

    /**
     * Human-readable expiry badge text.
     */
    @Transient
    public String getExpiryBadgeText() {
        if (expiryDateTime == null) return "Safe";
        long hours = getHoursUntilExpiry();
        if (hours < 0) {
            return "Expired " + Math.abs(hours) + "h ago";
        } else if (hours == 0) {
            return "Expires in <1 hour!";
        } else {
            return "Safe for " + hours + "h";
        }
    }

    @Transient
    public String getStatusBadgeClass() {
        if ("EXPIRED".equalsIgnoreCase(status)) return "badge-danger";
        if ("SURPLUS_AVAILABLE".equalsIgnoreCase(status)) return "badge-warning";
        if ("READY_TO_SERVE".equalsIgnoreCase(status)) return "badge-success";
        if ("FULLY_SERVED".equalsIgnoreCase(status)) return "badge-info";
        return "badge-secondary";
    }

    private static final DateTimeFormatter DATE_FORMATTER = DateTimeFormatter.ofPattern("dd-MM-yyyy");
    private static final DateTimeFormatter TIME_FORMATTER = DateTimeFormatter.ofPattern("hh:mm a");

    @Transient
    public String getFormattedPrepDate() {
        return prepDate != null ? prepDate.format(DATE_FORMATTER) : "";
    }

    @Transient
    public String getFormattedExpiryTime() {
        return expiryDateTime != null ? expiryDateTime.format(DateTimeFormatter.ofPattern("dd-MM-yyyy hh:mm a")) : "";
    }

    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public LocalDate getPrepDate() {
        return prepDate;
    }

    public void setPrepDate(LocalDate prepDate) {
        this.prepDate = prepDate;
    }

    public String getFoodName() {
        return foodName;
    }

    public void setFoodName(String foodName) {
        this.foodName = foodName;
    }

    public String getIngredientsUsed() {
        return ingredientsUsed;
    }

    public void setIngredientsUsed(String ingredientsUsed) {
        this.ingredientsUsed = ingredientsUsed;
    }

    public BigDecimal getQuantityPrepared() {
        return quantityPrepared;
    }

    public void setQuantityPrepared(BigDecimal quantityPrepared) {
        this.quantityPrepared = quantityPrepared;
    }

    public String getUnit() {
        return unit;
    }

    public void setUnit(String unit) {
        this.unit = unit;
    }

    public int getPortionsPrepared() {
        return portionsPrepared;
    }

    public void setPortionsPrepared(int portionsPrepared) {
        this.portionsPrepared = portionsPrepared;
    }

    public int getPortionsSold() {
        return portionsSold;
    }

    public void setPortionsSold(int portionsSold) {
        this.portionsSold = portionsSold;
    }

    public int getPortionsDonated() {
        return portionsDonated;
    }

    public void setPortionsDonated(int portionsDonated) {
        this.portionsDonated = portionsDonated;
    }

    public int getPortionsWasted() {
        return portionsWasted;
    }

    public void setPortionsWasted(int portionsWasted) {
        this.portionsWasted = portionsWasted;
    }

    public BigDecimal getServingSizeGrams() {
        return servingSizeGrams;
    }

    public void setServingSizeGrams(BigDecimal servingSizeGrams) {
        this.servingSizeGrams = servingSizeGrams;
    }

    public BigDecimal getRemainingQuantity() {
        return remainingQuantity;
    }

    public void setRemainingQuantity(BigDecimal remainingQuantity) {
        this.remainingQuantity = remainingQuantity;
    }

    public int getRemainingPortions() {
        return remainingPortions;
    }

    public void setRemainingPortions(int remainingPortions) {
        this.remainingPortions = remainingPortions;
    }

    public String getPrepTime() {
        return prepTime;
    }

    public void setPrepTime(String prepTime) {
        this.prepTime = prepTime;
    }

    public int getExpectedShelfHours() {
        return expectedShelfHours;
    }

    public void setExpectedShelfHours(int expectedShelfHours) {
        this.expectedShelfHours = expectedShelfHours;
    }

    public LocalDateTime getExpiryDateTime() {
        return expiryDateTime;
    }

    public void setExpiryDateTime(LocalDateTime expiryDateTime) {
        this.expiryDateTime = expiryDateTime;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public BigDecimal getCostPerPortion() {
        return costPerPortion;
    }

    public void setCostPerPortion(BigDecimal costPerPortion) {
        this.costPerPortion = costPerPortion;
    }

    public BigDecimal getSellingPricePerPortion() {
        return sellingPricePerPortion;
    }

    public void setSellingPricePerPortion(BigDecimal sellingPricePerPortion) {
        this.sellingPricePerPortion = sellingPricePerPortion;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public LocalDateTime getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(LocalDateTime updatedAt) {
        this.updatedAt = updatedAt;
    }
}
