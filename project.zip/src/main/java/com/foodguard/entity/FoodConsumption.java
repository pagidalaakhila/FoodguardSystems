package com.foodguard.entity;

import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

@Entity
@Table(name = "food_consumptions")
public class FoodConsumption {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.EAGER, optional = false)
    @JoinColumn(name = "user_id", nullable = false)
    private User user;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "food_prep_id")
    private FoodPreparation foodPreparation;

    @Column(name = "food_name", nullable = false, length = 150)
    private String foodName;

    @Column(name = "portions_sold", nullable = false)
    private int portionsSold;

    @Column(name = "quantity_sold", nullable = false, precision = 10, scale = 2)
    private BigDecimal quantitySold;

    @Column(nullable = false, length = 30)
    private String unit = "kg";

    @Column(name = "order_type", length = 50)
    private String orderType = "Dine-in"; // Dine-in, Takeaway, Online Delivery, Banquet

    @Column(name = "revenue", precision = 10, scale = 2)
    private BigDecimal revenue = BigDecimal.ZERO;

    @Column(name = "consumption_time", nullable = false)
    private LocalDateTime consumptionTime = LocalDateTime.now();

    @Column(columnDefinition = "TEXT")
    private String notes;

    public FoodConsumption() {
    }

    public FoodConsumption(User user, FoodPreparation foodPreparation, String foodName,
                           int portionsSold, BigDecimal quantitySold, String unit,
                           String orderType, BigDecimal revenue, String notes) {
        this.user = user;
        this.foodPreparation = foodPreparation;
        this.foodName = foodName;
        this.portionsSold = portionsSold;
        this.quantitySold = quantitySold;
        this.unit = (unit != null) ? unit : "kg";
        this.orderType = (orderType != null) ? orderType : "Dine-in";
        this.revenue = (revenue != null) ? revenue : BigDecimal.ZERO;
        this.notes = notes;
        this.consumptionTime = LocalDateTime.now();
    }

    @PrePersist
    protected void onCreate() {
        if (this.consumptionTime == null) {
            this.consumptionTime = LocalDateTime.now();
        }
    }

    private static final DateTimeFormatter FORMATTER = DateTimeFormatter.ofPattern("dd-MM-yyyy hh:mm a");

    @Transient
    public String getFormattedConsumptionTime() {
        return consumptionTime != null ? consumptionTime.format(FORMATTER) : "";
    }

    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public FoodPreparation getFoodPreparation() {
        return foodPreparation;
    }

    public void setFoodPreparation(FoodPreparation foodPreparation) {
        this.foodPreparation = foodPreparation;
    }

    public String getFoodName() {
        return foodName;
    }

    public void setFoodName(String foodName) {
        this.foodName = foodName;
    }

    public int getPortionsSold() {
        return portionsSold;
    }

    public void setPortionsSold(int portionsSold) {
        this.portionsSold = portionsSold;
    }

    public BigDecimal getQuantitySold() {
        return quantitySold;
    }

    public void setQuantitySold(BigDecimal quantitySold) {
        this.quantitySold = quantitySold;
    }

    public String getUnit() {
        return unit;
    }

    public void setUnit(String unit) {
        this.unit = unit;
    }

    public String getOrderType() {
        return orderType;
    }

    public void setOrderType(String orderType) {
        this.orderType = orderType;
    }

    public BigDecimal getRevenue() {
        return revenue;
    }

    public void setRevenue(BigDecimal revenue) {
        this.revenue = revenue;
    }

    public LocalDateTime getConsumptionTime() {
        return consumptionTime;
    }

    public void setConsumptionTime(LocalDateTime consumptionTime) {
        this.consumptionTime = consumptionTime;
    }

    public String getNotes() {
        return notes;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }
}
