package com.foodguard.entity;

public enum DonationStatus {
    AVAILABLE("Available for Rescue", "badge-fresh", "fa-clock", "Waiting for orphanage to claim"),
    PICKUP_SCHEDULED("Pickup Scheduled", "badge-expiring", "fa-truck", "Orphanage confirmed pickup arrival time"),
    COLLECTED("Collected & Fed", "badge-consumed", "fa-check-circle", "Food collected and handed over"),
    CANCELLED("Cancelled", "badge-expired", "fa-times-circle", "Donation cancelled");

    private final String displayName;
    private final String cssClass;
    private final String iconClass;
    private final String description;

    DonationStatus(String displayName, String cssClass, String iconClass, String description) {
        this.displayName = displayName;
        this.cssClass = cssClass;
        this.iconClass = iconClass;
        this.description = description;
    }

    public String getDisplayName() {
        return displayName;
    }

    public String getCssClass() {
        return cssClass;
    }

    public String getIconClass() {
        return iconClass;
    }

    public String getDescription() {
        return description;
    }
}
