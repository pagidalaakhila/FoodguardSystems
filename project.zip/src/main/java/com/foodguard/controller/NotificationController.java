package com.foodguard.controller;

import com.foodguard.entity.Notification;
import com.foodguard.entity.User;
import com.foodguard.service.NotificationService;
import com.foodguard.service.UserService;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.List;
import java.util.Map;

@Controller
@RequestMapping("/notifications")
public class NotificationController {

    private final NotificationService notificationService;
    private final UserService userService;

    public NotificationController(NotificationService notificationService, UserService userService) {
        this.notificationService = notificationService;
        this.userService = userService;
    }

    @GetMapping
    public String listNotifications(Model model) {
        User user = userService.getCurrentUser();
        List<Notification> notifications = notificationService.getNotificationsForUser(user);
        long unreadCount = notificationService.getUnreadCount(user);

        model.addAttribute("user", user);
        model.addAttribute("notifications", notifications);
        model.addAttribute("unreadCount", unreadCount);
        return "notifications/list";
    }

    @PostMapping("/mark-read/{id}")
    public String markAsRead(
            @PathVariable("id") Long id,
            @RequestParam(value = "redirectUri", required = false, defaultValue = "/notifications") String redirectUri
    ) {
        User user = userService.getCurrentUser();
        notificationService.markAsRead(id, user);
        return "redirect:" + redirectUri;
    }

    @PostMapping("/mark-all-read")
    public String markAllAsRead(
            @RequestParam(value = "redirectUri", required = false, defaultValue = "/notifications") String redirectUri,
            RedirectAttributes redirectAttributes
    ) {
        User user = userService.getCurrentUser();
        notificationService.markAllAsRead(user);
        redirectAttributes.addFlashAttribute("successMessage", "All notifications marked as read.");
        return "redirect:" + redirectUri;
    }

    @GetMapping("/api/unread-count")
    @ResponseBody
    public ResponseEntity<Map<String, Long>> getUnreadCountApi() {
        try {
            User user = userService.getCurrentUser();
            long count = notificationService.getUnreadCount(user);
            return ResponseEntity.ok(Map.of("count", count));
        } catch (Exception e) {
            return ResponseEntity.ok(Map.of("count", 0L));
        }
    }
}
