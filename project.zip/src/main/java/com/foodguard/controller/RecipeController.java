package com.foodguard.controller;

import com.foodguard.entity.FoodItem;
import com.foodguard.entity.Recipe;
import com.foodguard.entity.User;
import com.foodguard.repository.FoodItemRepository;
import com.foodguard.service.RecipeService;
import com.foodguard.service.UserService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.List;

@Controller
@RequestMapping("/recipes")
public class RecipeController {

    private final RecipeService recipeService;
    private final UserService userService;
    private final FoodItemRepository foodItemRepository;

    public RecipeController(RecipeService recipeService, UserService userService, FoodItemRepository foodItemRepository) {
        this.recipeService = recipeService;
        this.userService = userService;
        this.foodItemRepository = foodItemRepository;
    }

    @GetMapping
    public String listRecipes(
            @RequestParam(value = "search", required = false) String search,
            @RequestParam(value = "category", required = false) String category,
            @RequestParam(value = "tab", required = false, defaultValue = "all") String tab,
            @RequestParam(value = "openGenerator", required = false, defaultValue = "false") boolean openGenerator,
            Model model
    ) {
        User user = userService.getCurrentUser();
        List<Recipe> recipes = recipeService.getFilteredRecipesForUser(user, search, category, tab);
        List<FoodItem> inventoryItems = foodItemRepository.findByUserIdOrderByExpiryDateAsc(user.getId());
        List<String> categories = recipeService.getDistinctCategories();

        long totalCount = recipeService.getAllRecipes().size();
        long stockCount = recipeService.getFilteredRecipesForUser(user, null, null, "stock").size();
        long expiringCount = recipeService.getFilteredRecipesForUser(user, null, null, "expiring").size();
        long customCount = recipeService.getFilteredRecipesForUser(user, null, null, "custom").size();

        model.addAttribute("user", user);
        model.addAttribute("recipes", recipes);
        model.addAttribute("search", search);
        model.addAttribute("selectedCategory", category);
        model.addAttribute("activeTab", tab);
        model.addAttribute("categories", categories);
        model.addAttribute("inventoryItems", inventoryItems);
        model.addAttribute("totalCount", totalCount);
        model.addAttribute("stockCount", stockCount);
        model.addAttribute("expiringCount", expiringCount);
        model.addAttribute("customCount", customCount);
        model.addAttribute("openGenerator", openGenerator);
        return "recipes/list";
    }

    @GetMapping("/{id}")
    public String recipeDetail(@PathVariable("id") Long id, Model model) {
        User user = userService.getCurrentUser();
        Recipe recipe = recipeService.getRecipeByIdWithUserStock(id, user);

        model.addAttribute("user", user);
        model.addAttribute("recipe", recipe);
        return "recipes/detail";
    }

    @PostMapping("/generate")
    public String generateRecipe(
            @RequestParam(value = "selectedItems", required = false) List<Long> selectedItems,
            @RequestParam(value = "customIngredients", required = false) String customIngredients,
            @RequestParam(value = "category", required = false) String category,
            @RequestParam(value = "prepTime", required = false, defaultValue = "20") Integer prepTime,
            @RequestParam(value = "cookingStyle", required = false, defaultValue = "Savory & Quick") String cookingStyle,
            @RequestParam(value = "dietary", required = false) String dietary,
            RedirectAttributes redirectAttributes
    ) {
        User user = userService.getCurrentUser();
        Recipe recipe = recipeService.generateRecipe(user, selectedItems, customIngredients, category, prepTime, cookingStyle, dietary);
        redirectAttributes.addFlashAttribute("successMessage",
                "✨ Successfully generated recipe \"" + recipe.getTitle() + "\"! Saved to your collection.");
        return "redirect:/recipes/" + recipe.getId();
    }

    @PostMapping("/create")
    public String createRecipe(
            @RequestParam("title") String title,
            @RequestParam("description") String description,
            @RequestParam("category") String category,
            @RequestParam("prepTimeMinutes") int prepTimeMinutes,
            @RequestParam("ingredientsText") String ingredientsText,
            @RequestParam("instructions") String instructions,
            @RequestParam(value = "imageUrl", required = false) String imageUrl,
            RedirectAttributes redirectAttributes
    ) {
        User user = userService.getCurrentUser();
        Recipe recipe = new Recipe(title, description, category, prepTimeMinutes, ingredientsText, instructions, imageUrl);
        Recipe saved = recipeService.saveCustomRecipe(recipe, user);
        redirectAttributes.addFlashAttribute("successMessage", "Custom recipe \"" + saved.getTitle() + "\" created successfully!");
        return "redirect:/recipes/" + saved.getId();
    }

    @PostMapping("/delete/{id}")
    public String deleteRecipe(@PathVariable("id") Long id, RedirectAttributes redirectAttributes) {
        User user = userService.getCurrentUser();
        try {
            recipeService.deleteRecipe(id, user);
            redirectAttributes.addFlashAttribute("successMessage", "Recipe successfully deleted.");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("errorMessage", e.getMessage());
        }
        return "redirect:/recipes";
    }
}
