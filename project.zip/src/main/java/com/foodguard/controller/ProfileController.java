package com.foodguard.controller;

import com.foodguard.dto.DashboardSummaryDto;
import com.foodguard.dto.PasswordChangeDto;
import com.foodguard.dto.ProfileUpdateDto;
import com.foodguard.entity.User;
import com.foodguard.service.AnalyticsService;
import com.foodguard.service.UserService;
import jakarta.validation.Valid;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.time.format.DateTimeFormatter;

@Controller
@RequestMapping("/profile")
public class ProfileController {

    private final UserService userService;
    private final AnalyticsService analyticsService;

    public ProfileController(UserService userService, AnalyticsService analyticsService) {
        this.userService = userService;
        this.analyticsService = analyticsService;
    }

    private void populateOfficialProfileAttributes(Model model, User user) {
        String officialId = String.format("FG-IND-%06d", user.getId());
        DateTimeFormatter fullFormatter = DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss");
        DateTimeFormatter shortFormatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");

        String formattedJoinedDate = user.getCreatedAt() != null ? user.getCreatedAt().format(fullFormatter) : "05-10-2026 12:00:00";
        String formattedJoinedShort = user.getCreatedAt() != null ? user.getCreatedAt().format(shortFormatter) : "05-10-2026";
        String formattedUpdatedDate = user.getUpdatedAt() != null ? user.getUpdatedAt().format(fullFormatter) : formattedJoinedDate;

        DashboardSummaryDto summary = analyticsService.getDashboardSummary(user);

        model.addAttribute("officialId", officialId);
        model.addAttribute("formattedJoinedDate", formattedJoinedDate);
        model.addAttribute("formattedJoinedShort", formattedJoinedShort);
        model.addAttribute("formattedUpdatedDate", formattedUpdatedDate);
        model.addAttribute("summary", summary);
        model.addAttribute("officialRoleTitle", "Primary Household Administrator");
        model.addAttribute("securityLevel", "Level-3 Enterprise Shield (BCrypt-256)");
        model.addAttribute("officialStatus", "VERIFIED & ACTIVE");
        model.addAttribute("regionalZone", "Asia/Kolkata (IST, UTC+05:30)");
        model.addAttribute("officialCurrency", "INR – Indian Rupee (₹)");
    }

    @GetMapping
    public String showProfile(Model model) {
        User user = userService.getCurrentUser();
        ProfileUpdateDto profileDto = new ProfileUpdateDto(user.getFullName(), user.getAlertDaysBefore(), user.isEmailAlertsEnabled());

        model.addAttribute("user", user);
        model.addAttribute("profileDto", profileDto);
        model.addAttribute("passwordDto", new PasswordChangeDto());
        populateOfficialProfileAttributes(model, user);
        return "profile/index";
    }

    @PostMapping("/update")
    public String updateProfile(
            @Valid @ModelAttribute("profileDto") ProfileUpdateDto profileDto,
            BindingResult bindingResult,
            RedirectAttributes redirectAttributes,
            Model model
    ) {
        User user = userService.getCurrentUser();

        if (bindingResult.hasErrors()) {
            model.addAttribute("user", user);
            model.addAttribute("passwordDto", new PasswordChangeDto());
            populateOfficialProfileAttributes(model, user);
            return "profile/index";
        }

        userService.updateProfile(user, profileDto);
        redirectAttributes.addFlashAttribute("successMessage", "Profile preferences updated successfully.");
        return "redirect:/profile";
    }

    @PostMapping("/change-password")
    public String changePassword(
            @Valid @ModelAttribute("passwordDto") PasswordChangeDto passwordDto,
            BindingResult bindingResult,
            RedirectAttributes redirectAttributes,
            Model model
    ) {
        User user = userService.getCurrentUser();

        if (!passwordDto.getNewPassword().equals(passwordDto.getConfirmPassword())) {
            bindingResult.rejectValue("confirmPassword", "error.passwordDto", "New passwords do not match.");
        }

        if (bindingResult.hasErrors()) {
            ProfileUpdateDto profileDto = new ProfileUpdateDto(user.getFullName(), user.getAlertDaysBefore(), user.isEmailAlertsEnabled());
            model.addAttribute("user", user);
            model.addAttribute("profileDto", profileDto);
            populateOfficialProfileAttributes(model, user);
            return "profile/index";
        }

        try {
            userService.changePassword(user, passwordDto);
            redirectAttributes.addFlashAttribute("successMessage", "Your password has been changed successfully.");
        } catch (IllegalArgumentException e) {
            redirectAttributes.addFlashAttribute("errorMessage", e.getMessage());
        }

        return "redirect:/profile";
    }
}
