package com.foodguard.controller;

import com.foodguard.dto.FoodActionDto;
import com.foodguard.dto.FoodItemDto;
import com.foodguard.entity.ActionType;
import com.foodguard.entity.FoodCategory;
import com.foodguard.entity.FoodItem;
import com.foodguard.entity.StorageLocation;
import com.foodguard.entity.User;
import com.foodguard.service.FoodItemService;
import com.foodguard.service.UserService;
import jakarta.validation.Valid;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/inventory")
public class InventoryController {

    private final FoodItemService foodItemService;
    private final UserService userService;

    public InventoryController(FoodItemService foodItemService, UserService userService) {
        this.foodItemService = foodItemService;
        this.userService = userService;
    }

    @GetMapping
    public String listInventory(
            @RequestParam(value = "keyword", required = false) String keyword,
            @RequestParam(value = "category", required = false) FoodCategory category,
            @RequestParam(value = "location", required = false) StorageLocation location,
            @RequestParam(value = "status", required = false, defaultValue = "ALL") String status,
            @RequestParam(value = "page", required = false, defaultValue = "0") int page,
            @RequestParam(value = "size", required = false, defaultValue = "10") int size,
            @RequestParam(value = "sortField", required = false, defaultValue = "expiryDate") String sortField,
            @RequestParam(value = "sortDir", required = false, defaultValue = "asc") String sortDir,
            Model model
    ) {
        User user = userService.getCurrentUser();
        Page<FoodItem> itemsPage = foodItemService.getUserItems(
                user, keyword, category, location, status, page, size, sortField, sortDir
        );

        model.addAttribute("user", user);
        model.addAttribute("itemsPage", itemsPage);
        model.addAttribute("items", itemsPage.getContent());
        model.addAttribute("currentPage", page);
        model.addAttribute("totalPages", itemsPage.getTotalPages());
        model.addAttribute("totalItems", itemsPage.getTotalElements());

        model.addAttribute("keyword", keyword);
        model.addAttribute("selectedCategory", category);
        model.addAttribute("selectedLocation", location);
        model.addAttribute("selectedStatus", status);
        model.addAttribute("sortField", sortField);
        model.addAttribute("sortDir", sortDir);
        model.addAttribute("reverseSortDir", sortDir.equalsIgnoreCase("asc") ? "desc" : "asc");

        model.addAttribute("categories", FoodCategory.values());
        model.addAttribute("locations", StorageLocation.values());
        model.addAttribute("actionDto", new FoodActionDto());
        model.addAttribute("actionTypes", ActionType.values());

        return "inventory/list";
    }

    @GetMapping("/add")
    public String showAddForm(Model model) {
        User user = userService.getCurrentUser();
        model.addAttribute("user", user);
        model.addAttribute("foodItemDto", new FoodItemDto());
        model.addAttribute("categories", FoodCategory.values());
        model.addAttribute("locations", StorageLocation.values());
        model.addAttribute("isEdit", false);
        return "inventory/form";
    }

    @PostMapping("/add")
    public String addItem(
            @Valid @ModelAttribute("foodItemDto") FoodItemDto foodItemDto,
            BindingResult bindingResult,
            RedirectAttributes redirectAttributes,
            Model model
    ) {
        User user = userService.getCurrentUser();

        if (foodItemDto.getExpiryDate() != null && foodItemDto.getPurchaseDate() != null
                && foodItemDto.getExpiryDate().isBefore(foodItemDto.getPurchaseDate())) {
            bindingResult.rejectValue("expiryDate", "error.foodItemDto", "Expiry date cannot be before purchase date.");
        }

        if (bindingResult.hasErrors()) {
            model.addAttribute("user", user);
            model.addAttribute("categories", FoodCategory.values());
            model.addAttribute("locations", StorageLocation.values());
            model.addAttribute("isEdit", false);
            return "inventory/form";
        }

        foodItemService.createItem(foodItemDto, user);
        redirectAttributes.addFlashAttribute("successMessage", "'" + foodItemDto.getName() + "' added to your inventory!");
        return "redirect:/inventory";
    }

    @GetMapping("/edit/{id}")
    public String showEditForm(@PathVariable("id") Long id, Model model) {
        User user = userService.getCurrentUser();
        FoodItem item = foodItemService.getItemByIdAndUser(id, user);
        FoodItemDto dto = foodItemService.convertToDto(item);

        model.addAttribute("user", user);
        model.addAttribute("foodItemDto", dto);
        model.addAttribute("categories", FoodCategory.values());
        model.addAttribute("locations", StorageLocation.values());
        model.addAttribute("isEdit", true);
        model.addAttribute("itemId", id);
        return "inventory/form";
    }

    @PostMapping("/edit/{id}")
    public String updateItem(
            @PathVariable("id") Long id,
            @Valid @ModelAttribute("foodItemDto") FoodItemDto foodItemDto,
            BindingResult bindingResult,
            RedirectAttributes redirectAttributes,
            Model model
    ) {
        User user = userService.getCurrentUser();

        if (foodItemDto.getExpiryDate() != null && foodItemDto.getPurchaseDate() != null
                && foodItemDto.getExpiryDate().isBefore(foodItemDto.getPurchaseDate())) {
            bindingResult.rejectValue("expiryDate", "error.foodItemDto", "Expiry date cannot be before purchase date.");
        }

        if (bindingResult.hasErrors()) {
            model.addAttribute("user", user);
            model.addAttribute("categories", FoodCategory.values());
            model.addAttribute("locations", StorageLocation.values());
            model.addAttribute("isEdit", true);
            model.addAttribute("itemId", id);
            return "inventory/form";
        }

        foodItemService.updateItem(id, foodItemDto, user);
        redirectAttributes.addFlashAttribute("successMessage", "'" + foodItemDto.getName() + "' successfully updated!");
        return "redirect:/inventory";
    }

    @PostMapping("/delete/{id}")
    public String deleteItem(@PathVariable("id") Long id, RedirectAttributes redirectAttributes) {
        User user = userService.getCurrentUser();
        FoodItem item = foodItemService.getItemByIdAndUser(id, user);
        String itemName = item.getName();
        foodItemService.deleteItem(id, user);
        redirectAttributes.addFlashAttribute("successMessage", "'" + itemName + "' was removed from inventory.");
        return "redirect:/inventory";
    }
}
