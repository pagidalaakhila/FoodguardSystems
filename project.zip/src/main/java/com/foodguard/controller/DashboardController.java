package com.foodguard.controller;

import com.foodguard.dto.DashboardSummaryDto;
import com.foodguard.dto.FoodActionDto;
import com.foodguard.entity.ActionType;
import com.foodguard.entity.FoodItem;
import com.foodguard.entity.User;
import com.foodguard.service.*;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.List;

@Controller
public class DashboardController {

    private final UserService userService;
    private final AnalyticsService analyticsService;
    private final FoodItemService foodItemService;
    private final FoodActionService foodActionService;
    private final NotificationService notificationService;
    private final RecipeService recipeService;

    public DashboardController(UserService userService,
                               AnalyticsService analyticsService,
                               FoodItemService foodItemService,
                               FoodActionService foodActionService,
                               NotificationService notificationService,
                               RecipeService recipeService) {
        this.userService = userService;
        this.analyticsService = analyticsService;
        this.foodItemService = foodItemService;
        this.foodActionService = foodActionService;
        this.notificationService = notificationService;
        this.recipeService = recipeService;
    }

    @GetMapping("/dashboard")
    public String dashboard(Model model) {
        User user = userService.getCurrentUser();
        DashboardSummaryDto summary = analyticsService.getDashboardSummary(user);
        List<FoodItem> expiringSoon = foodItemService.getExpiringSoonItems(user);
        var recentActions = foodActionService.getUserActions(user, null, null, 0, 5);
        var recentNotifications = notificationService.getRecentNotifications(user);
        long unreadCount = notificationService.getUnreadCount(user);
        var suggestedRecipes = recipeService.getSuggestedRecipesForUser(user);

        model.addAttribute("user", user);
        model.addAttribute("summary", summary);
        model.addAttribute("expiringSoonItems", expiringSoon);
        model.addAttribute("recentActions", recentActions.getContent());
        model.addAttribute("recentNotifications", recentNotifications);
        model.addAttribute("unreadNotificationsCount", unreadCount);
        model.addAttribute("suggestedRecipes", suggestedRecipes.stream().limit(3).toList());
        model.addAttribute("actionDto", new FoodActionDto());
        model.addAttribute("actionTypes", ActionType.values());

        return "dashboard/index";
    }
}
