package com.foodguard.controller;

import com.foodguard.dto.DashboardSummaryDto;
import com.foodguard.entity.*;
import com.foodguard.repository.*;
import com.foodguard.service.*;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

@Controller
@RequestMapping("/reports")
public class ReportController {

    private final UserService userService;
    private final AnalyticsService analyticsService;
    private final FoodItemRepository foodItemRepository;
    private final FoodPreparationRepository preparationRepository;
    private final FoodConsumptionRepository consumptionRepository;
    private final FoodWasteRepository wasteRepository;
    private final FoodDonationRepository donationRepository;

    public ReportController(UserService userService,
                            AnalyticsService analyticsService,
                            FoodItemRepository foodItemRepository,
                            FoodPreparationRepository preparationRepository,
                            FoodConsumptionRepository consumptionRepository,
                            FoodWasteRepository wasteRepository,
                            FoodDonationRepository donationRepository) {
        this.userService = userService;
        this.analyticsService = analyticsService;
        this.foodItemRepository = foodItemRepository;
        this.preparationRepository = preparationRepository;
        this.consumptionRepository = consumptionRepository;
        this.wasteRepository = wasteRepository;
        this.donationRepository = donationRepository;
    }

    @GetMapping
    public String index(
            @RequestParam(value = "tab", defaultValue = "overview") String tab,
            Model model
    ) {
        User user = userService.getCurrentUser();
        DashboardSummaryDto summary = analyticsService.getDashboardSummary(user);

        List<FoodPreparation> preparations = preparationRepository.findByUserIdOrderByPrepDateDescIdDesc(user.getId());
        List<FoodConsumption> consumptions = consumptionRepository.findByUserIdOrderByConsumptionTimeDesc(user.getId());
        List<FoodWaste> wasteList = wasteRepository.findByUserIdOrderByWasteDateDesc(user.getId());
        List<FoodDonation> donations = donationRepository.findByRestaurantUserIdOrderByCreatedAtDesc(user.getId());
        List<FoodItem> inventory = foodItemRepository.findByUserIdOrderByExpiryDateAsc(user.getId());

        // Top KPIs
        BigDecimal totalPrepared = preparationRepository.sumTotalPreparedQuantity(user.getId());
        BigDecimal totalConsumed = consumptionRepository.sumTotalQuantitySold(user.getId());
        BigDecimal totalDonated = donationRepository.sumTotalWeightRescued(user.getId());
        BigDecimal totalWasted = wasteRepository.sumTotalQuantityWasted(user.getId());
        Long totalPeopleBenefited = donationRepository.sumTotalMealsRescued(user.getId());

        model.addAttribute("user", user);
        model.addAttribute("summary", summary);
        model.addAttribute("activeTab", tab);
        model.addAttribute("preparations", preparations);
        model.addAttribute("consumptions", consumptions);
        model.addAttribute("wasteList", wasteList);
        model.addAttribute("donations", donations);
        model.addAttribute("inventory", inventory);

        model.addAttribute("totalPrepared", totalPrepared != null ? totalPrepared : BigDecimal.ZERO);
        model.addAttribute("totalConsumed", totalConsumed != null ? totalConsumed : BigDecimal.ZERO);
        model.addAttribute("totalDonated", totalDonated != null ? totalDonated : BigDecimal.ZERO);
        model.addAttribute("totalWasted", totalWasted != null ? totalWasted : BigDecimal.ZERO);
        model.addAttribute("totalPeopleBenefited", totalPeopleBenefited != null ? totalPeopleBenefited : 0);

        return "reports/index";
    }
}
