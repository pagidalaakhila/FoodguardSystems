package com.foodguard.controller;

import com.foodguard.entity.User;
import com.foodguard.entity.UserRole;
import com.foodguard.repository.UserRepository;
import com.foodguard.service.UserService;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.List;

@Controller
@RequestMapping("/users")
public class UserController {

    private final UserRepository userRepository;
    private final UserService userService;
    private final PasswordEncoder passwordEncoder;

    public UserController(UserRepository userRepository, UserService userService, PasswordEncoder passwordEncoder) {
        this.userRepository = userRepository;
        this.userService = userService;
        this.passwordEncoder = passwordEncoder;
    }

    @GetMapping
    public String index(Model model) {
        User currentUser = userService.getCurrentUser();
        List<User> users = userRepository.findAll();

        model.addAttribute("currentUser", currentUser);
        model.addAttribute("users", users);
        model.addAttribute("roles", UserRole.values());

        return "users/index";
    }

    @PostMapping("/create")
    public String createUser(
            @RequestParam("fullName") String fullName,
            @RequestParam("email") String email,
            @RequestParam("password") String password,
            @RequestParam("role") String role,
            @RequestParam(value = "phoneNumber", required = false) String phoneNumber,
            @RequestParam(value = "restaurantName", required = false) String restaurantName,
            RedirectAttributes redirectAttributes
    ) {
        try {
            if (userRepository.findByEmail(email.toLowerCase().trim()).isPresent()) {
                redirectAttributes.addFlashAttribute("errorMessage", "A user with email " + email + " already exists!");
                return "redirect:/users";
            }

            User user = new User();
            user.setFullName(fullName.trim());
            user.setEmail(email.toLowerCase().trim());
            user.setPassword(passwordEncoder.encode(password));
            user.setRole(role);
            user.setPhoneNumber(phoneNumber != null ? phoneNumber : "+91 98450 11223");
            user.setRestaurantName(restaurantName != null ? restaurantName : "FoodGuard Grand Bistro");

            userRepository.save(user);
            redirectAttributes.addFlashAttribute("successMessage", "New staff account created for " + fullName + " (" + role + ")!");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("errorMessage", "Error creating user: " + e.getMessage());
        }
        return "redirect:/users";
    }
}
