package com.foodguard.controller;

import com.foodguard.entity.FoodConsumption;
import com.foodguard.entity.FoodPreparation;
import com.foodguard.entity.User;
import com.foodguard.repository.FoodConsumptionRepository;
import com.foodguard.service.PreparationService;
import com.foodguard.service.UserService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import java.math.BigDecimal;
import java.util.List;

@Controller
@RequestMapping("/consumption")
public class ConsumptionController {

    private final PreparationService preparationService;
    private final FoodConsumptionRepository consumptionRepository;
    private final UserService userService;

    public ConsumptionController(PreparationService preparationService,
                                 FoodConsumptionRepository consumptionRepository,
                                 UserService userService) {
        this.preparationService = preparationService;
        this.consumptionRepository = consumptionRepository;
        this.userService = userService;
    }

    @GetMapping
    public String index(Model model) {
        User user = userService.getCurrentUser();
        List<FoodPreparation> preparations = preparationService.getAllPreparations(user.getId());
        List<FoodConsumption> consumptions = consumptionRepository.findByUserIdOrderByConsumptionTimeDesc(user.getId());

        BigDecimal totalRevenue = consumptionRepository.sumTotalRevenue(user.getId());
        BigDecimal totalQtySold = consumptionRepository.sumTotalQuantitySold(user.getId());
        Long totalPortionsSold = consumptionRepository.sumTotalPortionsSold(user.getId());

        model.addAttribute("user", user);
        model.addAttribute("preparations", preparations);
        model.addAttribute("consumptions", consumptions);
        model.addAttribute("totalRevenue", totalRevenue != null ? totalRevenue : BigDecimal.ZERO);
        model.addAttribute("totalQtySold", totalQtySold != null ? totalQtySold : BigDecimal.ZERO);
        model.addAttribute("totalPortionsSold", totalPortionsSold != null ? totalPortionsSold : 0);

        return "consumption/index";
    }
}
