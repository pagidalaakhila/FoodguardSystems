package com.foodguard.controller;

import com.foodguard.entity.*;
import com.foodguard.repository.FoodItemRepository;
import com.foodguard.service.UserService;
import com.foodguard.service.WasteService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.math.BigDecimal;
import java.util.List;

@Controller
@RequestMapping("/waste")
public class WasteController {

    private final WasteService wasteService;
    private final FoodItemRepository foodItemRepository;
    private final UserService userService;

    public WasteController(WasteService wasteService,
                           FoodItemRepository foodItemRepository,
                           UserService userService) {
        this.wasteService = wasteService;
        this.foodItemRepository = foodItemRepository;
        this.userService = userService;
    }

    @GetMapping
    public String index(Model model) {
        User user = userService.getCurrentUser();
        List<FoodWaste> wasteRecords = wasteService.getAllWaste(user.getId());
        BigDecimal totalWastedQty = wasteService.getTotalQuantityWasted(user.getId());
        BigDecimal totalCostLoss = wasteService.getTotalCostLoss(user.getId());
        List<FoodItem> inventoryItems = foodItemRepository.findByUserIdOrderByExpiryDateAsc(user.getId());
        List<Object[]> reasonSummary = wasteService.getWasteSummaryByReason(user.getId());

        model.addAttribute("user", user);
        model.addAttribute("wasteRecords", wasteRecords);
        model.addAttribute("totalWastedQty", totalWastedQty != null ? totalWastedQty : BigDecimal.ZERO);
        model.addAttribute("totalCostLoss", totalCostLoss != null ? totalCostLoss : BigDecimal.ZERO);
        model.addAttribute("inventoryItems", inventoryItems);
        model.addAttribute("wasteReasons", WasteReason.values());
        model.addAttribute("categories", FoodCategory.values());
        model.addAttribute("reasonSummary", reasonSummary);

        return "waste/index";
    }

    @PostMapping("/record")
    public String recordWaste(
            @RequestParam(value = "foodItemId", required = false) Long foodItemId,
            @RequestParam("foodName") String foodName,
            @RequestParam("category") FoodCategory category,
            @RequestParam("quantityWasted") BigDecimal quantityWasted,
            @RequestParam(value = "unit", defaultValue = "kg") String unit,
            @RequestParam("reason") WasteReason reason,
            @RequestParam(value = "costPerUnit", defaultValue = "0.0") BigDecimal costPerUnit,
            @RequestParam(value = "notes", required = false) String notes,
            RedirectAttributes redirectAttributes
    ) {
        User user = userService.getCurrentUser();
        try {
            wasteService.recordWaste(user, foodItemId, foodName, category, quantityWasted, unit, reason, costPerUnit, notes);
            BigDecimal loss = quantityWasted.multiply(costPerUnit);
            redirectAttributes.addFlashAttribute("successMessage", "Logged " + quantityWasted + " " + unit + " of " + foodName + " to waste log. Cost loss: ₹" + loss);
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("errorMessage", "Error recording waste: " + e.getMessage());
        }
        return "redirect:/waste";
    }
}
