package com.foodguard.controller;

import com.foodguard.entity.FoodAction;
import com.foodguard.entity.FoodItem;
import com.foodguard.entity.User;
import com.foodguard.service.CsvExportService;
import com.foodguard.service.FoodActionService;
import com.foodguard.service.FoodItemService;
import com.foodguard.service.UserService;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

@Controller
@RequestMapping("/export")
public class ExportController {

    private final FoodItemService foodItemService;
    private final FoodActionService foodActionService;
    private final CsvExportService csvExportService;
    private final UserService userService;

    public ExportController(FoodItemService foodItemService,
                            FoodActionService foodActionService,
                            CsvExportService csvExportService,
                            UserService userService) {
        this.foodItemService = foodItemService;
        this.foodActionService = foodActionService;
        this.csvExportService = csvExportService;
        this.userService = userService;
    }

    @GetMapping("/inventory/csv")
    public void exportInventoryCsv(HttpServletResponse response) throws IOException {
        User user = userService.getCurrentUser();
        List<FoodItem> items = foodItemService.getAllUserItems(user);

        String filename = "foodguard-inventory-" + LocalDate.now().format(DateTimeFormatter.ofPattern("dd-MM-yyyy")) + ".csv";
        response.setContentType("text/csv; charset=UTF-8");
        response.setHeader("Content-Disposition", "attachment; filename=\"" + filename + "\"");

        csvExportService.exportInventoryToCsv(items, response.getWriter());
    }

    @GetMapping("/history/csv")
    public void exportHistoryCsv(HttpServletResponse response) throws IOException {
        User user = userService.getCurrentUser();
        List<FoodAction> actions = foodActionService.getAllUserActions(user);

        String filename = "foodguard-waste-history-" + LocalDate.now().format(DateTimeFormatter.ofPattern("dd-MM-yyyy")) + ".csv";
        response.setContentType("text/csv; charset=UTF-8");
        response.setHeader("Content-Disposition", "attachment; filename=\"" + filename + "\"");

        csvExportService.exportHistoryToCsv(actions, response.getWriter());
    }
}
