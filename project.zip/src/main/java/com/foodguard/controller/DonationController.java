package com.foodguard.controller;

import com.foodguard.entity.*;
import com.foodguard.repository.FoodItemRepository;
import com.foodguard.service.DonationService;
import com.foodguard.service.UserService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

@Controller
@RequestMapping("/donations")
public class DonationController {

    private final DonationService donationService;
    private final UserService userService;
    private final FoodItemRepository foodItemRepository;

    public DonationController(DonationService donationService,
                              UserService userService,
                              FoodItemRepository foodItemRepository) {
        this.donationService = donationService;
        this.userService = userService;
        this.foodItemRepository = foodItemRepository;
    }

    @GetMapping
    public String donationDashboard(
            @RequestParam(value = "tab", required = false, defaultValue = "available") String tab,
            @RequestParam(value = "openDonateModal", required = false, defaultValue = "false") boolean openDonateModal,
            Model model
    ) {
        User user = userService.getCurrentUser();
        List<FoodDonation> availableDonations = donationService.getAvailableDonations();
        List<FoodDonation> scheduledDonations = donationService.getScheduledDonations();
        List<FoodDonation> completedDonations = donationService.getCompletedDonations();
        List<Orphanage> orphanages = donationService.getAllOrphanages();
        List<FoodItem> inventoryItems = foodItemRepository.findByUserIdOrderByExpiryDateAsc(user.getId());
        Map<String, Object> metrics = donationService.getDonationMetrics();

        model.addAttribute("user", user);
        model.addAttribute("availableDonations", availableDonations);
        model.addAttribute("scheduledDonations", scheduledDonations);
        model.addAttribute("completedDonations", completedDonations);
        model.addAttribute("orphanages", orphanages);
        model.addAttribute("inventoryItems", inventoryItems);
        model.addAttribute("metrics", metrics);
        model.addAttribute("activeTab", tab);
        model.addAttribute("categories", FoodCategory.values());
        model.addAttribute("openDonateModal", openDonateModal);
        return "donations/index";
    }

    @GetMapping("/new")
    public String newDonationPage(
            @RequestParam(value = "foodItemId", required = false) Long foodItemId,
            Model model
    ) {
        User user = userService.getCurrentUser();
        FoodItem selectedItem = null;
        if (foodItemId != null) {
            selectedItem = foodItemRepository.findById(foodItemId).orElse(null);
        }

        List<FoodItem> inventoryItems = foodItemRepository.findByUserIdOrderByExpiryDateAsc(user.getId());
        List<Orphanage> orphanages = donationService.getAllOrphanages();

        model.addAttribute("user", user);
        model.addAttribute("selectedItem", selectedItem);
        model.addAttribute("inventoryItems", inventoryItems);
        model.addAttribute("categories", FoodCategory.values());
        model.addAttribute("orphanages", orphanages);
        return "donations/create";
    }

    @PostMapping("/create")
    public String createDonation(
            @RequestParam(value = "restaurantName", required = false) String restaurantName,
            @RequestParam(value = "restaurantPhone", required = false) String restaurantPhone,
            @RequestParam(value = "restaurantAddress", required = false) String restaurantAddress,
            @RequestParam(value = "foodItemId", required = false) Long foodItemId,
            @RequestParam("foodTitle") String foodTitle,
            @RequestParam("category") FoodCategory category,
            @RequestParam("quantity") BigDecimal quantity,
            @RequestParam(value = "unit", defaultValue = "kg") String unit,
            @RequestParam(value = "estimatedMeals", required = false) Integer estimatedMeals,
            @RequestParam(value = "foodCondition", required = false) String foodCondition,
            @RequestParam(value = "storageTemperature", required = false) String storageTemperature,
            @RequestParam(value = "consumeByHours", defaultValue = "6") Integer consumeByHours,
            @RequestParam(value = "costValue", required = false) BigDecimal costValue,
            @RequestParam(value = "notes", required = false) String notes,
            RedirectAttributes redirectAttributes
    ) {
        User user = userService.getCurrentUser();
        FoodDonation donation = donationService.createDonation(
                user,
                restaurantName,
                restaurantPhone,
                restaurantAddress,
                foodItemId,
                foodTitle,
                category,
                quantity,
                unit,
                estimatedMeals,
                foodCondition,
                storageTemperature,
                consumeByHours,
                costValue,
                notes
        );

        redirectAttributes.addFlashAttribute("successMessage",
                "🔔 Food donation \"" + donation.getFoodTitle() + "\" broadcasted to nearby registered orphanages! You will receive an alert as soon as pickup is confirmed.");
        return "redirect:/donations?tab=available";
    }

    @PostMapping("/{id}/accept")
    public String acceptDonation(
            @PathVariable("id") Long id,
            @RequestParam("orphanageId") Long orphanageId,
            @RequestParam("pickupTime") String pickupTime,
            @RequestParam(value = "pickupNotes", required = false) String pickupNotes,
            RedirectAttributes redirectAttributes
    ) {
        User user = userService.getCurrentUser();
        FoodDonation donation = donationService.acceptDonation(id, orphanageId, pickupTime, pickupNotes, user);
        redirectAttributes.addFlashAttribute("successMessage",
                "🚚 Pickup confirmed by " + donation.getClaimedByOrphanage().getName() + "! Scheduled arrival: " + donation.getPickupScheduledTime() + ". Keep packaging ready.");
        return "redirect:/donations?tab=scheduled";
    }

    @PostMapping("/{id}/collect")
    public String confirmCollection(
            @PathVariable("id") Long id,
            RedirectAttributes redirectAttributes
    ) {
        User user = userService.getCurrentUser();
        FoodDonation donation = donationService.confirmCollection(id, user);
        redirectAttributes.addFlashAttribute("successMessage",
                "🎉 Food collected successfully! Handover confirmed with " + donation.getClaimedByOrphanage().getName() + ". This donation is now permanently recorded in your Food Action History audit log.");
        return "redirect:/donations?tab=completed";
    }

    @GetMapping("/{id}")
    public String donationDetail(@PathVariable("id") Long id, Model model) {
        User user = userService.getCurrentUser();
        FoodDonation donation = donationService.getDonationById(id);
        List<Orphanage> orphanages = donationService.getAllOrphanages();

        model.addAttribute("user", user);
        model.addAttribute("donation", donation);
        model.addAttribute("orphanages", orphanages);
        return "donations/detail";
    }
}
