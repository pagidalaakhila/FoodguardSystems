package com.foodguard.controller;

import com.foodguard.dto.AnalyticsDto;
import com.foodguard.dto.DashboardSummaryDto;
import com.foodguard.entity.User;
import com.foodguard.service.AnalyticsService;
import com.foodguard.service.UserService;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class AnalyticsController {

    private final AnalyticsService analyticsService;
    private final UserService userService;

    public AnalyticsController(AnalyticsService analyticsService, UserService userService) {
        this.analyticsService = analyticsService;
        this.userService = userService;
    }

    @GetMapping("/analytics")
    public String showAnalytics(Model model) {
        User user = userService.getCurrentUser();
        DashboardSummaryDto summary = analyticsService.getDashboardSummary(user);
        AnalyticsDto analyticsDto = analyticsService.getAnalyticsData(user);

        model.addAttribute("user", user);
        model.addAttribute("summary", summary);
        model.addAttribute("analytics", analyticsDto);
        return "analytics/index";
    }

    @GetMapping("/api/analytics/data")
    @ResponseBody
    public ResponseEntity<AnalyticsDto> getAnalyticsApi() {
        User user = userService.getCurrentUser();
        AnalyticsDto dto = analyticsService.getAnalyticsData(user);
        return ResponseEntity.ok(dto);
    }
}
