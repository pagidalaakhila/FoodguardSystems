package com.foodguard.controller;

import com.foodguard.entity.FoodPreparation;
import com.foodguard.entity.User;
import com.foodguard.entity.WasteReason;
import com.foodguard.service.PreparationService;
import com.foodguard.service.UserService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.math.BigDecimal;
import java.util.List;

@Controller
@RequestMapping("/preparation")
public class PreparationController {

    private final PreparationService preparationService;
    private final UserService userService;

    public PreparationController(PreparationService preparationService, UserService userService) {
        this.preparationService = preparationService;
        this.userService = userService;
    }

    @GetMapping
    public String index(Model model) {
        User user = userService.getCurrentUser();
        List<FoodPreparation> preparations = preparationService.getAllPreparations(user.getId());

        // Calculate summary cards
        long totalPreparedPortions = preparations.stream().mapToLong(FoodPreparation::getPortionsPrepared).sum();
        long totalSoldPortions = preparations.stream().mapToLong(FoodPreparation::getPortionsSold).sum();
        long totalRemainingPortions = preparations.stream().mapToLong(FoodPreparation::getRemainingPortions).sum();
        long totalWastedPortions = preparations.stream().mapToLong(FoodPreparation::getPortionsWasted).sum();

        model.addAttribute("user", user);
        model.addAttribute("preparations", preparations);
        model.addAttribute("wasteReasons", WasteReason.values());
        model.addAttribute("totalPreparedPortions", totalPreparedPortions);
        model.addAttribute("totalSoldPortions", totalSoldPortions);
        model.addAttribute("totalRemainingPortions", totalRemainingPortions);
        model.addAttribute("totalWastedPortions", totalWastedPortions);

        return "preparation/index";
    }

    @PostMapping("/create")
    public String createPreparation(
            @RequestParam("foodName") String foodName,
            @RequestParam("ingredientsUsed") String ingredientsUsed,
            @RequestParam("quantityPrepared") BigDecimal quantityPrepared,
            @RequestParam(value = "unit", defaultValue = "kg") String unit,
            @RequestParam("portionsPrepared") int portionsPrepared,
            @RequestParam(value = "servingSizeGrams", defaultValue = "200.0") BigDecimal servingSizeGrams,
            @RequestParam(value = "prepTime", defaultValue = "11:30 AM") String prepTime,
            @RequestParam(value = "expectedShelfHours", defaultValue = "8") int expectedShelfHours,
            @RequestParam(value = "costPerPortion", defaultValue = "45.0") BigDecimal costPerPortion,
            @RequestParam(value = "sellingPricePerPortion", defaultValue = "180.0") BigDecimal sellingPricePerPortion,
            RedirectAttributes redirectAttributes
    ) {
        User user = userService.getCurrentUser();
        try {
            preparationService.createPreparation(user, foodName, ingredientsUsed, quantityPrepared, unit,
                    portionsPrepared, servingSizeGrams, prepTime, expectedShelfHours, costPerPortion, sellingPricePerPortion);
            redirectAttributes.addFlashAttribute("successMessage", "Fresh batch of " + foodName + " (" + portionsPrepared + " portions) recorded successfully!");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("errorMessage", "Error recording preparation: " + e.getMessage());
        }
        return "redirect:/preparation";
    }

    @PostMapping("/{id}/consume")
    public String recordConsumption(
            @PathVariable("id") Long id,
            @RequestParam("portionsSold") int portionsSold,
            @RequestParam(value = "orderType", defaultValue = "Dine-in") String orderType,
            @RequestParam(value = "revenue", required = false) BigDecimal revenue,
            @RequestParam(value = "notes", required = false) String notes,
            RedirectAttributes redirectAttributes
    ) {
        User user = userService.getCurrentUser();
        try {
            preparationService.recordConsumption(user, id, portionsSold, orderType, revenue, notes);
            redirectAttributes.addFlashAttribute("successMessage", "Recorded " + portionsSold + " portions sold/served!");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("errorMessage", "Error recording consumption: " + e.getMessage());
        }
        return "redirect:/preparation";
    }

    @PostMapping("/{id}/waste")
    public String recordWaste(
            @PathVariable("id") Long id,
            @RequestParam("portionsWasted") int portionsWasted,
            @RequestParam("reason") WasteReason reason,
            @RequestParam(value = "notes", required = false) String notes,
            RedirectAttributes redirectAttributes
    ) {
        User user = userService.getCurrentUser();
        try {
            preparationService.recordWasteFromPrep(user, id, portionsWasted, reason, notes);
            redirectAttributes.addFlashAttribute("successMessage", "Recorded " + portionsWasted + " portions discarded to waste log.");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("errorMessage", "Error logging waste: " + e.getMessage());
        }
        return "redirect:/preparation";
    }

    @PostMapping("/{id}/donate")
    public String recordDonation(
            @PathVariable("id") Long id,
            @RequestParam("portionsDonated") int portionsDonated,
            @RequestParam(value = "notes", required = false) String notes,
            RedirectAttributes redirectAttributes
    ) {
        User user = userService.getCurrentUser();
        try {
            preparationService.recordDonationFromPrep(user, id, portionsDonated, notes);
            redirectAttributes.addFlashAttribute("successMessage", "Recorded " + portionsDonated + " portions allocated to charity donation!");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("errorMessage", "Error recording donation: " + e.getMessage());
        }
        return "redirect:/preparation";
    }
}
