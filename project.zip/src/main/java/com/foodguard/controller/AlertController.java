package com.foodguard.controller;

import com.foodguard.entity.FoodItem;
import com.foodguard.entity.FoodPreparation;
import com.foodguard.entity.Notification;
import com.foodguard.entity.User;
import com.foodguard.repository.FoodItemRepository;
import com.foodguard.repository.FoodPreparationRepository;
import com.foodguard.service.NotificationService;
import com.foodguard.service.UserService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Controller
@RequestMapping("/alerts")
public class AlertController {

    private final UserService userService;
    private final FoodItemRepository foodItemRepository;
    private final FoodPreparationRepository preparationRepository;
    private final NotificationService notificationService;

    public AlertController(UserService userService,
                           FoodItemRepository foodItemRepository,
                           FoodPreparationRepository preparationRepository,
                           NotificationService notificationService) {
        this.userService = userService;
        this.foodItemRepository = foodItemRepository;
        this.preparationRepository = preparationRepository;
        this.notificationService = notificationService;
    }

    @GetMapping
    public String index(Model model) {
        User user = userService.getCurrentUser();
        LocalDate today = LocalDate.now();
        List<FoodItem> allItems = foodItemRepository.findByUserIdOrderByExpiryDateAsc(user.getId());

        List<FoodItem> expiringToday = new ArrayList<>();
        List<FoodItem> expiringTomorrow = new ArrayList<>();
        List<FoodItem> expiringIn3Days = new ArrayList<>();
        List<FoodItem> alreadyExpired = new ArrayList<>();
        List<FoodItem> lowStockItems = new ArrayList<>();

        for (FoodItem item : allItems) {
            long days = item.getDaysUntilExpiry();
            if (days < 0) {
                alreadyExpired.add(item);
            } else if (days == 0) {
                expiringToday.add(item);
            } else if (days == 1) {
                expiringTomorrow.add(item);
            } else if (days <= 3) {
                expiringIn3Days.add(item);
            }

            if (item.isLowStock()) {
                lowStockItems.add(item);
            }
        }

        // Prepared food approaching deadline (expiring within 4 hours or already expired)
        List<FoodPreparation> preps = preparationRepository.findByUserIdOrderByPrepDateDescIdDesc(user.getId());
        List<FoodPreparation> criticalPreps = new ArrayList<>();
        for (FoodPreparation p : preps) {
            if (p.getRemainingPortions() > 0) {
                if (p.getExpiryDateTime().isBefore(LocalDateTime.now()) || p.getHoursUntilExpiry() <= 4) {
                    criticalPreps.add(p);
                }
            }
        }

        List<Notification> systemAlerts = notificationService.getRecentNotifications(user);

        model.addAttribute("user", user);
        model.addAttribute("expiringToday", expiringToday);
        model.addAttribute("expiringTomorrow", expiringTomorrow);
        model.addAttribute("expiringIn3Days", expiringIn3Days);
        model.addAttribute("alreadyExpired", alreadyExpired);
        model.addAttribute("lowStockItems", lowStockItems);
        model.addAttribute("criticalPreps", criticalPreps);
        model.addAttribute("systemAlerts", systemAlerts);

        return "alerts/index";
    }
}
