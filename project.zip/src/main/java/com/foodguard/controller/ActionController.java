package com.foodguard.controller;

import com.foodguard.dto.FoodActionDto;
import com.foodguard.entity.ActionType;
import com.foodguard.entity.FoodAction;
import com.foodguard.entity.User;
import com.foodguard.service.AnalyticsService;
import com.foodguard.service.FoodActionService;
import com.foodguard.service.UserService;
import jakarta.validation.Valid;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.foodguard.entity.FoodItem;
import com.foodguard.repository.FoodItemRepository;
import java.util.Optional;

@Controller
public class ActionController {

    private final FoodActionService foodActionService;
    private final UserService userService;
    private final AnalyticsService analyticsService;
    private final FoodItemRepository foodItemRepository;

    public ActionController(FoodActionService foodActionService, UserService userService,
                            AnalyticsService analyticsService, FoodItemRepository foodItemRepository) {
        this.foodActionService = foodActionService;
        this.userService = userService;
        this.analyticsService = analyticsService;
        this.foodItemRepository = foodItemRepository;
    }

    @PostMapping("/actions/log")
    public String logAction(
            @Valid @ModelAttribute("actionDto") FoodActionDto actionDto,
            BindingResult bindingResult,
            @RequestParam(value = "redirectUri", required = false, defaultValue = "/inventory") String redirectUri,
            RedirectAttributes redirectAttributes
    ) {
        User user = userService.getCurrentUser();

        if (bindingResult.hasErrors()) {
            redirectAttributes.addFlashAttribute("errorMessage", "Invalid action details. Please provide a valid quantity.");
            return "redirect:" + redirectUri;
        }

        try {
            FoodAction action = foodActionService.logAction(actionDto, user);
            Optional<FoodItem> remainingOpt = foodItemRepository.findById(actionDto.getFoodItemId());
            String actionName = action.getActionType().getDisplayName();
            String message;

            if (remainingOpt.isPresent()) {
                FoodItem rem = remainingOpt.get();
                message = String.format("🍳 Kitchen Stock Updated: Successfully took %s %s of '%s' for %s. Remaining in stock: %s %s (Valued at ₹%.2f).",
                        action.getDisplayQuantity(), action.getUnit(), action.getItemName(), actionName.toLowerCase(),
                        rem.getDisplayQuantity(), rem.getUnit(), rem.getCost());
            } else {
                message = String.format("🍳 Kitchen Stock Updated: Successfully took all %s %s of '%s' for %s. Stock is now completely used.",
                        action.getDisplayQuantity(), action.getUnit(), action.getItemName(), actionName.toLowerCase());
            }

            redirectAttributes.addFlashAttribute("successMessage", message);
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("errorMessage", e.getMessage());
        }

        return "redirect:" + redirectUri;
    }

    @GetMapping("/history")
    public String viewHistory(
            @RequestParam(value = "type", required = false) ActionType type,
            @RequestParam(value = "keyword", required = false) String keyword,
            @RequestParam(value = "page", required = false, defaultValue = "0") int page,
            @RequestParam(value = "size", required = false, defaultValue = "10") int size,
            Model model
    ) {
        User user = userService.getCurrentUser();
        Page<FoodAction> actionsPage = foodActionService.getUserActions(user, type, keyword, page, size);
        var summary = analyticsService.getDashboardSummary(user);

        model.addAttribute("user", user);
        model.addAttribute("actionsPage", actionsPage);
        model.addAttribute("actions", actionsPage.getContent());
        model.addAttribute("currentPage", page);
        model.addAttribute("totalPages", actionsPage.getTotalPages());
        model.addAttribute("totalActions", actionsPage.getTotalElements());

        model.addAttribute("selectedType", type);
        model.addAttribute("keyword", keyword);
        model.addAttribute("actionTypes", ActionType.values());
        model.addAttribute("summary", summary);

        return "history/list";
    }
}
