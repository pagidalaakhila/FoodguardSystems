package com.foodguard.dto;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

public class AnalyticsDto {

    private List<String> monthlyLabels = new ArrayList<>();
    private List<Long> monthlyConsumed = new ArrayList<>();
    private List<Long> monthlyDonated = new ArrayList<>();
    private List<Long> monthlyWasted = new ArrayList<>();

    private List<String> categoryLabels = new ArrayList<>();
    private List<Long> categoryCounts = new ArrayList<>();

    private List<String> storageLabels = new ArrayList<>();
    private List<Long> storageCounts = new ArrayList<>();

    private BigDecimal totalMoneySaved = BigDecimal.ZERO;
    private BigDecimal totalMoneyLost = BigDecimal.ZERO;
    private double wasteReductionRate = 0.0;

    public AnalyticsDto() {
    }

    public List<String> getMonthlyLabels() {
        return monthlyLabels;
    }

    public void setMonthlyLabels(List<String> monthlyLabels) {
        this.monthlyLabels = monthlyLabels;
    }

    public List<Long> getMonthlyConsumed() {
        return monthlyConsumed;
    }

    public void setMonthlyConsumed(List<Long> monthlyConsumed) {
        this.monthlyConsumed = monthlyConsumed;
    }

    public List<Long> getMonthlyDonated() {
        return monthlyDonated;
    }

    public void setMonthlyDonated(List<Long> monthlyDonated) {
        this.monthlyDonated = monthlyDonated;
    }

    public List<Long> getMonthlyWasted() {
        return monthlyWasted;
    }

    public void setMonthlyWasted(List<Long> monthlyWasted) {
        this.monthlyWasted = monthlyWasted;
    }

    public List<String> getCategoryLabels() {
        return categoryLabels;
    }

    public void setCategoryLabels(List<String> categoryLabels) {
        this.categoryLabels = categoryLabels;
    }

    public List<Long> getCategoryCounts() {
        return categoryCounts;
    }

    public void setCategoryCounts(List<Long> categoryCounts) {
        this.categoryCounts = categoryCounts;
    }

    public List<String> getStorageLabels() {
        return storageLabels;
    }

    public void setStorageLabels(List<String> storageLabels) {
        this.storageLabels = storageLabels;
    }

    public List<Long> getStorageCounts() {
        return storageCounts;
    }

    public void setStorageCounts(List<Long> storageCounts) {
        this.storageCounts = storageCounts;
    }

    public BigDecimal getTotalMoneySaved() {
        return totalMoneySaved;
    }

    public void setTotalMoneySaved(BigDecimal totalMoneySaved) {
        this.totalMoneySaved = totalMoneySaved != null ? totalMoneySaved : BigDecimal.ZERO;
    }

    public BigDecimal getTotalMoneyLost() {
        return totalMoneyLost;
    }

    public void setTotalMoneyLost(BigDecimal totalMoneyLost) {
        this.totalMoneyLost = totalMoneyLost != null ? totalMoneyLost : BigDecimal.ZERO;
    }

    public double getWasteReductionRate() {
        return wasteReductionRate;
    }

    public void setWasteReductionRate(double wasteReductionRate) {
        this.wasteReductionRate = wasteReductionRate;
    }
}
