package com.foodguard.dto;

import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

public class ProfileUpdateDto {

    @NotBlank(message = "Full name is required")
    @Size(min = 2, max = 100, message = "Name must be between 2 and 100 characters")
    private String fullName;

    @Min(value = 1, message = "Alert threshold must be at least 1 day")
    @Max(value = 30, message = "Alert threshold cannot exceed 30 days")
    private int alertDaysBefore = 3;

    private boolean emailAlertsEnabled = false;

    public ProfileUpdateDto() {
    }

    public ProfileUpdateDto(String fullName, int alertDaysBefore, boolean emailAlertsEnabled) {
        this.fullName = fullName;
        this.alertDaysBefore = alertDaysBefore;
        this.emailAlertsEnabled = emailAlertsEnabled;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public int getAlertDaysBefore() {
        return alertDaysBefore;
    }

    public void setAlertDaysBefore(int alertDaysBefore) {
        this.alertDaysBefore = alertDaysBefore;
    }

    public boolean isEmailAlertsEnabled() {
        return emailAlertsEnabled;
    }

    public void setEmailAlertsEnabled(boolean emailAlertsEnabled) {
        this.emailAlertsEnabled = emailAlertsEnabled;
    }
}
