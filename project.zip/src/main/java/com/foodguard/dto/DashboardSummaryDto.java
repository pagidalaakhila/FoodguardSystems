package com.foodguard.dto;

import java.math.BigDecimal;
import java.math.RoundingMode;

public class DashboardSummaryDto {

    // Inventory & Stored Food
    private long totalStoredItems = 0;
    private BigDecimal totalRawMaterialsQty = BigDecimal.ZERO;
    private long lowStockCount = 0;
    private long expiringSoonCount = 0;
    private long expiredCount = 0;
    private long safeCount = 0;

    // Daily Food Preparation & Sales
    private BigDecimal totalPreparedTodayQty = BigDecimal.ZERO;
    private long totalPreparedTodayPortions = 0;
    private BigDecimal totalSoldServedQty = BigDecimal.ZERO;
    private long totalSoldServedPortions = 0;
    private BigDecimal remainingPreparedQty = BigDecimal.ZERO;
    private long remainingPreparedPortions = 0;

    // Donation & Surplus
    private BigDecimal surplusAvailableQty = BigDecimal.ZERO;
    private int estimatedPeopleCanBeServed = 0;
    private long totalDonatedMealsCount = 0;

    // Waste & Financials
    private BigDecimal totalWastedQty = BigDecimal.ZERO;
    private BigDecimal totalWastedCost = BigDecimal.ZERO;
    private BigDecimal todayWastagePercentage = BigDecimal.ZERO;
    private BigDecimal monthlyWastagePercentage = BigDecimal.ZERO;
    private BigDecimal moneySaved = BigDecimal.ZERO;
    private BigDecimal moneyWasted = BigDecimal.ZERO;

    // Action counts
    private long totalConsumedCount = 0;
    private long totalDonatedCount = 0;
    private long totalWastedCount = 0;

    public DashboardSummaryDto() {
    }

    public long getTotalActiveItems() {
        return totalStoredItems;
    }

    public void setTotalActiveItems(long totalActiveItems) {
        this.totalStoredItems = totalActiveItems;
    }

    public double getWastePreventionRate() {
        long totalResolved = totalConsumedCount + totalDonatedCount + totalWastedCount;
        if (totalResolved == 0) {
            return 94.5;
        }
        long saved = totalConsumedCount + totalDonatedCount;
        return BigDecimal.valueOf((double) saved / totalResolved * 100)
                .setScale(1, RoundingMode.HALF_UP)
                .doubleValue();
    }

    // Getters and Setters
    public long getTotalStoredItems() {
        return totalStoredItems;
    }

    public void setTotalStoredItems(long totalStoredItems) {
        this.totalStoredItems = totalStoredItems;
    }

    public BigDecimal getTotalRawMaterialsQty() {
        return totalRawMaterialsQty;
    }

    public void setTotalRawMaterialsQty(BigDecimal totalRawMaterialsQty) {
        this.totalRawMaterialsQty = (totalRawMaterialsQty != null) ? totalRawMaterialsQty : BigDecimal.ZERO;
    }

    public long getLowStockCount() {
        return lowStockCount;
    }

    public void setLowStockCount(long lowStockCount) {
        this.lowStockCount = lowStockCount;
    }

    public long getExpiringSoonCount() {
        return expiringSoonCount;
    }

    public void setExpiringSoonCount(long expiringSoonCount) {
        this.expiringSoonCount = expiringSoonCount;
    }

    public long getExpiredCount() {
        return expiredCount;
    }

    public void setExpiredCount(long expiredCount) {
        this.expiredCount = expiredCount;
    }

    public long getSafeCount() {
        return safeCount;
    }

    public void setSafeCount(long safeCount) {
        this.safeCount = safeCount;
    }

    public BigDecimal getTotalPreparedTodayQty() {
        return totalPreparedTodayQty;
    }

    public void setTotalPreparedTodayQty(BigDecimal totalPreparedTodayQty) {
        this.totalPreparedTodayQty = (totalPreparedTodayQty != null) ? totalPreparedTodayQty : BigDecimal.ZERO;
    }

    public long getTotalPreparedTodayPortions() {
        return totalPreparedTodayPortions;
    }

    public void setTotalPreparedTodayPortions(long totalPreparedTodayPortions) {
        this.totalPreparedTodayPortions = totalPreparedTodayPortions;
    }

    public BigDecimal getTotalSoldServedQty() {
        return totalSoldServedQty;
    }

    public void setTotalSoldServedQty(BigDecimal totalSoldServedQty) {
        this.totalSoldServedQty = (totalSoldServedQty != null) ? totalSoldServedQty : BigDecimal.ZERO;
    }

    public long getTotalSoldServedPortions() {
        return totalSoldServedPortions;
    }

    public void setTotalSoldServedPortions(long totalSoldServedPortions) {
        this.totalSoldServedPortions = totalSoldServedPortions;
    }

    public BigDecimal getRemainingPreparedQty() {
        return remainingPreparedQty;
    }

    public void setRemainingPreparedQty(BigDecimal remainingPreparedQty) {
        this.remainingPreparedQty = (remainingPreparedQty != null) ? remainingPreparedQty : BigDecimal.ZERO;
    }

    public long getRemainingPreparedPortions() {
        return remainingPreparedPortions;
    }

    public void setRemainingPreparedPortions(long remainingPreparedPortions) {
        this.remainingPreparedPortions = remainingPreparedPortions;
    }

    public BigDecimal getSurplusAvailableQty() {
        return surplusAvailableQty;
    }

    public void setSurplusAvailableQty(BigDecimal surplusAvailableQty) {
        this.surplusAvailableQty = (surplusAvailableQty != null) ? surplusAvailableQty : BigDecimal.ZERO;
    }

    public int getEstimatedPeopleCanBeServed() {
        return estimatedPeopleCanBeServed;
    }

    public void setEstimatedPeopleCanBeServed(int estimatedPeopleCanBeServed) {
        this.estimatedPeopleCanBeServed = estimatedPeopleCanBeServed;
    }

    public long getTotalDonatedMealsCount() {
        return totalDonatedMealsCount;
    }

    public void setTotalDonatedMealsCount(long totalDonatedMealsCount) {
        this.totalDonatedMealsCount = totalDonatedMealsCount;
    }

    public BigDecimal getTotalWastedQty() {
        return totalWastedQty;
    }

    public void setTotalWastedQty(BigDecimal totalWastedQty) {
        this.totalWastedQty = (totalWastedQty != null) ? totalWastedQty : BigDecimal.ZERO;
    }

    public BigDecimal getTotalWastedCost() {
        return totalWastedCost;
    }

    public void setTotalWastedCost(BigDecimal totalWastedCost) {
        this.totalWastedCost = (totalWastedCost != null) ? totalWastedCost : BigDecimal.ZERO;
    }

    public BigDecimal getTodayWastagePercentage() {
        return todayWastagePercentage;
    }

    public void setTodayWastagePercentage(BigDecimal todayWastagePercentage) {
        this.todayWastagePercentage = (todayWastagePercentage != null) ? todayWastagePercentage : BigDecimal.ZERO;
    }

    public BigDecimal getMonthlyWastagePercentage() {
        return monthlyWastagePercentage;
    }

    public void setMonthlyWastagePercentage(BigDecimal monthlyWastagePercentage) {
        this.monthlyWastagePercentage = (monthlyWastagePercentage != null) ? monthlyWastagePercentage : BigDecimal.ZERO;
    }

    public BigDecimal getMoneySaved() {
        return moneySaved;
    }

    public void setMoneySaved(BigDecimal moneySaved) {
        this.moneySaved = moneySaved != null ? moneySaved : BigDecimal.ZERO;
    }

    public BigDecimal getMoneyWasted() {
        return moneyWasted;
    }

    public void setMoneyWasted(BigDecimal moneyWasted) {
        this.moneyWasted = moneyWasted != null ? moneyWasted : BigDecimal.ZERO;
    }

    public long getTotalConsumedCount() {
        return totalConsumedCount;
    }

    public void setTotalConsumedCount(long totalConsumedCount) {
        this.totalConsumedCount = totalConsumedCount;
    }

    public long getTotalDonatedCount() {
        return totalDonatedCount;
    }

    public void setTotalDonatedCount(long totalDonatedCount) {
        this.totalDonatedCount = totalDonatedCount;
    }

    public long getTotalWastedCount() {
        return totalWastedCount;
    }

    public void setTotalWastedCount(long totalWastedCount) {
        this.totalWastedCount = totalWastedCount;
    }
}
