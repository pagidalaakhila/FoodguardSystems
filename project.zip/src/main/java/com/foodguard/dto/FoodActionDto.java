package com.foodguard.dto;

import com.foodguard.entity.ActionType;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotNull;
import java.math.BigDecimal;

public class FoodActionDto {

    @NotNull(message = "Food item ID is required")
    private Long foodItemId;

    @NotNull(message = "Action type is required")
    private ActionType actionType;

    @NotNull(message = "Quantity is required")
    @DecimalMin(value = "0.01", message = "Quantity must be greater than zero")
    private BigDecimal quantity;

    private String notes;

    public FoodActionDto() {
    }

    public FoodActionDto(Long foodItemId, ActionType actionType, BigDecimal quantity, String notes) {
        this.foodItemId = foodItemId;
        this.actionType = actionType;
        this.quantity = quantity;
        this.notes = notes;
    }

    public Long getFoodItemId() {
        return foodItemId;
    }

    public void setFoodItemId(Long foodItemId) {
        this.foodItemId = foodItemId;
    }

    public ActionType getActionType() {
        return actionType;
    }

    public void setActionType(ActionType actionType) {
        this.actionType = actionType;
    }

    public BigDecimal getQuantity() {
        return quantity;
    }

    public void setQuantity(BigDecimal quantity) {
        this.quantity = quantity;
    }

    public String getNotes() {
        return notes;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }
}
