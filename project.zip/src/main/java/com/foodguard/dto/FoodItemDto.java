package com.foodguard.dto;

import com.foodguard.entity.FoodCategory;
import com.foodguard.entity.StorageLocation;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import org.springframework.format.annotation.DateTimeFormat;

import java.math.BigDecimal;
import java.time.LocalDate;

public class FoodItemDto {

    private Long id;

    @NotBlank(message = "Item name is required")
    @Size(max = 120, message = "Item name cannot exceed 120 characters")
    private String name;

    @NotNull(message = "Please select a category")
    private FoodCategory category;

    @NotNull(message = "Quantity is required")
    @DecimalMin(value = "0.01", message = "Quantity must be greater than zero")
    private BigDecimal quantity;

    @NotBlank(message = "Unit of measurement is required")
    private String unit = "items";

    @NotNull(message = "Purchase date is required")
    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
    private LocalDate purchaseDate = LocalDate.now();

    @NotNull(message = "Expiry date is required")
    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
    private LocalDate expiryDate = LocalDate.now().plusDays(7);

    @NotNull(message = "Please select a storage location")
    private StorageLocation storageLocation = StorageLocation.FRIDGE;

    @DecimalMin(value = "0.00", message = "Cost cannot be negative")
    private BigDecimal cost = BigDecimal.ZERO;

    private String notes;

    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
    private LocalDate mfgDate;

    private BigDecimal currentAvailableQuantity;

    private BigDecimal minStockLevel = new BigDecimal("5.0");

    private String storageType = "Refrigerator";

    private String supplierName = "Metro Restaurant Supplies";

    public FoodItemDto() {
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public FoodCategory getCategory() {
        return category;
    }

    public void setCategory(FoodCategory category) {
        this.category = category;
    }

    public BigDecimal getQuantity() {
        return quantity;
    }

    public void setQuantity(BigDecimal quantity) {
        this.quantity = quantity;
    }

    public String getUnit() {
        return unit;
    }

    public void setUnit(String unit) {
        this.unit = unit;
    }

    public LocalDate getPurchaseDate() {
        return purchaseDate;
    }

    public void setPurchaseDate(LocalDate purchaseDate) {
        this.purchaseDate = purchaseDate;
    }

    public LocalDate getExpiryDate() {
        return expiryDate;
    }

    public void setExpiryDate(LocalDate expiryDate) {
        this.expiryDate = expiryDate;
    }

    public StorageLocation getStorageLocation() {
        return storageLocation;
    }

    public void setStorageLocation(StorageLocation storageLocation) {
        this.storageLocation = storageLocation;
    }

    public BigDecimal getCost() {
        return cost;
    }

    public void setCost(BigDecimal cost) {
        this.cost = cost;
    }

    public String getNotes() {
        return notes;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }

    public LocalDate getMfgDate() {
        return mfgDate != null ? mfgDate : purchaseDate;
    }

    public void setMfgDate(LocalDate mfgDate) {
        this.mfgDate = mfgDate;
    }

    public BigDecimal getCurrentAvailableQuantity() {
        return currentAvailableQuantity != null ? currentAvailableQuantity : quantity;
    }

    public void setCurrentAvailableQuantity(BigDecimal currentAvailableQuantity) {
        this.currentAvailableQuantity = currentAvailableQuantity;
    }

    public BigDecimal getMinStockLevel() {
        return minStockLevel != null ? minStockLevel : new BigDecimal("5.0");
    }

    public void setMinStockLevel(BigDecimal minStockLevel) {
        this.minStockLevel = minStockLevel;
    }

    public String getStorageType() {
        return storageType;
    }

    public void setStorageType(String storageType) {
        this.storageType = storageType;
    }

    public String getSupplierName() {
        return supplierName;
    }

    public void setSupplierName(String supplierName) {
        this.supplierName = supplierName;
    }
}
