package com.foodguard.util;

import com.foodguard.entity.*;
import com.foodguard.repository.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

@Component
public class SeedDataLoader implements CommandLineRunner {

    private static final Logger logger = LoggerFactory.getLogger(SeedDataLoader.class);

    private final UserRepository userRepository;
    private final FoodItemRepository foodItemRepository;
    private final FoodActionRepository foodActionRepository;
    private final NotificationRepository notificationRepository;
    private final RecipeRepository recipeRepository;
    private final OrphanageRepository orphanageRepository;
    private final FoodDonationRepository foodDonationRepository;
    private final FoodPreparationRepository foodPreparationRepository;
    private final FoodConsumptionRepository foodConsumptionRepository;
    private final FoodWasteRepository foodWasteRepository;
    private final SupplierRepository supplierRepository;
    private final PasswordEncoder passwordEncoder;

    public SeedDataLoader(UserRepository userRepository,
                          FoodItemRepository foodItemRepository,
                          FoodActionRepository foodActionRepository,
                          NotificationRepository notificationRepository,
                          RecipeRepository recipeRepository,
                          OrphanageRepository orphanageRepository,
                          FoodDonationRepository foodDonationRepository,
                          FoodPreparationRepository foodPreparationRepository,
                          FoodConsumptionRepository foodConsumptionRepository,
                          FoodWasteRepository foodWasteRepository,
                          SupplierRepository supplierRepository,
                          PasswordEncoder passwordEncoder) {
        this.userRepository = userRepository;
        this.foodItemRepository = foodItemRepository;
        this.foodActionRepository = foodActionRepository;
        this.notificationRepository = notificationRepository;
        this.recipeRepository = recipeRepository;
        this.orphanageRepository = orphanageRepository;
        this.foodDonationRepository = foodDonationRepository;
        this.foodPreparationRepository = foodPreparationRepository;
        this.foodConsumptionRepository = foodConsumptionRepository;
        this.foodWasteRepository = foodWasteRepository;
        this.supplierRepository = supplierRepository;
        this.passwordEncoder = passwordEncoder;
    }

    @Override
    public void run(String... args) {
        // 1. Seed Restaurant Users / Staff
        seedUsers();

        User alex = userRepository.findByEmail("alex@foodguard.com").orElse(null);
        if (alex != null) {
            // 2. Seed Suppliers
            seedSuppliers();

            // 3. Seed Restaurant Inventory Raw Materials
            seedInventoryItems(alex);

            // 4. Seed Daily Food Preparations
            seedPreparations(alex);

            // 5. Seed Food Consumptions
            seedConsumptions(alex);

            // 6. Seed Food Waste Records
            seedWaste(alex);

            // 7. Seed Nearby Registered Orphanages
            seedOrphanages();

            // 8. Seed Food Donations
            seedDonations(alex);

            // 9. Seed Expiry Notifications
            seedNotifications(alex);
        }

        // 10. Seed Recipes
        seedRecipes();
    }

    private void seedUsers() {
        if (userRepository.findByEmail("alex@foodguard.com").isEmpty()) {
            User alex = new User();
            alex.setEmail("alex@foodguard.com");
            alex.setPassword(passwordEncoder.encode("password123"));
            alex.setFullName("Chef Alex Mercer");
            alex.setRole("ROLE_ADMIN");
            alex.setRestaurantName("FoodGuard Grand Bistro");
            alex.setPhoneNumber("+91 98450 11223");
            alex.setAlertDaysBefore(3);
            alex.setEmailAlertsEnabled(true);
            userRepository.save(alex);
        } else {
            User alex = userRepository.findByEmail("alex@foodguard.com").get();
            alex.setRole("ROLE_ADMIN");
            alex.setRestaurantName("FoodGuard Grand Bistro");
            userRepository.save(alex);
        }

        if (userRepository.findByEmail("manager@foodguard.com").isEmpty()) {
            User manager = new User();
            manager.setEmail("manager@foodguard.com");
            manager.setPassword(passwordEncoder.encode("password123"));
            manager.setFullName("Elena Vance");
            manager.setRole("ROLE_RESTAURANT_MANAGER");
            manager.setRestaurantName("FoodGuard Grand Bistro");
            manager.setPhoneNumber("+91 98765 43210");
            userRepository.save(manager);
        }

        if (userRepository.findByEmail("kitchen@foodguard.com").isEmpty()) {
            User kitchen = new User();
            kitchen.setEmail("kitchen@foodguard.com");
            kitchen.setPassword(passwordEncoder.encode("password123"));
            kitchen.setFullName("Marco Rossi");
            kitchen.setRole("ROLE_KITCHEN_STAFF");
            kitchen.setRestaurantName("FoodGuard Grand Bistro");
            kitchen.setPhoneNumber("+91 98110 55443");
            userRepository.save(kitchen);
        }
    }

    private void seedSuppliers() {
        if (supplierRepository.count() == 0) {
            supplierRepository.save(new Supplier("Metro Food Supplies", "Ashok Kumar", "+91 98765 11001", "orders@metrofood.in", "Yard 12, APMC Market, Bangalore", "Dry Grains, Flours & Rice"));
            supplierRepository.save(new Supplier("Fresh Farms Poultry", "Suresh Gowda", "+91 98450 22002", "contact@freshfarms.in", "Poultry Complex, Hebbal, Bangalore", "Fresh Chicken & Eggs"));
            supplierRepository.save(new Supplier("Green Valley Organics", "Anita Rao", "+91 98220 33003", "sales@greenvalley.in", "Farm Gate 4, Nelamangala, Bangalore", "Fresh Vegetables & Greens"));
            supplierRepository.save(new Supplier("Amul Dairy Hub", "Ramesh Patel", "+91 98110 44004", "hub@amuldairy.in", "Dairy Circle, Bannerghatta Road, Bangalore", "Fresh Paneer, Milk & Butter"));
            supplierRepository.save(new Supplier("Fortune Edible Oils", "Kiran Shah", "+91 98330 55005", "distributor@fortuneoils.in", "Industrial Area, Peenya, Bangalore", "Refined Cooking Oil & Pure Ghee"));
            supplierRepository.save(new Supplier("Everest Spices Ltd", "Meera Nair", "+91 98990 66006", "spices@everest.in", "Commercial Street, Bangalore", "Whole & Ground Exotic Spices"));
            logger.info("Loaded restaurant supplier directory.");
        }
    }

    private void seedInventoryItems(User alex) {
        if (foodItemRepository.countByUserId(alex.getId()) == 0) {
            LocalDate today = LocalDate.now();

            // 1. Rice – 25 kg
            FoodItem rice = new FoodItem(alex, "Basmati Rice (A-Grade)", FoodCategory.PANTRY, new BigDecimal("25.00"), "kg",
                    today.minusDays(15), today.plusDays(180), StorageLocation.PANTRY, new BigDecimal("1850.00"), "Premium long grain basmati rice for biryanis and pulao");
            rice.setCurrentAvailableQuantity(new BigDecimal("22.00"));
            rice.setMinStockLevel(new BigDecimal("5.00"));
            rice.setStorageType("Dry Storage");
            rice.setSupplierName("Metro Food Supplies");
            foodItemRepository.save(rice);

            // 2. Chicken – 15 kg
            FoodItem chicken = new FoodItem(alex, "Fresh Chicken (Clean Cut)", FoodCategory.MEAT, new BigDecimal("15.00"), "kg",
                    today.minusDays(1), today.plusDays(2), StorageLocation.FRIDGE, new BigDecimal("3300.00"), "Fresh farm chicken delivered chilled");
            chicken.setCurrentAvailableQuantity(new BigDecimal("15.00"));
            chicken.setMinStockLevel(new BigDecimal("5.00"));
            chicken.setStorageType("Walk-in Chiller");
            chicken.setSupplierName("Fresh Farms Poultry");
            foodItemRepository.save(chicken);

            // 3. Vegetables – 20 kg
            FoodItem veg = new FoodItem(alex, "Assorted Farm Vegetables", FoodCategory.PRODUCE, new BigDecimal("20.00"), "kg",
                    today.minusDays(2), today.plusDays(3), StorageLocation.FRIDGE, new BigDecimal("900.00"), "Carrots, beans, capsicum, cauliflower, green peas");
            veg.setCurrentAvailableQuantity(new BigDecimal("18.00"));
            veg.setMinStockLevel(new BigDecimal("6.00"));
            veg.setStorageType("Walk-in Chiller");
            veg.setSupplierName("Green Valley Organics");
            foodItemRepository.save(veg);

            // 4. Paneer – 8 kg
            FoodItem paneer = new FoodItem(alex, "Fresh Malai Paneer Blocks", FoodCategory.DAIRY, new BigDecimal("8.00"), "kg",
                    today.minusDays(3), today.plusDays(2), StorageLocation.FRIDGE, new BigDecimal("2560.00"), "Soft fresh cottage cheese blocks for curries");
            paneer.setCurrentAvailableQuantity(new BigDecimal("8.00"));
            paneer.setMinStockLevel(new BigDecimal("3.00"));
            paneer.setStorageType("Refrigerator");
            paneer.setSupplierName("Amul Dairy Hub");
            foodItemRepository.save(paneer);

            // 5. Cooking Oil – 10 litres
            FoodItem oil = new FoodItem(alex, "Sunflower Cooking Oil", FoodCategory.PANTRY, new BigDecimal("10.00"), "litres",
                    today.minusDays(20), today.plusDays(120), StorageLocation.PANTRY, new BigDecimal("1400.00"), "Refined sunflower oil for deep frying and cooking");
            oil.setCurrentAvailableQuantity(new BigDecimal("10.00"));
            oil.setMinStockLevel(new BigDecimal("4.00"));
            oil.setStorageType("Dry Storage");
            oil.setSupplierName("Fortune Edible Oils");
            foodItemRepository.save(oil);

            // 6. Milk – 20 litres
            FoodItem milk = new FoodItem(alex, "Standardized Full Cream Milk", FoodCategory.DAIRY, new BigDecimal("20.00"), "litres",
                    today.minusDays(2), today.plusDays(1), StorageLocation.FRIDGE, new BigDecimal("1100.00"), "Fresh pasteurized full cream milk for tea, coffee & desserts");
            milk.setCurrentAvailableQuantity(new BigDecimal("20.00"));
            milk.setMinStockLevel(new BigDecimal("5.00"));
            milk.setStorageType("Refrigerator");
            milk.setSupplierName("Amul Dairy Hub");
            foodItemRepository.save(milk);

            // 7. Eggs – 120 pieces
            FoodItem eggs = new FoodItem(alex, "Farm Fresh Table Eggs", FoodCategory.DAIRY, new BigDecimal("120.00"), "pieces",
                    today.minusDays(5), today.plusDays(15), StorageLocation.FRIDGE, new BigDecimal("840.00"), "Farm graded white table eggs crate");
            eggs.setCurrentAvailableQuantity(new BigDecimal("110.00"));
            eggs.setMinStockLevel(new BigDecimal("30.00"));
            eggs.setStorageType("Refrigerator");
            eggs.setSupplierName("Fresh Farms Poultry");
            foodItemRepository.save(eggs);

            // 8. Flour – 25 kg
            FoodItem flour = new FoodItem(alex, "Chakki Fresh Atta & Maida", FoodCategory.PANTRY, new BigDecimal("25.00"), "kg",
                    today.minusDays(10), today.plusDays(90), StorageLocation.PANTRY, new BigDecimal("875.00"), "Whole wheat atta and all-purpose flour for rotis and naans");
            flour.setCurrentAvailableQuantity(new BigDecimal("25.00"));
            flour.setMinStockLevel(new BigDecimal("5.00"));
            flour.setStorageType("Dry Storage");
            flour.setSupplierName("Metro Food Supplies");
            foodItemRepository.save(flour);

            // 9. Spices – 5 kg
            FoodItem spices = new FoodItem(alex, "Whole Garam Masala & Spices", FoodCategory.PANTRY, new BigDecimal("5.00"), "kg",
                    today.minusDays(30), today.plusDays(60), StorageLocation.PANTRY, new BigDecimal("1800.00"), "Cardamom, cloves, cinnamon, star anise, cumin");
            spices.setCurrentAvailableQuantity(new BigDecimal("2.50")); // Trigger LOW_STOCK!
            spices.setMinStockLevel(new BigDecimal("3.00"));
            spices.setStorageType("Dry Storage");
            spices.setSupplierName("Everest Spices Ltd");
            foodItemRepository.save(spices);

            logger.info("Loaded realistic restaurant inventory raw materials for Alex.");
        }
    }

    private void seedPreparations(User alex) {
        if (foodPreparationRepository.count() == 0) {
            LocalDate today = LocalDate.now();

            // 1. Chicken Biryani (20 kg, 100 portions, 75 sold, 25 remaining)
            FoodPreparation biryani = new FoodPreparation(alex, today, "Hyderabadi Chicken Dum Biryani",
                    "Basmati Rice (8 kg), Chicken (10 kg), Pure Ghee (1 kg), Fried Onions, Saffron, Spices",
                    new BigDecimal("20.00"), "kg", 100, new BigDecimal("200.00"), "11:30 AM", 8,
                    new BigDecimal("65.00"), new BigDecimal("280.00"));
            biryani.setPortionsSold(75);
            biryani.recalculate();
            foodPreparationRepository.save(biryani);

            // 2. Butter Chicken (12 kg, 60 portions, 45 sold, 15 remaining)
            FoodPreparation butterChicken = new FoodPreparation(alex, today, "Smoky Murgh Makhani (Butter Chicken)",
                    "Tandoori Chicken (8 kg), Tomato Gravy, Butter, Cream, Kasuri Methi",
                    new BigDecimal("12.00"), "kg", 60, new BigDecimal("200.00"), "11:45 AM", 8,
                    new BigDecimal("70.00"), new BigDecimal("320.00"));
            butterChicken.setPortionsSold(45);
            butterChicken.recalculate();
            foodPreparationRepository.save(butterChicken);

            // 3. Paneer Butter Masala (10 kg, 50 portions, 35 sold, 15 remaining)
            FoodPreparation paneerMasala = new FoodPreparation(alex, today, "Shahi Paneer Butter Masala",
                    "Fresh Cottage Cheese Paneer (4 kg), Cashew Tomato Puree, Cream, Whole Spices",
                    new BigDecimal("10.00"), "kg", 50, new BigDecimal("200.00"), "12:00 PM", 8,
                    new BigDecimal("55.00"), new BigDecimal("260.00"));
            paneerMasala.setPortionsSold(35);
            paneerMasala.recalculate();
            foodPreparationRepository.save(paneerMasala);

            // 4. Veg Dum Pulao (15 kg, 75 portions, 60 sold, 15 remaining)
            FoodPreparation pulao = new FoodPreparation(alex, today, "Kashmiri Veg Dum Pulao",
                    "Basmati Rice (6 kg), Mixed Vegetables (4 kg), Ghee, Saffron, Mint",
                    new BigDecimal("15.00"), "kg", 75, new BigDecimal("200.00"), "11:15 AM", 8,
                    new BigDecimal("35.00"), new BigDecimal("190.00"));
            pulao.setPortionsSold(60);
            pulao.recalculate();
            foodPreparationRepository.save(pulao);

            // 5. Dal Makhani (18 kg, 90 portions, 80 sold, 10 remaining)
            FoodPreparation dal = new FoodPreparation(alex, today, "Slow Cooked Dal Makhani",
                    "Black Lentils Urad (6 kg), Kidney Beans, White Butter, Cream, Garlic",
                    new BigDecimal("18.00"), "kg", 90, new BigDecimal("200.00"), "10:30 AM", 8,
                    new BigDecimal("30.00"), new BigDecimal("180.00"));
            dal.setPortionsSold(80);
            dal.recalculate();
            foodPreparationRepository.save(dal);

            logger.info("Loaded daily restaurant food preparation batches.");
        }
    }

    private void seedConsumptions(User alex) {
        if (foodConsumptionRepository.count() == 0) {
            List<FoodPreparation> preps = foodPreparationRepository.findByUserIdOrderByPrepDateDescIdDesc(alex.getId());
            if (!preps.isEmpty()) {
                FoodPreparation biryani = preps.get(0);
                foodConsumptionRepository.save(new FoodConsumption(alex, biryani, biryani.getFoodName(),
                        50, new BigDecimal("10.00"), "kg", "Dine-in", new BigDecimal("14000.00"), "Lunch rush dining hall tables 1-14"));
                foodConsumptionRepository.save(new FoodConsumption(alex, biryani, biryani.getFoodName(),
                        25, new BigDecimal("5.00"), "kg", "Online Delivery", new BigDecimal("7000.00"), "Swiggy & Zomato lunch parcel orders"));
            }
        }
    }

    private void seedWaste(User alex) {
        if (foodWasteRepository.count() == 0) {
            foodWasteRepository.save(new FoodWaste(alex, null, null, "Overprepared Rice Surplus", FoodCategory.PANTRY,
                    new BigDecimal("3.00"), "kg", WasteReason.OVERPRODUCTION, new BigDecimal("50.00"), "Banquet excess unconsumed cooked rice"));

            foodWasteRepository.save(new FoodWaste(alex, null, null, "Wilted Salad Greens", FoodCategory.PRODUCE,
                    new BigDecimal("2.50"), "kg", WasteReason.SPOILED, new BigDecimal("45.00"), "High humidity leaf spoilage in salad station"));

            foodWasteRepository.save(new FoodWaste(alex, null, null, "Overbaked Naan Bread", FoodCategory.BAKERY,
                    new BigDecimal("1.50"), "kg", WasteReason.PREPARATION_ERROR, new BigDecimal("40.00"), "Tandoor temperature spike overbaked batch"));

            foodWasteRepository.save(new FoodWaste(alex, null, null, "Expired Cream Cheese", FoodCategory.DAIRY,
                    new BigDecimal("2.00"), "kg", WasteReason.EXPIRED, new BigDecimal("180.00"), "Sealed pack past expiry date"));

            logger.info("Loaded restaurant food waste audit records.");
        }
    }

    private void seedOrphanages() {
        if (orphanageRepository.count() == 0) {
            orphanageRepository.save(new Orphanage(
                    "Hope Children's Home", "REG-KA-2021-0042", "Sister Maria Joseph",
                    "+91 98450 11223", "maria@hopechildrenshome.org",
                    "42 Richmond Town, Behind Sacred Heart Church, Bangalore",
                    1.2, 48, "https://images.unsplash.com/photo-1488521787991-ed7bbaae773c?w=400&q=80",
                    "Registered charitable home caring for 48 orphaned and vulnerable children since 2012."
            ));

            orphanageRepository.save(new Orphanage(
                    "Sunrise Orphanage Shelter", "REG-KA-2019-0118", "Father Thomas Kurian",
                    "+91 98765 43210", "contact@sunriseorphanage.org",
                    "15 Victoria Road, Austin Town, Bangalore",
                    2.4, 35, "https://images.unsplash.com/photo-1509099836639-18ba1795216d?w=400&q=80",
                    "Dedicated shelter providing education, nutrition, and medical support to 35 children."
            ));

            orphanageRepository.save(new Orphanage(
                    "Little Angels Home", "REG-KA-2022-0309", "Mrs. Lakshmi Narayanan",
                    "+91 98110 55667", "lakshmi@littleangelshome.org",
                    "88 Cambridge Road, Ulsoor, Bangalore",
                    3.1, 62, "https://images.unsplash.com/photo-1542810634-71277d95dcbb?w=400&q=80",
                    "Nurturing environment supporting 62 young girls with school coaching and wholesome meals."
            ));

            orphanageRepository.save(new Orphanage(
                    "Sneha Nilaya Orphanage", "REG-KA-2018-0091", "Brother Francis D'Souza",
                    "+91 98220 77889", "francis@snehanilaya.org",
                    "7 Rest House Crescent, Off Brigade Road, Bangalore",
                    3.8, 40, "https://images.unsplash.com/photo-1469571486292-0ba58a3f068b?w=400&q=80",
                    "Community children home empowering youth with vocational training and nutritious meals."
            ));

            orphanageRepository.save(new Orphanage(
                    "Karuna Child Care Trust", "REG-KA-2020-0255", "Dr. Shalini Hegde",
                    "+91 98330 99001", "info@karunatrust.org",
                    "102 Wheeler Road, Frazer Town, Bangalore",
                    4.5, 55, "https://images.unsplash.com/photo-1516627145497-ae6968895b74?w=400&q=80",
                    "Recognized non-profit providing rehabilitation and full board care to 55 needy children."
            ));
            logger.info("Loaded 5 nearby verified registered orphanages.");
        }
    }

    private void seedDonations(User alex) {
        if (foodDonationRepository.count() == 0) {
            List<Orphanage> orphanages = orphanageRepository.findAll();
            if (!orphanages.isEmpty()) {
                // Listing 1: Available
                FoodDonation don1 = new FoodDonation(
                        alex, "FoodGuard Grand Bistro", "+91 98450 11223",
                        "124 Brigade Road, Bangalore", null,
                        "Freshly Cooked Veg Pulao & Paneer Gravy", FoodCategory.DAIRY,
                        new BigDecimal("15.00"), "kg", 35,
                        "Freshly cooked lunch surplus, hot packed in thermo boxes",
                        "Warm / Hot", 6, new BigDecimal("1450.00"),
                        "Hot packed immediately following lunch service. Pure vegetarian, mild spice."
                );
                don1.setStatus(DonationStatus.AVAILABLE);
                foodDonationRepository.save(don1);

                // Listing 2: Pickup Scheduled
                FoodDonation don2 = new FoodDonation(
                        alex, "FoodGuard Grand Bistro", "+91 98450 11223",
                        "124 Brigade Road, Bangalore", null,
                        "Assorted Artisan Breads & Sandwiches", FoodCategory.BAKERY,
                        new BigDecimal("12.00"), "kg", 25,
                        "Sealed bakery boxes", "Room Temp", 8, new BigDecimal("950.00"),
                        "Fresh morning bake surplus."
                );
                don2.setStatus(DonationStatus.PICKUP_SCHEDULED);
                don2.setClaimedByOrphanage(orphanages.get(0)); // Hope Children's Home
                don2.setPickupScheduledTime("Today at 2:30 PM");
                don2.setPickupNotes("Sister Maria Joseph arriving in orphanage van KA-01-E-4321");
                foodDonationRepository.save(don2);

                // Listing 3: Collected
                FoodDonation don3 = new FoodDonation(
                        alex, "FoodGuard Grand Bistro", "+91 98450 11223",
                        "124 Brigade Road, Bangalore", null,
                        "Steamed Jeera Rice & Dal Makhani", FoodCategory.PANTRY,
                        new BigDecimal("18.00"), "kg", 45,
                        "Food-grade containers", "Warm / Hot", 6, new BigDecimal("1850.00"),
                        "Dinner banquet surplus."
                );
                don3.setStatus(DonationStatus.COLLECTED);
                don3.setClaimedByOrphanage(orphanages.get(1)); // Sunrise Orphanage
                don3.setPickupScheduledTime("Collected at 1:15 PM");
                don3.setCollectedAt(LocalDateTime.now().minusHours(2));
                don3.setPickupNotes("Collected by van driver Ramesh");
                foodDonationRepository.save(don3);

                logger.info("Loaded initial food donation lifecycle records.");
            }
        }
    }

    private void seedNotifications(User alex) {
        if (notificationRepository.countByUserId(alex.getId()) == 0) {
            notificationRepository.save(new Notification(alex,
                    "⚠️ Chicken Expiry Notice",
                    "15 kg Fresh Chicken expires tomorrow in Walk-in Chiller. Please prepare or freeze.",
                    "EXPIRING_SOON", null));

            notificationRepository.save(new Notification(alex,
                    "⏱️ Surplus Biryani Safe Deadline",
                    "5 kg Dum Biryani remaining should be consumed or donated before 8:00 PM today.",
                    "EXPIRING_SOON", null));

            notificationRepository.save(new Notification(alex,
                    "❌ Expired Item Alert",
                    "2 kg Cream Cheese in Refrigerator has expired. Please log as waste.",
                    "EXPIRED", null));

            notificationRepository.save(new Notification(alex,
                    "❤️ Orphanage Pickup Confirmed",
                    "Hope Children's Home confirmed pickup for 25 meals today at 2:30 PM.",
                    "SYSTEM", null));
        }
    }

    private void seedRecipes() {
        if (recipeRepository.count() == 0) {
            recipeRepository.save(new Recipe("Zero-Waste Vegetable Fried Rice", "Turn day-old cold rice into a savory street-style fried rice dish.", "15 mins", "Easy", "Rice, Vegetables, Cooking Oil, Soy Sauce", "1. Heat oil in wok.\n2. Sauté chopped vegetables on high flame.\n3. Add cold rice and toss.\n4. Season with salt and soy sauce.", "Dinner"));
            recipeRepository.save(new Recipe("Crispy Bread Upma", "Revitalize stale bread crusts and leftover loaves with a tempered spicy South Indian upma.", "12 mins", "Easy", "Bread, Onions, Mustard Seeds, Curry Leaves, Green Chillies", "1. Tear bread into cubes.\n2. Splutter mustard and curry leaves.\n3. Sauté onions and chillies.\n4. Toss in bread cubes until golden.", "Breakfast"));
            recipeRepository.save(new Recipe("Creamy Paneer Tikka Masala", "Use near-expiry paneer cubes in a rich tomato butter gravy.", "25 mins", "Medium", "Paneer, Tomatoes, Cream, Butter, Spices", "1. Pan-sear paneer cubes.\n2. Simmer spiced tomato puree with butter.\n3. Fold in cream and paneer cubes.\n4. Garnish with coriander.", "Dinner"));
        }
    }
}
