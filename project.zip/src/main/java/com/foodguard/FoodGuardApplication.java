package com.foodguard;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication
@EnableScheduling
public class FoodGuardApplication {

    public static void main(String[] args) {
        SpringApplication.run(FoodGuardApplication.class, args);
    }
}
