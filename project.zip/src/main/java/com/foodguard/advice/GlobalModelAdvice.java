package com.foodguard.advice;

import com.foodguard.entity.User;
import com.foodguard.service.NotificationService;
import com.foodguard.service.UserService;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.security.authentication.AnonymousAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ModelAttribute;

@ControllerAdvice
public class GlobalModelAdvice {

    private final UserService userService;
    private final NotificationService notificationService;

    public GlobalModelAdvice(UserService userService, NotificationService notificationService) {
        this.userService = userService;
        this.notificationService = notificationService;
    }

    @ModelAttribute
    public void populateGlobalModel(HttpServletRequest request, Model model, Authentication authentication) {
        if (request != null) {
            model.addAttribute("currentUri", request.getRequestURI());
        }

        if (authentication != null && authentication.isAuthenticated() && !(authentication instanceof AnonymousAuthenticationToken)) {
            try {
                User user = userService.getCurrentUser();
                if (!model.containsAttribute("user")) {
                    model.addAttribute("user", user);
                }
                model.addAttribute("currentUser", user);
                model.addAttribute("unreadNotificationsCount", notificationService.getUnreadCount(user));
            } catch (Exception ignored) {
                // If user is not yet loaded or on anonymous transitions
            }
        }
    }
}
