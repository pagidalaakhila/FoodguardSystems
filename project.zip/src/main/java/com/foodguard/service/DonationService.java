package com.foodguard.service;

import com.foodguard.entity.*;
import com.foodguard.exception.ResourceNotFoundException;
import com.foodguard.repository.FoodActionRepository;
import com.foodguard.repository.FoodDonationRepository;
import com.foodguard.repository.FoodItemRepository;
import com.foodguard.repository.NotificationRepository;
import com.foodguard.repository.OrphanageRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class DonationService {

    private final FoodDonationRepository foodDonationRepository;
    private final OrphanageRepository orphanageRepository;
    private final FoodActionRepository foodActionRepository;
    private final FoodItemRepository foodItemRepository;
    private final NotificationRepository notificationRepository;

    public DonationService(FoodDonationRepository foodDonationRepository,
                           OrphanageRepository orphanageRepository,
                           FoodActionRepository foodActionRepository,
                           FoodItemRepository foodItemRepository,
                           NotificationRepository notificationRepository) {
        this.foodDonationRepository = foodDonationRepository;
        this.orphanageRepository = orphanageRepository;
        this.foodActionRepository = foodActionRepository;
        this.foodItemRepository = foodItemRepository;
        this.notificationRepository = notificationRepository;
    }

    public List<FoodDonation> getAllDonations() {
        return foodDonationRepository.findAllByOrderByCreatedAtDesc();
    }

    public List<FoodDonation> getAvailableDonations() {
        return foodDonationRepository.findByStatusOrderByCreatedAtDesc(DonationStatus.AVAILABLE);
    }

    public List<FoodDonation> getScheduledDonations() {
        return foodDonationRepository.findByStatusOrderByCreatedAtDesc(DonationStatus.PICKUP_SCHEDULED);
    }

    public List<FoodDonation> getCompletedDonations() {
        return foodDonationRepository.findByStatusOrderByCreatedAtDesc(DonationStatus.COLLECTED);
    }

    public List<FoodDonation> getDonationsByRestaurantUser(User user) {
        return foodDonationRepository.findByRestaurantUserIdOrderByCreatedAtDesc(user.getId());
    }

    public FoodDonation getDonationById(Long id) {
        return foodDonationRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Food donation listing not found with ID: " + id));
    }

    public List<Orphanage> getAllOrphanages() {
        return orphanageRepository.findAllByOrderByDistanceKmAsc();
    }

    @Transactional
    public FoodDonation createDonation(User user,
                                       String restaurantName,
                                       String restaurantPhone,
                                       String restaurantAddress,
                                       Long foodItemId,
                                       String foodTitle,
                                       FoodCategory category,
                                       BigDecimal quantity,
                                       String unit,
                                       Integer estimatedMeals,
                                       String foodCondition,
                                       String storageTemperature,
                                       Integer consumeByHours,
                                       BigDecimal costValue,
                                       String notes) {

        int meals = (estimatedMeals != null && estimatedMeals > 0)
                ? estimatedMeals
                : Math.max(1, (int) (quantity.doubleValue() * 2.5));

        int hours = (consumeByHours != null && consumeByHours > 0) ? consumeByHours : 6;
        BigDecimal cost = (costValue != null && costValue.compareTo(BigDecimal.ZERO) > 0) ? costValue : BigDecimal.ZERO;

        // If linked to an inventory food item, optionally deduct quantity or use item cost
        if (foodItemId != null) {
            foodItemRepository.findById(foodItemId).ifPresent(item -> {
                if (cost.compareTo(BigDecimal.ZERO) == 0 && item.getCost() != null) {
                    // inherit cost
                }
            });
        }

        FoodDonation donation = new FoodDonation(
                user,
                (restaurantName != null && !restaurantName.isBlank()) ? restaurantName : (user.getFullName() + "'s Kitchen"),
                (restaurantPhone != null && !restaurantPhone.isBlank()) ? restaurantPhone : "+91 98450 12345",
                (restaurantAddress != null && !restaurantAddress.isBlank()) ? restaurantAddress : "Indiranagar Main Road, Bangalore",
                foodItemId,
                foodTitle,
                (category != null) ? category : FoodCategory.OTHER,
                quantity,
                (unit != null && !unit.isBlank()) ? unit : "kg",
                meals,
                (foodCondition != null && !foodCondition.isBlank()) ? foodCondition : "Freshly Prepared Surplus Food",
                (storageTemperature != null && !storageTemperature.isBlank()) ? storageTemperature : "Warm / Hot",
                hours,
                cost,
                notes
        );

        FoodDonation saved = foodDonationRepository.save(donation);

        // Broadcast notification to user & nearby orphanages
        long orphanageCount = orphanageRepository.count();
        notificationRepository.save(new Notification(
                user,
                foodItemId,
                "🔔 Food Rescue Broadcast Sent to " + orphanageCount + " Orphanages",
                "Your donation listing for '" + foodTitle + "' (" + quantity + " " + unit + ", ~" + meals + " meals) is live! Verified nearby orphanages have been alerted for immediate pickup.",
                "DONATION_BROADCAST"
        ));

        return saved;
    }

    @Transactional
    public FoodDonation acceptDonation(Long donationId, Long orphanageId, String pickupTime, String pickupNotes, User currentUser) {
        FoodDonation donation = getDonationById(donationId);
        Orphanage orphanage = orphanageRepository.findById(orphanageId)
                .orElseThrow(() -> new ResourceNotFoundException("Orphanage not found with ID: " + orphanageId));

        donation.setStatus(DonationStatus.PICKUP_SCHEDULED);
        donation.setClaimedByOrphanage(orphanage);
        donation.setPickupScheduledTime((pickupTime != null && !pickupTime.isBlank()) ? pickupTime : "Within 1 hour");
        donation.setPickupNotes(pickupNotes);

        FoodDonation updated = foodDonationRepository.save(donation);

        // Notify Restaurant / User
        notificationRepository.save(new Notification(
                donation.getRestaurantUser(),
                donation.getFoodItemId(),
                "🚚 Pickup Confirmed by " + orphanage.getName(),
                "Good news! " + orphanage.getName() + " has claimed '" + donation.getFoodTitle() + "'. Confirmed arrival: " + donation.getPickupScheduledTime() + ". " +
                (pickupNotes != null && !pickupNotes.isBlank() ? "Note: " + pickupNotes : "Please keep food packaged for pickup."),
                "DONATION_SCHEDULED"
        ));

        return updated;
    }

    @Transactional
    public FoodDonation confirmCollection(Long donationId, User currentUser) {
        FoodDonation donation = getDonationById(donationId);
        donation.setStatus(DonationStatus.COLLECTED);
        donation.setCollectedAt(LocalDateTime.now());

        FoodDonation updated = foodDonationRepository.save(donation);

        Orphanage orphanage = donation.getClaimedByOrphanage();
        String orphanageName = (orphanage != null) ? orphanage.getName() : "Local Orphanage";

        // Deduct inventory item if linked
        if (donation.getFoodItemId() != null) {
            foodItemRepository.findById(donation.getFoodItemId()).ifPresent(item -> {
                BigDecimal remaining = item.getQuantity().subtract(donation.getQuantity());
                if (remaining.compareTo(BigDecimal.ZERO) <= 0) {
                    foodItemRepository.delete(item);
                } else {
                    item.setQuantity(remaining);
                    foodItemRepository.save(item);
                }
            });
        }

        // AUTOMATICALLY RECORD IN FOOD ACTION AUDIT HISTORY (ActionType.DONATED)
        FoodAction action = new FoodAction(
                donation.getRestaurantUser(),
                donation.getFoodItemId(),
                donation.getFoodTitle(),
                donation.getCategory(),
                ActionType.DONATED,
                donation.getQuantity(),
                donation.getUnit(),
                donation.getCostValue(),
                LocalDate.now(),
                "Donated to " + orphanageName + " (Fed ~" + donation.getEstimatedMeals() + " children)"
        );
        foodActionRepository.save(action);

        // Send Completion Notification
        notificationRepository.save(new Notification(
                donation.getRestaurantUser(),
                donation.getFoodItemId(),
                "🎉 Food Collected & Donated to " + orphanageName + "!",
                "Handover complete! " + donation.getQuantity() + " " + donation.getUnit() + " of '" + donation.getFoodTitle() + "' was collected by " + orphanageName + " to feed ~" + donation.getEstimatedMeals() + " children. Recorded in your Food Action History audit log.",
                "DONATION_COLLECTED"
        ));

        return updated;
    }

    public Map<String, Object> getDonationMetrics() {
        Map<String, Object> metrics = new HashMap<>();
        int meals = foodDonationRepository.sumMealsCollected();
        BigDecimal qty = foodDonationRepository.sumQuantityCollected();
        BigDecimal value = foodDonationRepository.sumCostValueCollected();
        long availableCount = foodDonationRepository.countByStatus(DonationStatus.AVAILABLE);
        long scheduledCount = foodDonationRepository.countByStatus(DonationStatus.PICKUP_SCHEDULED);
        long completedCount = foodDonationRepository.countByStatus(DonationStatus.COLLECTED);
        long orphanageCount = orphanageRepository.count();

        metrics.put("totalMealsFed", meals);
        metrics.put("totalQuantityRescued", qty);
        metrics.put("totalFinancialValue", value);
        metrics.put("availableCount", availableCount);
        metrics.put("scheduledCount", scheduledCount);
        metrics.put("completedCount", completedCount);
        metrics.put("orphanageCount", orphanageCount);
        return metrics;
    }
}
