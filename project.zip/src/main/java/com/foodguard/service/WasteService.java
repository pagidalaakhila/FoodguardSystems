package com.foodguard.service;

import com.foodguard.entity.*;
import com.foodguard.repository.FoodActionRepository;
import com.foodguard.repository.FoodItemRepository;
import com.foodguard.repository.FoodWasteRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

@Service
@Transactional
public class WasteService {

    private final FoodWasteRepository wasteRepository;
    private final FoodActionRepository foodActionRepository;
    private final FoodItemRepository foodItemRepository;

    public WasteService(FoodWasteRepository wasteRepository,
                        FoodActionRepository foodActionRepository,
                        FoodItemRepository foodItemRepository) {
        this.wasteRepository = wasteRepository;
        this.foodActionRepository = foodActionRepository;
        this.foodItemRepository = foodItemRepository;
    }

    public List<FoodWaste> getAllWaste(Long userId) {
        return wasteRepository.findByUserIdOrderByWasteDateDesc(userId);
    }

    public BigDecimal getTotalQuantityWasted(Long userId) {
        return wasteRepository.sumTotalQuantityWasted(userId);
    }

    public BigDecimal getTotalCostLoss(Long userId) {
        return wasteRepository.sumTotalCostLoss(userId);
    }

    public List<Object[]> getWasteSummaryByReason(Long userId) {
        return wasteRepository.getWasteSummaryByReason(userId);
    }

    /**
     * Records food waste from raw inventory or general kitchen waste.
     */
    public FoodWaste recordWaste(User user, Long foodItemId, String foodName, FoodCategory category,
                                 BigDecimal quantityWasted, String unit, WasteReason reason,
                                 BigDecimal costPerUnit, String notes) {
        FoodItem foodItem = null;
        if (foodItemId != null) {
            foodItem = foodItemRepository.findById(foodItemId).orElse(null);
            if (foodItem != null) {
                // Deduct from available inventory
                BigDecimal current = foodItem.getCurrentAvailableQuantity();
                if (current != null && current.compareTo(quantityWasted) >= 0) {
                    foodItem.setCurrentAvailableQuantity(current.subtract(quantityWasted));
                    foodItemRepository.save(foodItem);
                }
            }
        }

        BigDecimal costLoss = (costPerUnit != null && quantityWasted != null)
                ? quantityWasted.multiply(costPerUnit)
                : BigDecimal.ZERO;

        FoodWaste waste = new FoodWaste(
                user, null, foodItem, foodName, category, quantityWasted, unit, reason, costPerUnit, notes
        );
        waste.setEstimatedCostLoss(costLoss);
        FoodWaste saved = wasteRepository.save(waste);

        // Record in FoodAction history
        FoodAction action = new FoodAction(
                user,
                foodItemId,
                foodName,
                (category != null) ? category : FoodCategory.OTHER,
                ActionType.WASTED,
                quantityWasted,
                unit,
                costLoss,
                LocalDate.now(),
                "Discarded " + quantityWasted + " " + unit + " due to " + reason.getDisplayName() + ". Cost loss: ₹" + costLoss
        );
        foodActionRepository.save(action);

        return saved;
    }
}
