package com.foodguard.service;

import com.foodguard.entity.*;
import com.foodguard.repository.FoodActionRepository;
import com.foodguard.repository.FoodConsumptionRepository;
import com.foodguard.repository.FoodPreparationRepository;
import com.foodguard.repository.FoodWasteRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

@Service
@Transactional
public class PreparationService {

    private final FoodPreparationRepository preparationRepository;
    private final FoodConsumptionRepository consumptionRepository;
    private final FoodWasteRepository wasteRepository;
    private final FoodActionRepository foodActionRepository;
    private final CalculationService calculationService;

    public PreparationService(FoodPreparationRepository preparationRepository,
                              FoodConsumptionRepository consumptionRepository,
                              FoodWasteRepository wasteRepository,
                              FoodActionRepository foodActionRepository,
                              CalculationService calculationService) {
        this.preparationRepository = preparationRepository;
        this.consumptionRepository = consumptionRepository;
        this.wasteRepository = wasteRepository;
        this.foodActionRepository = foodActionRepository;
        this.calculationService = calculationService;
    }

    public List<FoodPreparation> getAllPreparations(Long userId) {
        return preparationRepository.findByUserIdOrderByPrepDateDescIdDesc(userId);
    }

    public List<FoodPreparation> getAvailableSurplus(Long userId) {
        return preparationRepository.findAvailableSurplusPreps(userId);
    }

    public FoodPreparation getPreparationById(Long id) {
        return preparationRepository.findById(id).orElse(null);
    }

    /**
     * Records a new daily food preparation batch.
     */
    public FoodPreparation createPreparation(User user, String foodName, String ingredientsUsed,
                                             BigDecimal quantityPrepared, String unit, int portionsPrepared,
                                             BigDecimal servingSizeGrams, String prepTime, int expectedShelfHours,
                                             BigDecimal costPerPortion, BigDecimal sellingPricePerPortion) {
        FoodPreparation prep = new FoodPreparation(user, LocalDate.now(), foodName, ingredientsUsed,
                quantityPrepared, unit, portionsPrepared, servingSizeGrams, prepTime, expectedShelfHours,
                costPerPortion, sellingPricePerPortion);

        FoodPreparation saved = preparationRepository.save(prep);

        // Record in FoodAction history
        FoodAction action = new FoodAction(
                user,
                null,
                prep.getFoodName(),
                FoodCategory.PREPARED_MEALS != null ? FoodCategory.OTHER : FoodCategory.OTHER,
                ActionType.PREPARED,
                prep.getQuantityPrepared(),
                prep.getUnit(),
                prep.getCostPerPortion().multiply(BigDecimal.valueOf(prep.getPortionsPrepared())),
                LocalDate.now(),
                "Prepared batch: " + prep.getPortionsPrepared() + " portions (" + prep.getQuantityPrepared() + " " + prep.getUnit() + ")"
        );
        action.setFoodPrepId(saved.getId());
        foodActionRepository.save(action);

        return saved;
    }

    /**
     * Records food consumption / sales against a prepared batch.
     */
    public FoodConsumption recordConsumption(User user, Long prepId, int portionsSold, String orderType,
                                             BigDecimal customRevenue, String notes) {
        FoodPreparation prep = preparationRepository.findById(prepId)
                .orElseThrow(() -> new IllegalArgumentException("Preparation batch not found: " + prepId));

        if (portionsSold <= 0) {
            throw new IllegalArgumentException("Portions sold must be greater than zero.");
        }
        if (portionsSold > prep.getRemainingPortions()) {
            throw new IllegalArgumentException("Cannot sell " + portionsSold + " portions. Only " + prep.getRemainingPortions() + " portions remaining.");
        }

        // Calculate sold quantity in unit
        BigDecimal portionRatio = BigDecimal.valueOf(portionsSold).divide(BigDecimal.valueOf(prep.getPortionsPrepared()), 4, RoundingMode.HALF_UP);
        BigDecimal qtySold = prep.getQuantityPrepared().multiply(portionRatio).setScale(2, RoundingMode.HALF_UP);

        BigDecimal revenue = (customRevenue != null && customRevenue.compareTo(BigDecimal.ZERO) > 0)
                ? customRevenue
                : prep.getSellingPricePerPortion().multiply(BigDecimal.valueOf(portionsSold));

        // Update batch portions sold
        prep.setPortionsSold(prep.getPortionsSold() + portionsSold);
        prep.recalculate();
        preparationRepository.save(prep);

        // Save Consumption Record
        FoodConsumption consumption = new FoodConsumption(
                user, prep, prep.getFoodName(), portionsSold, qtySold, prep.getUnit(), orderType, revenue, notes
        );
        FoodConsumption saved = consumptionRepository.save(consumption);

        // Record in FoodAction history
        FoodAction action = new FoodAction(
                user,
                null,
                prep.getFoodName(),
                FoodCategory.OTHER,
                ActionType.CONSUMED,
                qtySold,
                prep.getUnit(),
                revenue,
                LocalDate.now(),
                "Sold/Served " + portionsSold + " portions (" + qtySold + " " + prep.getUnit() + ") via " + orderType
        );
        action.setFoodPrepId(prep.getId());
        foodActionRepository.save(action);

        return saved;
    }

    /**
     * Records food waste from a prepared batch (e.g. at end of day).
     */
    public FoodWaste recordWasteFromPrep(User user, Long prepId, int portionsWasted, WasteReason reason, String notes) {
        FoodPreparation prep = preparationRepository.findById(prepId)
                .orElseThrow(() -> new IllegalArgumentException("Preparation batch not found: " + prepId));

        if (portionsWasted <= 0) {
            throw new IllegalArgumentException("Portions wasted must be greater than zero.");
        }
        if (portionsWasted > prep.getRemainingPortions()) {
            throw new IllegalArgumentException("Cannot discard " + portionsWasted + " portions. Only " + prep.getRemainingPortions() + " portions remaining.");
        }

        BigDecimal portionRatio = BigDecimal.valueOf(portionsWasted).divide(BigDecimal.valueOf(prep.getPortionsPrepared()), 4, RoundingMode.HALF_UP);
        BigDecimal qtyWasted = prep.getQuantityPrepared().multiply(portionRatio).setScale(2, RoundingMode.HALF_UP);
        BigDecimal costLoss = prep.getCostPerPortion().multiply(BigDecimal.valueOf(portionsWasted));

        // Update batch
        prep.setPortionsWasted(prep.getPortionsWasted() + portionsWasted);
        prep.recalculate();
        preparationRepository.save(prep);

        // Save FoodWaste
        FoodWaste waste = new FoodWaste(
                user, prep, null, prep.getFoodName(), FoodCategory.OTHER, qtyWasted,
                prep.getUnit(), reason, prep.getCostPerPortion(), notes
        );
        waste.setEstimatedCostLoss(costLoss);
        FoodWaste saved = wasteRepository.save(waste);

        // Record in FoodAction history
        FoodAction action = new FoodAction(
                user,
                null,
                prep.getFoodName(),
                FoodCategory.OTHER,
                ActionType.WASTED,
                qtyWasted,
                prep.getUnit(),
                costLoss,
                LocalDate.now(),
                "Wasted " + portionsWasted + " portions due to " + reason.getDisplayName() + ". Financial Loss: ₹" + costLoss
        );
        action.setFoodPrepId(prep.getId());
        foodActionRepository.save(action);

        return saved;
    }

    /**
     * Donates remaining surplus portions from a preparation batch.
     */
    public void recordDonationFromPrep(User user, Long prepId, int portionsDonated, String notes) {
        FoodPreparation prep = preparationRepository.findById(prepId)
                .orElseThrow(() -> new IllegalArgumentException("Preparation batch not found: " + prepId));

        if (portionsDonated <= 0 || portionsDonated > prep.getRemainingPortions()) {
            throw new IllegalArgumentException("Invalid donation portions: " + portionsDonated);
        }

        BigDecimal portionRatio = BigDecimal.valueOf(portionsDonated).divide(BigDecimal.valueOf(prep.getPortionsPrepared()), 4, RoundingMode.HALF_UP);
        BigDecimal qtyDonated = prep.getQuantityPrepared().multiply(portionRatio).setScale(2, RoundingMode.HALF_UP);

        prep.setPortionsDonated(prep.getPortionsDonated() + portionsDonated);
        prep.recalculate();
        preparationRepository.save(prep);

        // Log to history
        FoodAction action = new FoodAction(
                user,
                null,
                prep.getFoodName(),
                FoodCategory.OTHER,
                ActionType.DONATED,
                qtyDonated,
                prep.getUnit(),
                prep.getCostPerPortion().multiply(BigDecimal.valueOf(portionsDonated)),
                LocalDate.now(),
                "Donated " + portionsDonated + " portions (" + qtyDonated + " " + prep.getUnit() + ") of surplus to orphanage. " + (notes != null ? notes : "")
        );
        action.setFoodPrepId(prep.getId());
        foodActionRepository.save(action);
    }
}
