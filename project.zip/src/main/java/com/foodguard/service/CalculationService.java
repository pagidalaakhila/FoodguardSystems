package com.foodguard.service;

import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;

@Service
public class CalculationService {

    /**
     * Standard average serving size in grams for prepared dishes.
     */
    public static final BigDecimal DEFAULT_SERVING_SIZE_GRAMS = new BigDecimal("200.0");

    /**
     * Converts a given quantity and unit to standard grams.
     * Supports: kg, grams, litres, ml, pieces, packets, portions.
     */
    public BigDecimal convertToGrams(BigDecimal quantity, String unit) {
        if (quantity == null || quantity.compareTo(BigDecimal.ZERO) <= 0) {
            return BigDecimal.ZERO;
        }
        if (unit == null) return quantity.multiply(new BigDecimal("1000"));

        String u = unit.toLowerCase().trim();
        switch (u) {
            case "kg":
            case "kilogram":
            case "kilograms":
                return quantity.multiply(new BigDecimal("1000"));
            case "g":
            case "gram":
            case "grams":
                return quantity;
            case "l":
            case "litre":
            case "litres":
            case "liter":
            case "liters":
                // Assuming density roughly 1kg/L for soups/curries/water
                return quantity.multiply(new BigDecimal("1000"));
            case "ml":
            case "millilitre":
            case "millilitres":
            case "milliliter":
                return quantity;
            case "portion":
            case "portions":
            case "serving":
            case "servings":
                return quantity.multiply(DEFAULT_SERVING_SIZE_GRAMS);
            case "piece":
            case "pieces":
            case "pc":
            case "pcs":
                // Standard piece estimated around 150g
                return quantity.multiply(new BigDecimal("150"));
            case "packet":
            case "packets":
            case "pack":
            case "packs":
                // Standard pack estimated around 500g
                return quantity.multiply(new BigDecimal("500"));
            default:
                return quantity.multiply(new BigDecimal("1000"));
        }
    }

    /**
     * Calculates estimated people served:
     * Formula: Available Food Quantity in Grams ÷ Average Serving Size in Grams
     * e.g., 5 kg food (5000g) ÷ 200 g serving = 25 people.
     */
    public int calculateEstimatedPeopleServed(BigDecimal availableQuantity, String unit, BigDecimal servingSizeGrams) {
        if (availableQuantity == null || availableQuantity.compareTo(BigDecimal.ZERO) <= 0) {
            return 0;
        }
        BigDecimal servingGrams = (servingSizeGrams != null && servingSizeGrams.compareTo(BigDecimal.ZERO) > 0)
                ? servingSizeGrams
                : DEFAULT_SERVING_SIZE_GRAMS;

        BigDecimal totalGrams = convertToGrams(availableQuantity, unit);
        BigDecimal people = totalGrams.divide(servingGrams, 0, RoundingMode.FLOOR);
        return Math.max(1, people.intValue());
    }

    /**
     * Calculates remaining quantity based on remaining portions vs total portions prepared.
     */
    public BigDecimal calculateRemainingQuantity(BigDecimal totalPreparedQty, int totalPortions, int remainingPortions) {
        if (totalPreparedQty == null || totalPortions <= 0 || remainingPortions <= 0) {
            return BigDecimal.ZERO;
        }
        return totalPreparedQty.multiply(BigDecimal.valueOf(remainingPortions))
                .divide(BigDecimal.valueOf(totalPortions), 2, RoundingMode.HALF_UP);
    }

    /**
     * Calculates waste percentage: (wastedQty / totalQty) * 100
     */
    public BigDecimal calculateWastePercentage(BigDecimal wastedQty, BigDecimal totalQty) {
        if (wastedQty == null || totalQty == null || totalQty.compareTo(BigDecimal.ZERO) <= 0) {
            return BigDecimal.ZERO;
        }
        return wastedQty.multiply(new BigDecimal("100"))
                .divide(totalQty, 1, RoundingMode.HALF_UP);
    }

    /**
     * Calculates donation percentage: (donatedQty / totalQty) * 100
     */
    public BigDecimal calculateDonationPercentage(BigDecimal donatedQty, BigDecimal totalQty) {
        if (donatedQty == null || totalQty == null || totalQty.compareTo(BigDecimal.ZERO) <= 0) {
            return BigDecimal.ZERO;
        }
        return donatedQty.multiply(new BigDecimal("100"))
                .divide(totalQty, 1, RoundingMode.HALF_UP);
    }

    /**
     * Calculates consumption percentage: (consumedQty / totalQty) * 100
     */
    public BigDecimal calculateConsumptionPercentage(BigDecimal consumedQty, BigDecimal totalQty) {
        if (consumedQty == null || totalQty == null || totalQty.compareTo(BigDecimal.ZERO) <= 0) {
            return BigDecimal.ZERO;
        }
        return consumedQty.multiply(new BigDecimal("100"))
                .divide(totalQty, 1, RoundingMode.HALF_UP);
    }

    /**
     * Calculates financial loss: Quantity Wasted × Cost per Unit
     */
    public BigDecimal calculateFinancialLoss(BigDecimal wastedQty, BigDecimal costPerUnit) {
        if (wastedQty == null || costPerUnit == null) {
            return BigDecimal.ZERO;
        }
        return wastedQty.multiply(costPerUnit).setScale(2, RoundingMode.HALF_UP);
    }
}
