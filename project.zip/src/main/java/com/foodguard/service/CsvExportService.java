package com.foodguard.service;

import com.foodguard.entity.FoodAction;
import com.foodguard.entity.FoodItem;
import org.springframework.stereotype.Service;

import java.io.PrintWriter;
import java.util.List;

@Service
public class CsvExportService {

    public void exportInventoryToCsv(List<FoodItem> items, PrintWriter writer) {
        // CSV Header
        writer.println("ID,Item Name,Category,Quantity,Unit,Storage Location,Purchase Date,Expiry Date,Days Left,Status,Cost (₹),Notes");

        for (FoodItem item : items) {
            writer.printf("%d,%s,%s,%.2f,%s,%s,%s,%s,%d,%s,%.2f,%s%n",
                    item.getId(),
                    escapeCsv(item.getName()),
                    escapeCsv(item.getCategory().getDisplayName()),
                    item.getQuantity(),
                    escapeCsv(item.getUnit()),
                    escapeCsv(item.getStorageLocation().getDisplayName()),
                    item.getFormattedPurchaseDate(),
                    item.getFormattedExpiryDate(),
                    item.getDaysUntilExpiry(),
                    escapeCsv(item.getStatus().getLabel()),
                    item.getCost(),
                    escapeCsv(item.getNotes() != null ? item.getNotes() : "")
            );
        }
        writer.flush();
    }

    public void exportHistoryToCsv(List<FoodAction> actions, PrintWriter writer) {
        // CSV Header
        writer.println("Action ID,Action Date,Action Type,Item Name,Category,Quantity,Unit,Cost Impact (₹),Notes");

        for (FoodAction action : actions) {
            writer.printf("%d,%s,%s,%s,%s,%.2f,%s,%.2f,%s%n",
                    action.getId(),
                    action.getFormattedActionDate(),
                    escapeCsv(action.getActionType().getDisplayName()),
                    escapeCsv(action.getItemName()),
                    escapeCsv(action.getCategory().getDisplayName()),
                    action.getQuantity(),
                    escapeCsv(action.getUnit()),
                    action.getCostImpact(),
                    escapeCsv(action.getNotes() != null ? action.getNotes() : "")
            );
        }
        writer.flush();
    }

    private String escapeCsv(String data) {
        if (data == null) {
            return "\"\"";
        }
        String clean = data.replace("\"", "\"\"");
        if (clean.contains(",") || clean.contains("\n") || clean.contains("\r") || clean.contains("\"")) {
            return "\"" + clean + "\"";
        }
        return "\"" + clean + "\"";
    }
}
