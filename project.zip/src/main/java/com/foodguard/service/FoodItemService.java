package com.foodguard.service;

import com.foodguard.dto.FoodItemDto;
import com.foodguard.entity.FoodCategory;
import com.foodguard.entity.FoodItem;
import com.foodguard.entity.StorageLocation;
import com.foodguard.entity.User;
import com.foodguard.exception.ResourceNotFoundException;
import com.foodguard.exception.UnauthorizedException;
import com.foodguard.repository.FoodItemRepository;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

@Service
public class FoodItemService {

    private final FoodItemRepository foodItemRepository;

    public FoodItemService(FoodItemRepository foodItemRepository) {
        this.foodItemRepository = foodItemRepository;
    }

    @Transactional
    public FoodItem createItem(FoodItemDto dto, User user) {
        FoodItem item = new FoodItem();
        item.setUser(user);
        mapDtoToEntity(dto, item);
        return foodItemRepository.save(item);
    }

    @Transactional
    public FoodItem updateItem(Long id, FoodItemDto dto, User user) {
        FoodItem item = getItemByIdAndUser(id, user);
        mapDtoToEntity(dto, item);
        return foodItemRepository.save(item);
    }

    public FoodItem getItemByIdAndUser(Long id, User user) {
        FoodItem item = foodItemRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Food item not found with ID: " + id));

        if (!item.getUser().getId().equals(user.getId())) {
            throw new UnauthorizedException("You are not authorized to access this food item.");
        }
        return item;
    }

    @Transactional
    public void deleteItem(Long id, User user) {
        FoodItem item = getItemByIdAndUser(id, user);
        foodItemRepository.delete(item);
    }

    public Page<FoodItem> getUserItems(
            User user,
            String keyword,
            FoodCategory category,
            StorageLocation location,
            String status,
            int page,
            int size,
            String sortField,
            String sortDir
    ) {
        Sort sort = sortDir.equalsIgnoreCase("asc") ? Sort.by(sortField).ascending() : Sort.by(sortField).descending();
        Pageable pageable = PageRequest.of(Math.max(0, page), size, sort);

        LocalDate today = LocalDate.now();
        LocalDate soonDate = today.plusDays(user.getAlertDaysBefore());

        String cleanKeyword = (keyword != null && !keyword.trim().isEmpty()) ? keyword.trim() : null;
        String cleanStatus = (status != null && !status.trim().isEmpty() && !status.equalsIgnoreCase("ALL")) ? status.trim().toUpperCase() : null;

        return foodItemRepository.searchItems(user.getId(), cleanKeyword, category, location, cleanStatus, today, soonDate, pageable);
    }

    public List<FoodItem> getAllUserItems(User user) {
        return foodItemRepository.findByUserIdOrderByExpiryDateAsc(user.getId());
    }

    public List<FoodItem> getExpiringSoonItems(User user) {
        LocalDate today = LocalDate.now();
        LocalDate soonDate = today.plusDays(user.getAlertDaysBefore());
        return foodItemRepository.findByUserIdOrderByExpiryDateAsc(user.getId()).stream()
                .filter(item -> {
                    long days = item.getDaysUntilExpiry();
                    return days >= 0 && days <= user.getAlertDaysBefore();
                })
                .toList();
    }

    public FoodItemDto convertToDto(FoodItem item) {
        FoodItemDto dto = new FoodItemDto();
        dto.setId(item.getId());
        dto.setName(item.getName());
        dto.setCategory(item.getCategory());
        dto.setQuantity(item.getQuantity());
        dto.setUnit(item.getUnit());
        dto.setPurchaseDate(item.getPurchaseDate());
        dto.setExpiryDate(item.getExpiryDate());
        dto.setStorageLocation(item.getStorageLocation());
        dto.setCost(item.getCost());
        dto.setNotes(item.getNotes());
        dto.setMfgDate(item.getMfgDate());
        dto.setCurrentAvailableQuantity(item.getCurrentAvailableQuantity());
        dto.setMinStockLevel(item.getMinStockLevel());
        dto.setStorageType(item.getStorageType());
        dto.setSupplierName(item.getSupplierName());
        return dto;
    }

    private void mapDtoToEntity(FoodItemDto dto, FoodItem entity) {
        entity.setName(dto.getName().trim());
        entity.setCategory(dto.getCategory());
        entity.setQuantity(dto.getQuantity());
        entity.setUnit(dto.getUnit().trim());
        entity.setPurchaseDate(dto.getPurchaseDate());
        entity.setExpiryDate(dto.getExpiryDate());
        entity.setStorageLocation(dto.getStorageLocation());
        entity.setCost(dto.getCost() != null ? dto.getCost() : BigDecimal.ZERO);
        entity.setNotes(dto.getNotes() != null ? dto.getNotes().trim() : null);
        entity.setMfgDate(dto.getMfgDate() != null ? dto.getMfgDate() : dto.getPurchaseDate());
        entity.setCurrentAvailableQuantity(dto.getCurrentAvailableQuantity() != null ? dto.getCurrentAvailableQuantity() : dto.getQuantity());
        entity.setMinStockLevel(dto.getMinStockLevel() != null ? dto.getMinStockLevel() : new java.math.BigDecimal("5.0"));
        entity.setStorageType(dto.getStorageType() != null && !dto.getStorageType().trim().isEmpty() ? dto.getStorageType().trim() : (dto.getStorageLocation() != null ? dto.getStorageLocation().getDisplayName() : "Refrigerator"));
        entity.setSupplierName(dto.getSupplierName() != null && !dto.getSupplierName().trim().isEmpty() ? dto.getSupplierName().trim() : "Metro Restaurant Supplies");
    }
}
