package com.foodguard.service;

import com.foodguard.entity.FoodItem;
import com.foodguard.entity.User;
import com.foodguard.repository.FoodItemRepository;
import com.foodguard.repository.NotificationRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.event.EventListener;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.List;

@Service
public class ExpiryScheduler {

    private static final Logger logger = LoggerFactory.getLogger(ExpiryScheduler.class);

    private final FoodItemRepository foodItemRepository;
    private final NotificationRepository notificationRepository;
    private final NotificationService notificationService;
    private final EmailAlertService emailAlertService;

    @Value("${foodguard.scheduler.run-on-startup:true}")
    private boolean runOnStartup;

    public ExpiryScheduler(FoodItemRepository foodItemRepository,
                           NotificationRepository notificationRepository,
                           NotificationService notificationService,
                           EmailAlertService emailAlertService) {
        this.foodItemRepository = foodItemRepository;
        this.notificationRepository = notificationRepository;
        this.notificationService = notificationService;
        this.emailAlertService = emailAlertService;
    }

    @EventListener(ApplicationReadyEvent.class)
    @Transactional
    public void onStartup() {
        if (runOnStartup) {
            logger.info("Running initial FoodGuard Expiry Check on application startup...");
            performExpiryCheck();
        }
    }

    @Scheduled(cron = "${foodguard.scheduler.expiry-cron:0 0 0 * * ?}")
    @Transactional
    public void scheduledExpiryCheck() {
        logger.info("Executing scheduled FoodGuard daily expiry evaluation...");
        performExpiryCheck();
    }

    @Transactional
    public void performExpiryCheck() {
        LocalDate today = LocalDate.now();
        LocalDateTime oneDayAgo = LocalDateTime.now().minusHours(23);

        List<FoodItem> allItems = foodItemRepository.findAll();
        int alertCount = 0;

        for (FoodItem item : allItems) {
            User user = item.getUser();
            long daysLeft = ChronoUnit.DAYS.between(today, item.getExpiryDate());

            if (daysLeft < 0) {
                // Item is Expired
                boolean alreadyNotified = notificationRepository.existsByUserIdAndFoodItemIdAndTypeAndCreatedAtAfter(
                        user.getId(), item.getId(), "EXPIRED", oneDayAgo
                );

                if (!alreadyNotified) {
                    String title = "Item Expired: " + item.getName();
                    String message = String.format("'%s' expired on %s (%d days ago). Please audit your inventory.",
                            item.getName(), item.getFormattedExpiryDate(), Math.abs(daysLeft));
                    notificationService.createNotification(user, item.getId(), title, message, "EXPIRED");
                    emailAlertService.sendExpiryAlert(user, item, "Expired");
                    alertCount++;
                }
            } else if (daysLeft <= user.getAlertDaysBefore()) {
                // Item is Expiring Soon
                boolean alreadyNotified = notificationRepository.existsByUserIdAndFoodItemIdAndTypeAndCreatedAtAfter(
                        user.getId(), item.getId(), "EXPIRING_SOON", oneDayAgo
                );

                if (!alreadyNotified) {
                    String countdown = (daysLeft == 0) ? "today!" : (daysLeft == 1 ? "tomorrow" : "in " + daysLeft + " days");
                    String title = "Expiring Soon: " + item.getName();
                    String message = String.format("'%s' expires %s (%s). Check recommended recipes to use it now!",
                            item.getName(), countdown, item.getFormattedExpiryDate());
                    notificationService.createNotification(user, item.getId(), title, message, "EXPIRING_SOON");
                    emailAlertService.sendExpiryAlert(user, item, "Expiring Soon (" + countdown + ")");
                    alertCount++;
                }
            }
        }

        logger.info("FoodGuard Expiry Check completed. Created {} new alerts.", alertCount);
    }
}
