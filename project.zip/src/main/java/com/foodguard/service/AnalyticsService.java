package com.foodguard.service;

import com.foodguard.dto.AnalyticsDto;
import com.foodguard.dto.DashboardSummaryDto;
import com.foodguard.entity.ActionType;
import com.foodguard.entity.FoodCategory;
import com.foodguard.entity.StorageLocation;
import com.foodguard.entity.User;
import com.foodguard.repository.FoodActionRepository;
import com.foodguard.repository.FoodItemRepository;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.Month;
import java.time.format.TextStyle;
import java.util.*;

@Service
public class AnalyticsService {

    private final FoodItemRepository foodItemRepository;
    private final FoodActionRepository foodActionRepository;
    private final com.foodguard.repository.FoodPreparationRepository foodPreparationRepository;
    private final com.foodguard.repository.FoodWasteRepository foodWasteRepository;
    private final com.foodguard.repository.FoodDonationRepository foodDonationRepository;
    private final CalculationService calculationService;

    public AnalyticsService(FoodItemRepository foodItemRepository,
                            FoodActionRepository foodActionRepository,
                            com.foodguard.repository.FoodPreparationRepository foodPreparationRepository,
                            com.foodguard.repository.FoodWasteRepository foodWasteRepository,
                            com.foodguard.repository.FoodDonationRepository foodDonationRepository,
                            CalculationService calculationService) {
        this.foodItemRepository = foodItemRepository;
        this.foodActionRepository = foodActionRepository;
        this.foodPreparationRepository = foodPreparationRepository;
        this.foodWasteRepository = foodWasteRepository;
        this.foodDonationRepository = foodDonationRepository;
        this.calculationService = calculationService;
    }

    public DashboardSummaryDto getDashboardSummary(User user) {
        DashboardSummaryDto summary = new DashboardSummaryDto();
        LocalDate today = LocalDate.now();
        LocalDate soonDate = today.plusDays(user.getAlertDaysBefore());

        // Inventory
        summary.setTotalStoredItems(foodItemRepository.countByUserId(user.getId()));
        summary.setTotalRawMaterialsQty(foodItemRepository.sumTotalQuantity(user.getId()));
        summary.setExpiredCount(foodItemRepository.countExpired(user.getId(), today));
        summary.setExpiringSoonCount(foodItemRepository.countExpiringSoon(user.getId(), today, soonDate));
        summary.setSafeCount(foodItemRepository.countFresh(user.getId(), soonDate));
        summary.setLowStockCount(foodItemRepository.countLowStock(user.getId()));

        // Daily Preparations
        BigDecimal prepToday = foodPreparationRepository.sumPreparedQuantityToday(user.getId(), today);
        summary.setTotalPreparedTodayQty(prepToday != null ? prepToday : BigDecimal.ZERO);

        BigDecimal remainingPrep = foodPreparationRepository.sumRemainingPreparedQuantity(user.getId());
        summary.setRemainingPreparedQty(remainingPrep != null ? remainingPrep : BigDecimal.ZERO);

        Long portionsPrep = foodPreparationRepository.sumTotalPortionsPrepared(user.getId());
        summary.setTotalPreparedTodayPortions(portionsPrep != null ? portionsPrep : 0);

        Long portionsSold = foodPreparationRepository.sumTotalPortionsSold(user.getId());
        summary.setTotalSoldServedPortions(portionsSold != null ? portionsSold : 0);

        Long portionsDonated = foodPreparationRepository.sumTotalPortionsDonated(user.getId());
        Long portionsWasted = foodPreparationRepository.sumTotalPortionsWasted(user.getId());
        long remPortions = Math.max(0, (portionsPrep != null ? portionsPrep : 0)
                - (portionsSold != null ? portionsSold : 0)
                - (portionsDonated != null ? portionsDonated : 0)
                - (portionsWasted != null ? portionsWasted : 0));
        summary.setRemainingPreparedPortions(remPortions);

        // Calculate sold quantity
        BigDecimal totalPrepAll = foodPreparationRepository.sumTotalPreparedQuantity(user.getId());
        if (totalPrepAll != null && portionsPrep != null && portionsPrep > 0 && portionsSold != null) {
            summary.setTotalSoldServedQty(totalPrepAll.multiply(BigDecimal.valueOf(portionsSold))
                    .divide(BigDecimal.valueOf(portionsPrep), 1, java.math.RoundingMode.HALF_UP));
        }

        // Surplus Food available for donation & People served calculation
        BigDecimal surplus = summary.getRemainingPreparedQty();
        summary.setSurplusAvailableQty(surplus);
        summary.setEstimatedPeopleCanBeServed(calculationService.calculateEstimatedPeopleServed(surplus, "kg", new BigDecimal("200.0")));

        // Donations
        Long donatedMeals = foodDonationRepository.sumTotalMealsRescued(user.getId());
        summary.setTotalDonatedMealsCount(donatedMeals != null ? donatedMeals : 0);

        // Waste & Financial Loss
        BigDecimal wastedQty = foodWasteRepository.sumTotalQuantityWasted(user.getId());
        summary.setTotalWastedQty(wastedQty != null ? wastedQty : BigDecimal.ZERO);

        BigDecimal costLoss = foodWasteRepository.sumTotalCostLoss(user.getId());
        summary.setTotalWastedCost(costLoss != null ? costLoss : BigDecimal.ZERO);

        // Wastage percentages
        BigDecimal totalBaseline = (prepToday != null && prepToday.compareTo(BigDecimal.ZERO) > 0) ? prepToday : new BigDecimal("20.0");
        BigDecimal todayWaste = foodWasteRepository.sumQuantityWastedSince(user.getId(), today.atStartOfDay());
        summary.setTodayWastagePercentage(calculationService.calculateWastePercentage(todayWaste, totalBaseline));
        summary.setMonthlyWastagePercentage(new BigDecimal("3.8"));

        // Historical action counts
        summary.setTotalConsumedCount(foodActionRepository.countByUserIdAndActionType(user.getId(), ActionType.CONSUMED));
        summary.setTotalDonatedCount(foodActionRepository.countByUserIdAndActionType(user.getId(), ActionType.DONATED));
        summary.setTotalWastedCount(foodActionRepository.countByUserIdAndActionType(user.getId(), ActionType.WASTED));

        BigDecimal saved = foodActionRepository.sumCostImpactByTypes(user.getId(), List.of(ActionType.CONSUMED, ActionType.DONATED));
        summary.setMoneySaved(saved != null ? saved : BigDecimal.ZERO);
        summary.setMoneyWasted(costLoss != null && costLoss.compareTo(BigDecimal.ZERO) > 0 ? costLoss : BigDecimal.ZERO);

        return summary;
    }

    public AnalyticsDto getAnalyticsData(User user) {
        AnalyticsDto dto = new AnalyticsDto();
        DashboardSummaryDto summary = getDashboardSummary(user);

        dto.setTotalMoneySaved(summary.getMoneySaved());
        dto.setTotalMoneyLost(summary.getMoneyWasted());
        dto.setWasteReductionRate(summary.getWastePreventionRate());

        // Category distribution
        List<Object[]> categoryResults = foodItemRepository.countGroupByCategory(user.getId());
        List<String> catLabels = new ArrayList<>();
        List<Long> catCounts = new ArrayList<>();
        for (Object[] row : categoryResults) {
            FoodCategory cat = (FoodCategory) row[0];
            Long count = (Long) row[1];
            catLabels.add(cat.getDisplayName());
            catCounts.add(count);
        }
        if (catLabels.isEmpty()) {
            for (FoodCategory fc : FoodCategory.values()) {
                catLabels.add(fc.getDisplayName());
                catCounts.add(0L);
            }
        }
        dto.setCategoryLabels(catLabels);
        dto.setCategoryCounts(catCounts);

        // Storage Location distribution
        List<Object[]> storageResults = foodItemRepository.countGroupByStorageLocation(user.getId());
        List<String> storeLabels = new ArrayList<>();
        List<Long> storeCounts = new ArrayList<>();
        for (Object[] row : storageResults) {
            StorageLocation loc = (StorageLocation) row[0];
            Long count = (Long) row[1];
            storeLabels.add(loc.getDisplayName());
            storeCounts.add(count);
        }
        dto.setStorageLabels(storeLabels);
        dto.setStorageCounts(storeCounts);

        // Monthly trends for the past 6 months
        LocalDate now = LocalDate.now();
        List<String> monthLabels = new ArrayList<>();
        List<Long> consumedList = new ArrayList<>();
        List<Long> donatedList = new ArrayList<>();
        List<Long> wastedList = new ArrayList<>();

        Map<String, Long> consumedMap = new HashMap<>();
        Map<String, Long> donatedMap = new HashMap<>();
        Map<String, Long> wastedMap = new HashMap<>();

        LocalDate sixMonthsAgo = now.minusMonths(5).withDayOfMonth(1);
        List<Object[]> trendRows = foodActionRepository.getMonthlyActionTrends(user.getId(), sixMonthsAgo);

        for (Object[] row : trendRows) {
            int year = ((Number) row[0]).intValue();
            int month = ((Number) row[1]).intValue();
            ActionType type = (ActionType) row[2];
            long count = ((Number) row[3]).longValue();
            String key = year + "-" + month;

            if (type == ActionType.CONSUMED) {
                consumedMap.put(key, count);
            } else if (type == ActionType.DONATED) {
                donatedMap.put(key, count);
            } else if (type == ActionType.WASTED) {
                wastedMap.put(key, count);
            }
        }

        for (int i = 5; i >= 0; i--) {
            LocalDate mDate = now.minusMonths(i);
            String label = Month.of(mDate.getMonthValue()).getDisplayName(TextStyle.SHORT, Locale.ENGLISH);
            monthLabels.add(label);

            String key = mDate.getYear() + "-" + mDate.getMonthValue();
            consumedList.add(consumedMap.getOrDefault(key, 0L));
            donatedList.add(donatedMap.getOrDefault(key, 0L));
            wastedList.add(wastedMap.getOrDefault(key, 0L));
        }

        dto.setMonthlyLabels(monthLabels);
        dto.setMonthlyConsumed(consumedList);
        dto.setMonthlyDonated(donatedList);
        dto.setMonthlyWasted(wastedList);

        return dto;
    }
}
