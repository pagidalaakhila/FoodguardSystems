package com.foodguard.service;

import com.foodguard.entity.FoodItem;
import com.foodguard.entity.User;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

@Service
public class EmailAlertService {

    private static final Logger logger = LoggerFactory.getLogger(EmailAlertService.class);

    @Value("${foodguard.mail.enabled:false}")
    private boolean mailEnabled;

    @Autowired(required = false)
    private JavaMailSender mailSender;

    public void sendExpiryAlert(User user, FoodItem item, String statusText) {
        if (!user.isEmailAlertsEnabled()) {
            return;
        }

        String subject = "FoodGuard Alert: " + item.getName() + " is " + statusText;
        String content = String.format(
                "Hello %s,\n\n" +
                "This is a friendly reminder from FoodGuard.\n" +
                "Item: %s (%s %s)\n" +
                "Status: %s\n" +
                "Expiry Date: %s\n" +
                "Storage Location: %s\n\n" +
                "Visit your FoodGuard dashboard to view recipe ideas or log this item to prevent waste!\n\n" +
                "— The FoodGuard Team",
                user.getFullName(),
                item.getName(),
                item.getQuantity(),
                item.getUnit(),
                statusText,
                item.getFormattedExpiryDate(),
                item.getStorageLocation().getDisplayName()
        );

        if (mailEnabled && mailSender != null) {
            try {
                SimpleMailMessage message = new SimpleMailMessage();
                message.setTo(user.getEmail());
                message.setSubject(subject);
                message.setText(content);
                mailSender.send(message);
                logger.info("Sent email expiry alert to {} for item {}", user.getEmail(), item.getName());
            } catch (Exception e) {
                logger.warn("Could not dispatch email to {}: {}", user.getEmail(), e.getMessage());
            }
        } else {
            logger.info("[EMAIL ALERT SIMULATION] To: {} | Subject: {} | Message: \n{}",
                    user.getEmail(), subject, content);
        }
    }
}
