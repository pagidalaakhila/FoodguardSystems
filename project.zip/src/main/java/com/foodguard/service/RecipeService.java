package com.foodguard.service;

import com.foodguard.entity.FoodItem;
import com.foodguard.entity.Recipe;
import com.foodguard.entity.User;
import com.foodguard.exception.ResourceNotFoundException;
import com.foodguard.repository.FoodItemRepository;
import com.foodguard.repository.RecipeRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;
import java.util.stream.Collectors;

@Service
public class RecipeService {

    private final RecipeRepository recipeRepository;
    private final FoodItemRepository foodItemRepository;

    public RecipeService(RecipeRepository recipeRepository, FoodItemRepository foodItemRepository) {
        this.recipeRepository = recipeRepository;
        this.foodItemRepository = foodItemRepository;
    }

    public List<Recipe> getAllRecipes() {
        return recipeRepository.findAll();
    }

    public Recipe getRecipeById(Long id) {
        return recipeRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Recipe not found with ID: " + id));
    }

    public Recipe getRecipeByIdWithUserStock(Long id, User user) {
        Recipe recipe = getRecipeById(id);
        if (user == null) {
            return recipe;
        }

        List<FoodItem> userItems = foodItemRepository.findByUserIdOrderByExpiryDateAsc(user.getId());
        if (userItems.isEmpty()) {
            return recipe;
        }

        Recipe populated = copyRecipe(recipe);
        populateStockMatches(populated, userItems, user);
        return populated;
    }

    public List<String> getDistinctCategories() {
        return recipeRepository.findDistinctCategories();
    }

    public List<Recipe> searchRecipes(String query) {
        if (query == null || query.trim().isEmpty()) {
            return getAllRecipes();
        }
        return recipeRepository.searchRecipes(query.trim());
    }

    /**
     * Enhanced filter showing all recipes or subsets (stock matches, expiring soon, custom),
     * while calculating stock match counts against the user's active inventory.
     */
    public List<Recipe> getFilteredRecipesForUser(User user, String search, String category, String tab) {
        String cleanSearch = (search != null && !search.trim().isEmpty()) ? search.trim() : null;
        String cleanCategory = (category != null && !category.trim().isEmpty() && !"ALL".equalsIgnoreCase(category)) ? category.trim() : null;

        List<Recipe> candidateRecipes;
        if (cleanSearch != null || cleanCategory != null) {
            candidateRecipes = recipeRepository.searchRecipes(cleanSearch, cleanCategory);
        } else {
            candidateRecipes = recipeRepository.findAll();
        }

        List<FoodItem> userItems = (user != null)
                ? foodItemRepository.findByUserIdOrderByExpiryDateAsc(user.getId())
                : Collections.emptyList();

        List<Recipe> processed = new ArrayList<>();
        for (Recipe r : candidateRecipes) {
            Recipe copy = copyRecipe(r);
            if (!userItems.isEmpty() && user != null) {
                populateStockMatches(copy, userItems, user);
            }
            processed.add(copy);
        }

        // Apply Tab Filter
        String activeTab = (tab != null) ? tab.trim().toLowerCase() : "all";
        List<Recipe> filtered = new ArrayList<>();

        for (Recipe r : processed) {
            boolean keep = true;
            switch (activeTab) {
                case "stock":
                    keep = (r.getMatchedIngredientsCount() > 0);
                    break;
                case "expiring":
                    keep = hasExpiringMatch(r, userItems, user);
                    break;
                case "custom":
                    keep = r.isCustom();
                    break;
                case "all":
                default:
                    keep = true;
                    break;
            }
            if (keep) {
                filtered.add(r);
            }
        }

        // Sort: Prioritize inventory matches, then alphabetical
        filtered.sort((r1, r2) -> {
            int cmp = Integer.compare(r2.getMatchedIngredientsCount(), r1.getMatchedIngredientsCount());
            if (cmp != 0) return cmp;
            return r1.getTitle().compareToIgnoreCase(r2.getTitle());
        });

        return filtered;
    }

    /**
     * Recommends recipes for user dashboard.
     */
    public List<Recipe> getSuggestedRecipesForUser(User user) {
        return getFilteredRecipesForUser(user, null, null, "all");
    }

    private void populateStockMatches(Recipe recipe, List<FoodItem> userItems, User user) {
        int matchCount = 0;
        List<String> matchedNames = new ArrayList<>();
        String recipeContent = (recipe.getTitle() + " " + recipe.getIngredientsText() + " " + recipe.getDescription()).toLowerCase();

        for (FoodItem item : userItems) {
            String itemName = item.getName().toLowerCase().trim();
            if (recipeContent.contains(itemName) || containsWord(recipeContent, itemName)) {
                matchCount++;
                if (user != null && item.getDaysUntilExpiry() <= user.getAlertDaysBefore()) {
                    matchCount += 2; // bonus weight for expiring soon
                }
                if (!matchedNames.contains(item.getName())) {
                    matchedNames.add(item.getName());
                }
            }
        }

        recipe.setMatchedIngredientsCount(matchCount);
        recipe.setMatchedItemNames(matchedNames);
    }

    private boolean hasExpiringMatch(Recipe recipe, List<FoodItem> userItems, User user) {
        if (user == null || recipe.getMatchedItemNames().isEmpty()) {
            return false;
        }
        for (FoodItem item : userItems) {
            if (recipe.getMatchedItemNames().contains(item.getName()) &&
                    item.getDaysUntilExpiry() <= user.getAlertDaysBefore()) {
                return true;
            }
        }
        return false;
    }

    private boolean containsWord(String text, String word) {
        String[] tokens = word.split("\\s+");
        for (String token : tokens) {
            if (token.length() > 2 && text.contains(token)) {
                return true;
            }
        }
        return false;
    }

    private Recipe copyRecipe(Recipe orig) {
        Recipe r = new Recipe(
                orig.getTitle(),
                orig.getDescription(),
                orig.getCategory(),
                orig.getPrepTimeMinutes(),
                orig.getIngredientsText(),
                orig.getInstructions(),
                orig.getImageUrl(),
                orig.isCustom(),
                orig.getCreatedBy()
        );
        r.setId(orig.getId());
        return r;
    }

    /**
     * Smart Recipe Generator: Synthesizes a realistic, creative, chef-quality zero-waste recipe
     * using the user's selected inventory items and culinary preferences.
     */
    @Transactional
    public Recipe generateRecipe(
            User user,
            List<Long> selectedFoodItemIds,
            String customIngredients,
            String preferredCategory,
            Integer preferredPrepTime,
            String cookingStyle,
            String dietary
    ) {
        List<String> ingredients = new ArrayList<>();

        // 1. Gather selected inventory items
        if (selectedFoodItemIds != null && !selectedFoodItemIds.isEmpty()) {
            List<FoodItem> items = foodItemRepository.findAllById(selectedFoodItemIds);
            for (FoodItem item : items) {
                ingredients.add(item.getName());
            }
        }

        // 2. Add custom ingredients
        if (customIngredients != null && !customIngredients.isBlank()) {
            String[] customArray = customIngredients.split("[,;\\n]+");
            for (String c : customArray) {
                String clean = c.trim();
                if (!clean.isEmpty() && !ingredients.contains(clean)) {
                    ingredients.add(clean);
                }
            }
        }

        // 3. Fallback if empty: pick user's expiring items or default staples
        if (ingredients.isEmpty() && user != null) {
            List<FoodItem> userItems = foodItemRepository.findByUserIdOrderByExpiryDateAsc(user.getId());
            if (!userItems.isEmpty()) {
                ingredients.add(userItems.get(0).getName());
                if (userItems.size() > 1) {
                    ingredients.add(userItems.get(1).getName());
                }
            }
        }
        if (ingredients.isEmpty()) {
            ingredients.add("Vegetables");
            ingredients.add("Eggs");
            ingredients.add("Olive Oil");
        }

        // Determine Category
        String category = (preferredCategory != null && !preferredCategory.isBlank() && !"Any".equalsIgnoreCase(preferredCategory))
                ? preferredCategory.trim()
                : inferCategory(ingredients);

        int prepTime = (preferredPrepTime != null && preferredPrepTime > 0) ? preferredPrepTime : 20;
        String style = (cookingStyle != null && !cookingStyle.isBlank()) ? cookingStyle.trim() : "Savory & Quick";

        // Culinary synthesis for Title, Description, Ingredients, Steps, and Image
        String title = synthesizeTitle(ingredients, category, style);
        String description = synthesizeDescription(ingredients, category, style);
        String fullIngredients = synthesizeIngredientsText(ingredients, style);
        String instructions = synthesizeInstructions(ingredients, category, style, prepTime);
        String imageUrl = pickCulinaryImage(category, ingredients);

        Recipe generatedRecipe = new Recipe(
                title,
                description,
                category,
                prepTime,
                fullIngredients,
                instructions,
                imageUrl,
                true,
                user
        );

        return recipeRepository.save(generatedRecipe);
    }

    @Transactional
    public Recipe saveCustomRecipe(Recipe recipe, User user) {
        recipe.setCustom(true);
        recipe.setCreatedBy(user);
        if (recipe.getImageUrl() == null || recipe.getImageUrl().isBlank()) {
            recipe.setImageUrl(pickCulinaryImage(recipe.getCategory(), List.of(recipe.getTitle())));
        }
        return recipeRepository.save(recipe);
    }

    @Transactional
    public void deleteRecipe(Long id, User currentUser) {
        Recipe recipe = getRecipeById(id);
        if (recipe.isCustom()) {
            if (recipe.getCreatedBy() == null ||
                recipe.getCreatedBy().getId().equals(currentUser.getId()) ||
                "ROLE_ADMIN".equals(currentUser.getRole())) {
                recipeRepository.delete(recipe);
                return;
            }
        }
        throw new IllegalArgumentException("You do not have permission to delete this recipe.");
    }

    private String inferCategory(List<String> ingredients) {
        String joined = String.join(" ", ingredients).toLowerCase();
        if (joined.contains("egg") || joined.contains("oat") || joined.contains("banana") || joined.contains("pancake") || joined.contains("yogurt")) {
            return "Breakfast & Brunch";
        } else if (joined.contains("bread") || joined.contains("toast") || joined.contains("salad") || joined.contains("wrap") || joined.contains("sandwich")) {
            return "Lunch & Snacks";
        } else if (joined.contains("soup") || joined.contains("broth") || joined.contains("lentil")) {
            return "Soups & Stews";
        } else if (joined.contains("cake") || joined.contains("cookie") || joined.contains("muffin") || joined.contains("sugar") || joined.contains("flour")) {
            return "Bakery & Treats";
        }
        return "Dinner";
    }

    private String synthesizeTitle(List<String> ingredients, String category, String style) {
        String primary = cleanIngredientName(ingredients.get(0));
        String secondary = (ingredients.size() > 1) ? cleanIngredientName(ingredients.get(1)) : null;

        String ingPair = (secondary != null) ? primary + " & " + secondary : primary;

        if (category.contains("Breakfast")) {
            if (ingPair.toLowerCase().contains("egg")) return "Artisan " + ingPair + " Skillet Frittata";
            if (ingPair.toLowerCase().contains("banana") || ingPair.toLowerCase().contains("oat")) return "Warm Cinnamon " + ingPair + " Breakfast Bake";
            return "Sunrise " + ingPair + " Morning Hash";
        } else if (category.contains("Soups") || category.contains("Stews")) {
            return "Hearty Farmhouse " + ingPair + " Broth";
        } else if (category.contains("Lunch") || category.contains("Snacks")) {
            if (ingPair.toLowerCase().contains("bread") || ingPair.toLowerCase().contains("toast") || ingPair.toLowerCase().contains("cheese")) {
                return "Crispy Golden " + ingPair + " Gourmet Melt";
            }
            return "Fresh Zesty " + ingPair + " Power Bowl";
        } else if (category.contains("Bakery")) {
            return "Rustic Zero-Waste " + ingPair + " Treat";
        } else {
            if (ingPair.toLowerCase().contains("rice")) return "Golden Garlic " + ingPair + " Fried Rice";
            if (ingPair.toLowerCase().contains("pasta")) return "One-Pan Creamy " + ingPair + " Pasta";
            if (ingPair.toLowerCase().contains("chicken")) return "Cast-Iron Herb Roasted " + ingPair;
            return "Chef's " + style + " " + ingPair + " Sauté";
        }
    }

    private String synthesizeDescription(List<String> ingredients, String category, String style) {
        String list = ingredients.stream().map(this::cleanIngredientName).collect(Collectors.joining(", "));
        return "An inventive, chef-curated zero-waste meal crafted to turn your kitchen staples (" + list + ") into a fragrant " +
                style.toLowerCase() + " masterpiece. Designed to eliminate food spoilage while treating your palate to maximum flavor.";
    }

    private String synthesizeIngredientsText(List<String> ingredients, String style) {
        List<String> completeList = new ArrayList<>();
        for (String ing : ingredients) {
            completeList.add(ing.trim().toLowerCase());
        }

        // Add complimentary kitchen essentials if not present
        List<String> staples = List.of("olive oil", "minced garlic", "sea salt", "black pepper", "fresh herbs");
        for (String staple : staples) {
            if (!completeList.contains(staple)) {
                completeList.add(staple);
            }
        }
        return String.join(", ", completeList);
    }

    private String synthesizeInstructions(List<String> ingredients, String category, String style, int prepTime) {
        String main1 = cleanIngredientName(ingredients.get(0));
        String main2 = (ingredients.size() > 1) ? cleanIngredientName(ingredients.get(1)) : "remaining vegetables";

        return "1. Preparation & Mise en Place (" + (prepTime / 4) + " mins):\n" +
               "Rinse and prep " + main1 + " and " + main2 + ". Finely mince garlic and measure your seasoning. Having ingredients chopped and within reach ensures even, golden cooking.\n\n" +
               "2. Sizzle Aromatics & Base Flavor:\n" +
               "Heat 1-2 tbsp olive oil or butter in a wide heavy skillet over medium-high heat. Add garlic and hearty ingredients, tossing gently until aromatic and lightly browned (2-3 minutes).\n\n" +
               "3. Incorporate & Sauté Main Ingredients:\n" +
               "Introduce " + main1 + " and " + main2 + " into the skillet. Cook evenly for 6-8 minutes, allowing natural flavors and juices to caramelize. Stir occasionally to achieve a rich golden texture.\n\n" +
               "4. Season, Blend & Finish (" + style + "):\n" +
               "Fold in delicate greens or tender additions. Season generously with sea salt, freshly cracked black pepper, and herbs. Reduce heat to low, cover briefly for 2 minutes to let all aromatics marry together.\n\n" +
               "5. Plating & Zero-Waste Kitchen Note:\n" +
               "Transfer steaming hot to your serving dish. Garnish with cracked pepper or fresh herb sprigs. Store any remaining portions in an airtight container for up to 3 days.";
    }

    private String pickCulinaryImage(String category, List<String> ingredients) {
        String joined = (category + " " + String.join(" ", ingredients)).toLowerCase();

        if (joined.contains("pasta") || joined.contains("noodle")) {
            return "https://images.unsplash.com/photo-1621996346565-e3d5d6281292?auto=format&fit=crop&w=600&q=80";
        } else if (joined.contains("rice") || joined.contains("stir-fry")) {
            return "https://images.unsplash.com/photo-1603133872878-684f208fb84b?auto=format&fit=crop&w=600&q=80";
        } else if (joined.contains("chicken") || joined.contains("meat")) {
            return "https://images.unsplash.com/photo-1598515214211-89d3c73ae83b?auto=format&fit=crop&w=600&q=80";
        } else if (joined.contains("egg") || joined.contains("frittata") || joined.contains("scramble")) {
            return "https://images.unsplash.com/photo-1584776296944-ab6fb57b0bdd?auto=format&fit=crop&w=600&q=80";
        } else if (joined.contains("banana") || joined.contains("pancake") || joined.contains("bake") || joined.contains("bread")) {
            return "https://images.unsplash.com/photo-1607958996333-41aef7caef4b?auto=format&fit=crop&w=600&q=80";
        } else if (joined.contains("soup") || joined.contains("stew") || joined.contains("lentil")) {
            return "https://images.unsplash.com/photo-1547592166-23ac45744acd?auto=format&fit=crop&w=600&q=80";
        } else if (joined.contains("toast") || joined.contains("sourdough") || joined.contains("sandwich") || joined.contains("melt")) {
            return "https://images.unsplash.com/photo-1525351484163-7529414344d8?auto=format&fit=crop&w=600&q=80";
        } else if (joined.contains("potato") || joined.contains("hash")) {
            return "https://images.unsplash.com/photo-1510693206972-df098062cb71?auto=format&fit=crop&w=600&q=80";
        } else if (joined.contains("yogurt") || joined.contains("berry") || joined.contains("fruit") || joined.contains("oats")) {
            return "https://images.unsplash.com/photo-1488477181946-6428a0291777?auto=format&fit=crop&w=600&q=80";
        }
        return "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?auto=format&fit=crop&w=600&q=80";
    }

    private String cleanIngredientName(String name) {
        return name.replaceAll("(?i)\\b(organic|fresh|ripe|large|small|raw|frozen|canned)\\b", "").trim();
    }
}
