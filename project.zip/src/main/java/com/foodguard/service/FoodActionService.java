package com.foodguard.service;

import com.foodguard.dto.FoodActionDto;
import com.foodguard.entity.ActionType;
import com.foodguard.entity.FoodAction;
import com.foodguard.entity.FoodItem;
import com.foodguard.entity.User;
import com.foodguard.exception.ResourceNotFoundException;
import com.foodguard.exception.UnauthorizedException;
import com.foodguard.repository.FoodActionRepository;
import com.foodguard.repository.FoodItemRepository;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.util.List;

@Service
public class FoodActionService {

    private final FoodActionRepository foodActionRepository;
    private final FoodItemRepository foodItemRepository;

    public FoodActionService(FoodActionRepository foodActionRepository, FoodItemRepository foodItemRepository) {
        this.foodActionRepository = foodActionRepository;
        this.foodItemRepository = foodItemRepository;
    }

    @Transactional
    public FoodAction logAction(FoodActionDto dto, User user) {
        FoodItem item = foodItemRepository.findById(dto.getFoodItemId())
                .orElseThrow(() -> new ResourceNotFoundException("Food item not found with ID: " + dto.getFoodItemId()));

        if (!item.getUser().getId().equals(user.getId())) {
            throw new UnauthorizedException("You are not authorized to log actions for this food item.");
        }

        BigDecimal actionQty = dto.getQuantity();
        if (actionQty.compareTo(BigDecimal.ZERO) <= 0) {
            throw new IllegalArgumentException("Quantity must be greater than zero.");
        }

        BigDecimal currentQty = item.getQuantity();
        if (actionQty.compareTo(currentQty) > 0) {
            throw new IllegalArgumentException("Action quantity (" + actionQty + ") cannot exceed available inventory (" + currentQty + ").");
        }

        // Calculate proportional cost impact
        BigDecimal itemCost = item.getCost() != null ? item.getCost() : BigDecimal.ZERO;
        BigDecimal costImpact = BigDecimal.ZERO;
        if (currentQty.compareTo(BigDecimal.ZERO) > 0 && itemCost.compareTo(BigDecimal.ZERO) > 0) {
            costImpact = itemCost.multiply(actionQty).divide(currentQty, 2, RoundingMode.HALF_UP);
        }

        // Create FoodAction audit record
        FoodAction action = new FoodAction();
        action.setUser(user);
        action.setFoodItemId(item.getId());
        action.setItemName(item.getName());
        action.setCategory(item.getCategory());
        action.setActionType(dto.getActionType());
        action.setQuantity(actionQty);
        action.setUnit(item.getUnit());
        action.setCostImpact(costImpact);
        action.setActionDate(LocalDate.now());
        action.setNotes(dto.getNotes() != null ? dto.getNotes().trim() : "");

        FoodAction savedAction = foodActionRepository.save(action);

        // Adjust or delete inventory item
        BigDecimal remainingQty = currentQty.subtract(actionQty).setScale(2, RoundingMode.HALF_UP);
        if (remainingQty.compareTo(BigDecimal.ZERO) <= 0) {
            foodItemRepository.delete(item);
        } else {
            item.setQuantity(remainingQty);
            BigDecimal remainingCost = itemCost.subtract(costImpact).setScale(2, RoundingMode.HALF_UP);
            if (remainingCost.compareTo(BigDecimal.ZERO) < 0) {
                remainingCost = BigDecimal.ZERO;
            }
            item.setCost(remainingCost);
            foodItemRepository.save(item);
        }

        return savedAction;
    }

    public Page<FoodAction> getUserActions(User user, ActionType actionType, String keyword, int page, int size) {
        Pageable pageable = PageRequest.of(Math.max(0, page), size);
        String cleanKeyword = (keyword != null && !keyword.trim().isEmpty()) ? keyword.trim() : null;
        return foodActionRepository.filterActions(user.getId(), actionType, cleanKeyword, pageable);
    }

    public List<FoodAction> getAllUserActions(User user) {
        return foodActionRepository.findByUserIdOrderByActionDateDesc(user.getId());
    }
}
