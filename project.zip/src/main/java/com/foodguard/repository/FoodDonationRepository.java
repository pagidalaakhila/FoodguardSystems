package com.foodguard.repository;

import com.foodguard.entity.DonationStatus;
import com.foodguard.entity.FoodDonation;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.util.List;

@Repository
public interface FoodDonationRepository extends JpaRepository<FoodDonation, Long> {

    List<FoodDonation> findAllByOrderByCreatedAtDesc();

    List<FoodDonation> findByStatusOrderByCreatedAtDesc(DonationStatus status);

    List<FoodDonation> findByRestaurantUserIdOrderByCreatedAtDesc(Long userId);

    @Query("SELECT COALESCE(SUM(d.estimatedMeals), 0) FROM FoodDonation d WHERE (:userId IS NULL OR d.restaurantUser.id = :userId)")
    Integer sumTotalMealsRescued(@Param("userId") Long userId);

    @Query("SELECT COALESCE(SUM(d.quantity), 0) FROM FoodDonation d WHERE (:userId IS NULL OR d.restaurantUser.id = :userId)")
    BigDecimal sumTotalWeightRescued(@Param("userId") Long userId);

    long countByStatus(DonationStatus status);

    @Query("SELECT COALESCE(SUM(d.estimatedMeals), 0) FROM FoodDonation d WHERE d.status = 'COLLECTED'")
    int sumMealsCollected();

    @Query("SELECT COALESCE(SUM(d.quantity), 0) FROM FoodDonation d WHERE d.status = 'COLLECTED'")
    BigDecimal sumQuantityCollected();

    @Query("SELECT COALESCE(SUM(d.costValue), 0) FROM FoodDonation d WHERE d.status = 'COLLECTED'")
    BigDecimal sumCostValueCollected();
}
