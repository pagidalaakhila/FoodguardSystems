package com.foodguard.repository;

import com.foodguard.entity.FoodConsumption;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.util.List;

@Repository
public interface FoodConsumptionRepository extends JpaRepository<FoodConsumption, Long> {

    List<FoodConsumption> findByUserIdOrderByConsumptionTimeDesc(Long userId);

    List<FoodConsumption> findByFoodPreparationIdOrderByConsumptionTimeDesc(Long foodPrepId);

    @Query("SELECT COALESCE(SUM(c.quantitySold), 0) FROM FoodConsumption c WHERE c.user.id = :userId")
    BigDecimal sumTotalQuantitySold(@Param("userId") Long userId);

    @Query("SELECT COALESCE(SUM(c.revenue), 0) FROM FoodConsumption c WHERE c.user.id = :userId")
    BigDecimal sumTotalRevenue(@Param("userId") Long userId);

    @Query("SELECT COALESCE(SUM(c.portionsSold), 0) FROM FoodConsumption c WHERE c.user.id = :userId")
    Long sumTotalPortionsSold(@Param("userId") Long userId);
}
