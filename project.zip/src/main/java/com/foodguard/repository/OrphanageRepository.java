package com.foodguard.repository;

import com.foodguard.entity.Orphanage;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface OrphanageRepository extends JpaRepository<Orphanage, Long> {

    List<Orphanage> findAllByOrderByDistanceKmAsc();

    boolean existsByName(String name);
}
