package com.foodguard.repository;

import com.foodguard.entity.FoodPreparation;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

@Repository
public interface FoodPreparationRepository extends JpaRepository<FoodPreparation, Long> {

    List<FoodPreparation> findByUserIdOrderByPrepDateDescIdDesc(Long userId);

    List<FoodPreparation> findByUserIdAndPrepDate(Long userId, LocalDate prepDate);

    @Query("SELECT p FROM FoodPreparation p WHERE p.user.id = :userId AND p.remainingPortions > 0 AND p.expiryDateTime > CURRENT_TIMESTAMP ORDER BY p.expiryDateTime ASC")
    List<FoodPreparation> findAvailableSurplusPreps(@Param("userId") Long userId);

    @Query("SELECT COALESCE(SUM(p.quantityPrepared), 0) FROM FoodPreparation p WHERE p.user.id = :userId AND p.prepDate = :date")
    BigDecimal sumPreparedQuantityToday(@Param("userId") Long userId, @Param("date") LocalDate date);

    @Query("SELECT COALESCE(SUM(p.quantityPrepared), 0) FROM FoodPreparation p WHERE p.user.id = :userId")
    BigDecimal sumTotalPreparedQuantity(@Param("userId") Long userId);

    @Query("SELECT COALESCE(SUM(p.remainingQuantity), 0) FROM FoodPreparation p WHERE p.user.id = :userId AND p.remainingPortions > 0")
    BigDecimal sumRemainingPreparedQuantity(@Param("userId") Long userId);

    @Query("SELECT COALESCE(SUM(p.portionsPrepared), 0) FROM FoodPreparation p WHERE p.user.id = :userId")
    Long sumTotalPortionsPrepared(@Param("userId") Long userId);

    @Query("SELECT COALESCE(SUM(p.portionsSold), 0) FROM FoodPreparation p WHERE p.user.id = :userId")
    Long sumTotalPortionsSold(@Param("userId") Long userId);

    @Query("SELECT COALESCE(SUM(p.portionsDonated), 0) FROM FoodPreparation p WHERE p.user.id = :userId")
    Long sumTotalPortionsDonated(@Param("userId") Long userId);

    @Query("SELECT COALESCE(SUM(p.portionsWasted), 0) FROM FoodPreparation p WHERE p.user.id = :userId")
    Long sumTotalPortionsWasted(@Param("userId") Long userId);
}
