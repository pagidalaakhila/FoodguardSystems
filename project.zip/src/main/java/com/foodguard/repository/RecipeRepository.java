package com.foodguard.repository;

import com.foodguard.entity.Recipe;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface RecipeRepository extends JpaRepository<Recipe, Long> {

    @Query("SELECT r FROM Recipe r WHERE " +
           "(:query IS NULL OR :query = '' OR " +
           " LOWER(r.title) LIKE LOWER(CONCAT('%', :query, '%')) OR " +
           " LOWER(r.ingredientsText) LIKE LOWER(CONCAT('%', :query, '%')) OR " +
           " LOWER(r.description) LIKE LOWER(CONCAT('%', :query, '%')) OR " +
           " LOWER(r.category) LIKE LOWER(CONCAT('%', :query, '%'))) AND " +
           "(:category IS NULL OR :category = '' OR LOWER(r.category) = LOWER(:category))")
    List<Recipe> searchRecipes(@Param("query") String query, @Param("category") String category);

    @Query("SELECT r FROM Recipe r WHERE " +
           "LOWER(r.title) LIKE LOWER(CONCAT('%', :query, '%')) OR " +
           "LOWER(r.ingredientsText) LIKE LOWER(CONCAT('%', :query, '%')) OR " +
           "LOWER(r.category) LIKE LOWER(CONCAT('%', :query, '%'))")
    List<Recipe> searchRecipes(@Param("query") String query);

    List<Recipe> findByCategory(String category);

    boolean existsByTitle(String title);

    List<Recipe> findByCreatedById(Long userId);

    @Query("SELECT DISTINCT r.category FROM Recipe r WHERE r.category IS NOT NULL AND r.category != '' ORDER BY r.category ASC")
    List<String> findDistinctCategories();
}
