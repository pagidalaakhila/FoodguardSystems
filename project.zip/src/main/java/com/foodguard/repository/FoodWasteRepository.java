package com.foodguard.repository;

import com.foodguard.entity.FoodWaste;
import com.foodguard.entity.WasteReason;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface FoodWasteRepository extends JpaRepository<FoodWaste, Long> {

    List<FoodWaste> findByUserIdOrderByWasteDateDesc(Long userId);

    List<FoodWaste> findByUserIdAndReasonOrderByWasteDateDesc(Long userId, WasteReason reason);

    List<FoodWaste> findByUserIdAndWasteDateBetweenOrderByWasteDateDesc(Long userId, LocalDateTime start, LocalDateTime end);

    @Query("SELECT COALESCE(SUM(w.quantityWasted), 0) FROM FoodWaste w WHERE w.user.id = :userId")
    BigDecimal sumTotalQuantityWasted(@Param("userId") Long userId);

    @Query("SELECT COALESCE(SUM(w.estimatedCostLoss), 0) FROM FoodWaste w WHERE w.user.id = :userId")
    BigDecimal sumTotalCostLoss(@Param("userId") Long userId);

    @Query("SELECT COALESCE(SUM(w.quantityWasted), 0) FROM FoodWaste w WHERE w.user.id = :userId AND w.wasteDate >= :since")
    BigDecimal sumQuantityWastedSince(@Param("userId") Long userId, @Param("since") LocalDateTime since);

    @Query("SELECT COALESCE(SUM(w.estimatedCostLoss), 0) FROM FoodWaste w WHERE w.user.id = :userId AND w.wasteDate >= :since")
    BigDecimal sumCostLossSince(@Param("userId") Long userId, @Param("since") LocalDateTime since);

    @Query("SELECT w.reason, COUNT(w), SUM(w.quantityWasted), SUM(w.estimatedCostLoss) FROM FoodWaste w WHERE w.user.id = :userId GROUP BY w.reason")
    List<Object[]> getWasteSummaryByReason(@Param("userId") Long userId);
}
