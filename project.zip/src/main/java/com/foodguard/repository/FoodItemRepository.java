package com.foodguard.repository;

import com.foodguard.entity.FoodCategory;
import com.foodguard.entity.FoodItem;
import com.foodguard.entity.StorageLocation;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;

@Repository
public interface FoodItemRepository extends JpaRepository<FoodItem, Long> {

    List<FoodItem> findByUserIdOrderByExpiryDateAsc(Long userId);

    Page<FoodItem> findByUserId(Long userId, Pageable pageable);

    @Query("SELECT f FROM FoodItem f WHERE f.user.id = :userId " +
           "AND (:keyword IS NULL OR LOWER(f.name) LIKE LOWER(CONCAT('%', :keyword, '%')) OR LOWER(f.notes) LIKE LOWER(CONCAT('%', :keyword, '%'))) " +
           "AND (:category IS NULL OR f.category = :category) " +
           "AND (:location IS NULL OR f.storageLocation = :location) " +
           "AND (:status IS NULL OR " +
           "     (:status = 'EXPIRED' AND f.expiryDate < :today) OR " +
           "     (:status = 'EXPIRING_SOON' AND f.expiryDate >= :today AND f.expiryDate <= :soonDate) OR " +
           "     (:status = 'LOW_STOCK' AND (f.currentAvailableQuantity <= f.minStockLevel OR (f.currentAvailableQuantity IS NULL AND f.quantity <= f.minStockLevel))) OR " +
           "     (:status = 'FRESH' AND f.expiryDate > :soonDate))")
    Page<FoodItem> searchItems(
            @Param("userId") Long userId,
            @Param("keyword") String keyword,
            @Param("category") FoodCategory category,
            @Param("location") StorageLocation location,
            @Param("status") String status,
            @Param("today") LocalDate today,
            @Param("soonDate") LocalDate soonDate,
            Pageable pageable
    );

    long countByUserId(Long userId);

    @Query("SELECT COUNT(f) FROM FoodItem f WHERE f.user.id = :userId AND f.expiryDate < :today")
    long countExpired(@Param("userId") Long userId, @Param("today") LocalDate today);

    @Query("SELECT COUNT(f) FROM FoodItem f WHERE f.user.id = :userId AND f.expiryDate >= :today AND f.expiryDate <= :soonDate")
    long countExpiringSoon(@Param("userId") Long userId, @Param("today") LocalDate today, @Param("soonDate") LocalDate soonDate);

    @Query("SELECT COUNT(f) FROM FoodItem f WHERE f.user.id = :userId AND f.expiryDate > :soonDate")
    long countFresh(@Param("userId") Long userId, @Param("soonDate") LocalDate soonDate);

    @Query("SELECT f.category, COUNT(f) FROM FoodItem f WHERE f.user.id = :userId GROUP BY f.category")
    List<Object[]> countGroupByCategory(@Param("userId") Long userId);

    @Query("SELECT f.storageLocation, COUNT(f) FROM FoodItem f WHERE f.user.id = :userId GROUP BY f.storageLocation")
    List<Object[]> countGroupByStorageLocation(@Param("userId") Long userId);

    @Query("SELECT f FROM FoodItem f WHERE f.expiryDate <= :targetDate")
    List<FoodItem> findAllExpiringOnOrBefore(@Param("targetDate") LocalDate targetDate);

    @Query("SELECT COALESCE(SUM(f.quantity), 0) FROM FoodItem f WHERE f.user.id = :userId")
    java.math.BigDecimal sumTotalQuantity(@Param("userId") Long userId);

    @Query("SELECT COUNT(f) FROM FoodItem f WHERE f.user.id = :userId AND (COALESCE(f.currentAvailableQuantity, f.quantity) <= COALESCE(f.minStockLevel, 5.0))")
    long countLowStock(@Param("userId") Long userId);
}
