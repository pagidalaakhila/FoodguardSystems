package com.foodguard.repository;

import com.foodguard.entity.ActionType;
import com.foodguard.entity.FoodAction;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

@Repository
public interface FoodActionRepository extends JpaRepository<FoodAction, Long> {

    List<FoodAction> findByUserIdOrderByActionDateDesc(Long userId);

    Page<FoodAction> findByUserIdOrderByActionDateDesc(Long userId, Pageable pageable);

    @Query("SELECT a FROM FoodAction a WHERE a.user.id = :userId " +
           "AND (:actionType IS NULL OR a.actionType = :actionType) " +
           "AND (:keyword IS NULL OR LOWER(a.itemName) LIKE LOWER(CONCAT('%', :keyword, '%')) OR LOWER(a.notes) LIKE LOWER(CONCAT('%', :keyword, '%'))) " +
           "ORDER BY a.actionDate DESC, a.createdAt DESC")
    Page<FoodAction> filterActions(
            @Param("userId") Long userId,
            @Param("actionType") ActionType actionType,
            @Param("keyword") String keyword,
            Pageable pageable
    );

    long countByUserIdAndActionType(Long userId, ActionType actionType);

    @Query("SELECT COALESCE(SUM(a.costImpact), 0) FROM FoodAction a WHERE a.user.id = :userId AND a.actionType IN (:types)")
    BigDecimal sumCostImpactByTypes(@Param("userId") Long userId, @Param("types") List<ActionType> types);

    @Query("SELECT COALESCE(SUM(a.costImpact), 0) FROM FoodAction a WHERE a.user.id = :userId AND a.actionType = :type")
    BigDecimal sumCostImpactByType(@Param("userId") Long userId, @Param("type") ActionType type);

    @Query("SELECT FUNCTION('YEAR', a.actionDate), FUNCTION('MONTH', a.actionDate), a.actionType, COUNT(a) " +
           "FROM FoodAction a WHERE a.user.id = :userId AND a.actionDate >= :sinceDate " +
           "GROUP BY FUNCTION('YEAR', a.actionDate), FUNCTION('MONTH', a.actionDate), a.actionType " +
           "ORDER BY FUNCTION('YEAR', a.actionDate) ASC, FUNCTION('MONTH', a.actionDate) ASC")
    List<Object[]> getMonthlyActionTrends(@Param("userId") Long userId, @Param("sinceDate") LocalDate sinceDate);
}
