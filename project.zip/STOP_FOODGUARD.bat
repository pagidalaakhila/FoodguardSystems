@echo off
setlocal
title Stop FoodGuard

echo [INFO] Stopping FoodGuard process running on port 8080...
for /f "tokens=5" %%a in ('netstat -ano ^| findstr ":8080 " ^| findstr "LISTENING"') do (
    echo Terminating PID: %%a
    taskkill /F /PID %%a >nul 2>&1
)

echo [OK] FoodGuard has been stopped.
ping 127.0.0.1 -n 3 >nul
