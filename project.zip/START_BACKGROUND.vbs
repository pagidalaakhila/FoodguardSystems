Set WshShell = CreateObject("WScript.Shell")
WshShell.CurrentDirectory = "C:\Users\Administrator\Desktop\project-final"
WshShell.Run "cmd /c START_FOODGUARD.bat", 0, False
