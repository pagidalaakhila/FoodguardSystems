Set WshShell = CreateObject("WScript.Shell")
strDesktop = WshShell.SpecialFolders("Desktop")

' Remove older generic shortcut
Set fso = CreateObject("Scripting.FileSystemObject")
oldLnk = strDesktop & "\FoodGuard - Start & Open.lnk"
If fso.FileExists(oldLnk) Then
    fso.DeleteFile(oldLnk)
End If

' Create dedicated FoodGuard App shortcut
Set oShortcut = WshShell.CreateShortcut(strDesktop & "\FoodGuard.lnk")
oShortcut.TargetPath = "wscript.exe"
oShortcut.Arguments = """" & "C:\Users\Administrator\Desktop\project-final\Open_FoodGuard_App.vbs" & """"
oShortcut.WorkingDirectory = "C:\Users\Administrator\Desktop\project-final"
oShortcut.WindowStyle = 7
oShortcut.IconLocation = "C:\Users\Administrator\Desktop\project-final\foodguard.ico, 0"
oShortcut.Description = "FoodGuard - Food Expiry and Waste Prevention System"
oShortcut.Save

WScript.Echo "FoodGuard Desktop App Shortcut created successfully!"
