Set WshShell = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")

projectDir = "C:\Users\Administrator\Desktop\project-final"
appUrl = "http://localhost:8080"

Function IsServerReady()
    On Error Resume Next
    Set http = CreateObject("MSXML2.ServerXMLHTTP.6.0")
    http.setTimeouts 800, 800, 800, 800
    http.open "GET", appUrl, False
    http.send
    If Err.Number = 0 Then
        If http.status = 200 Or http.status = 302 Then
            IsServerReady = True
        Else
            IsServerReady = False
        End If
    Else
        IsServerReady = False
    End If
    Set http = Nothing
    On Error GoTo 0
End Function

' If server is not ready, start it silently
If Not IsServerReady() Then
    ' Start MySQL if not running
    WshShell.Run "net start MySQL80", 0, True
    
    ' Launch FoodGuard silently
    WshShell.CurrentDirectory = projectDir
    WshShell.Run "javaw.exe -Dfile.encoding=UTF-8 -jar """ & projectDir & "\target\foodguard-1.0.0.jar""", 0, False
    
    ' Wait until server is ready
    For i = 1 To 30
        WScript.Sleep 1000
        If IsServerReady() Then
            Exit For
        End If
    Next
End If

' Launch in standalone desktop app mode
chromePath = "C:\Program Files\Google\Chrome\Application\chrome.exe"
chromePathX86 = "C:\Program Files (x86)\Google\Chrome\Application\chrome.exe"
edgePath = "C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe"
edgePath64 = "C:\Program Files\Microsoft\Edge\Application\msedge.exe"

If fso.FileExists(chromePath) Then
    WshShell.Run """" & chromePath & """ --app=""" & appUrl & """", 3, False
ElseIf fso.FileExists(chromePathX86) Then
    WshShell.Run """" & chromePathX86 & """ --app=""" & appUrl & """", 3, False
ElseIf fso.FileExists(edgePath) Then
    WshShell.Run """" & edgePath & """ --app=""" & appUrl & """", 3, False
ElseIf fso.FileExists(edgePath64) Then
    WshShell.Run """" & edgePath64 & """ --app=""" & appUrl & """", 3, False
Else
    WshShell.Run appUrl, 3, False
End If
