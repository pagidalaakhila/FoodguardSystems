@echo off
setlocal
title FoodGuard - Food Expiry and Waste Prevention System

cd /d "C:\Users\Administrator\Desktop\project-final"

echo ========================================================
echo   FoodGuard - Food Expiry and Waste Prevention System
echo ========================================================
echo.

:: 1. Check if MySQL80 service is running
sc query MySQL80 | findstr "RUNNING" >nul 2>&1
if %ERRORLEVEL% neq 0 (
    echo [INFO] Starting MySQL80 service...
    net start MySQL80 >nul 2>&1
) else (
    echo [OK] MySQL80 service is active.
)

:: 2. Check if already running on port 8080
netstat -ano | findstr ":8080 " | findstr "LISTENING" >nul 2>&1
if %ERRORLEVEL% equ 0 (
    echo [OK] FoodGuard is already running on port 8080!
    echo Opening browser to http://localhost:8080 ...
    start http://localhost:8080
    exit /b 0
)

:: 3. Check if JAR exists, else build it
if not exist "target\foodguard-1.0.0.jar" (
    echo [INFO] Building production JAR file...
    call mvnw.cmd clean package -DskipTests
)

echo [INFO] Starting FoodGuard application...
echo Web UI will be available at: http://localhost:8080
echo.

:: Automatically open browser once initialized
start /b cmd /c "ping 127.0.0.1 -n 8 >nul & start http://localhost:8080"

:: 4. Launch JAR
java -jar "target\foodguard-1.0.0.jar"
