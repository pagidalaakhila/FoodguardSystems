# FoodGuard – Food Expiry and Waste Prevention System

FoodGuard is a full-stack, production-style web application built with **Spring Boot 3, Spring Data JPA/Hibernate, Spring Security with BCrypt, Thymeleaf, MySQL, and Chart.js**. It is designed to eradicate household grocery waste, proactively alert users before items spoil, inspire zero-waste cooking with smart recipe matching, and provide quantifiable analytics on financial savings.

---

## 🌟 Key Features

1. **Enterprise Security & Authentication**
   - User registration and login protected by **Spring Security 6** with **BCrypt password hashing** (10 salt rounds).
   - Strict per-user data isolation and server-side ownership authorization on every operation.
   - Cross-Site Request Forgery (**CSRF**) token enforcement on all mutation forms.

2. **Smart Food Inventory Management (CRUD)**
   - Track items with category (Produce, Dairy, Meat, Bakery, Pantry, Beverages, Frozen, Other), storage location (Fridge, Freezer, Pantry, Countertop), quantity, unit of measure, purchase date, expiration date, estimated cost, and notes.
   - Dynamic multi-parameter search, category filter, location filter, expiry status filter, column sorting, and pagination.

3. **Dynamic Expiry Classification Engine (`java.time.LocalDate`)**
   - Precise day-level countdown calculated from current system date.
   - Automatic classification:
     - 🟢 **Fresh & Safe**: Remaining days > user alert threshold (default > 3 days)
     - 🟡 **Expiring Soon**: 0 &le; Remaining days &le; user alert threshold
     - 🔴 **Expired**: Remaining days < 0
   - Human-friendly countdown badges (e.g., *"Expires today!"*, *"Expires in 2 days"*, *"Expired yesterday"*).

4. **Automated Scheduled Expiry Engine & In-App Alerts**
   - Spring `@Scheduled` background worker scans inventory daily at midnight (and automatically on application startup).
   - Deduplicated in-app notifications generated for urgent items to prevent notification spam.
   - Configurable email notification service with graceful fallback simulation.

5. **Partial / Full Food Action Logging & Audit Trail**
   - Log actions: **Consumed** (eaten/saved), **Donated** (community/shelter), or **Wasted** (spoiled/discarded).
   - Supports partial quantities (e.g., consume 1 out of 3 kg; the remaining 2 kg remains in inventory with proportionally adjusted cost).
   - Automatically computes financial impact: **Cost Saved** vs. **Financial Loss**.

6. **Zero-Waste Recipe Recommendation Engine**
   - Matches active pantry and refrigerator items against curated recipe database.
   - Prioritizes meals that rescue ingredients expiring soon.
   - Displays preparation time, instructions, and checklist of in-stock matched ingredients.

7. **Interactive Visual Analytics (Chart.js)**
   - Monthly trend breakdown (Multi-bar: Consumed vs. Donated vs. Wasted over the past 6 months).
   - Inventory category distribution (Doughnut chart).
   - Storage location breakdown (Horizontal bar chart).
   - Real-time financial balance scorecard: Cumulative money saved vs. lost.
   - **All metrics computed dynamically from real database queries (no hardcoded metrics).**

8. **RFC 4180 CSV Data Export**
   - Direct CSV download for active inventory.
   - Direct CSV download for historical waste & consumption audit logs.

9. **Customizable User Profile & Settings**
   - Configure custom alert window threshold (1, 2, 3, 5, 7, 14 days).
   - Toggle automated email alerts.
   - Secure password change verification.

---

## 🏗️ System Architecture

```mermaid
graph TD
    Client[Web Browser / Responsive Client]
    
    subgraph Presentation Layer
        Thymeleaf[Thymeleaf HTML5 Templates]
        CSS[Forest Green & Cream CSS Design System]
        JS[Client JS - Modals, Toasts, Chart.js]
    end

    subgraph Controller & Security Layer
        Sec[Spring Security 6 + BCrypt + CSRF]
        Controllers[MVC Controllers: Auth, Dashboard, Inventory, Actions, Recipes, Analytics, Export]
    end

    subgraph Business Logic Layer
        Services[Services: FoodItem, FoodAction, Recipe, Notification, Analytics, CsvExport]
        Scheduler[ExpiryScheduler @Scheduled]
        Email[EmailAlertService]
    end

    subgraph Data Access Layer
        JPA[Spring Data JPA / Hibernate ORM]
        Repositories[User, FoodItem, FoodAction, Notification, Recipe Repositories]
    end

    subgraph Storage Layer
        MySQL[(MySQL 8.0 Database)]
    end

    Client --> CSS
    Client --> JS
    Client --> Thymeleaf
    Thymeleaf --> Controllers
    Controllers --> Sec
    Sec --> Services
    Services --> Repositories
    Scheduler --> Services
    Services --> Email
    Repositories --> JPA
    JPA --> MySQL
```

---

## 🗄️ Database Schema & Normalized Tables

The application utilizes 5 normalized tables in MySQL (`foodguard_db`):

```sql
-- 1. Users Table
CREATE TABLE users (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    email VARCHAR(150) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    full_name VARCHAR(100) NOT NULL,
    role VARCHAR(50) NOT NULL DEFAULT 'ROLE_USER',
    alert_days_before INT NOT NULL DEFAULT 3,
    email_alerts_enabled BOOLEAN NOT NULL DEFAULT FALSE,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- 2. Food Items Table
CREATE TABLE food_items (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    user_id BIGINT NOT NULL,
    name VARCHAR(120) NOT NULL,
    category VARCHAR(50) NOT NULL,
    quantity DECIMAL(10,2) NOT NULL,
    unit VARCHAR(30) NOT NULL,
    purchase_date DATE NOT NULL,
    expiry_date DATE NOT NULL,
    storage_location VARCHAR(50) NOT NULL,
    cost DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    notes TEXT,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_food_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_user_expiry (user_id, expiry_date),
    INDEX idx_user_category (user_id, category)
);

-- 3. Food Actions Audit Table
CREATE TABLE food_actions (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    user_id BIGINT NOT NULL,
    food_item_id BIGINT NULL,
    item_name VARCHAR(120) NOT NULL,
    category VARCHAR(50) NOT NULL,
    action_type VARCHAR(30) NOT NULL,
    quantity DECIMAL(10,2) NOT NULL,
    unit VARCHAR(30) NOT NULL,
    cost_impact DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    action_date DATE NOT NULL,
    notes VARCHAR(255),
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_action_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_action_user_date (user_id, action_date)
);

-- 4. In-App Notifications Table
CREATE TABLE notifications (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    user_id BIGINT NOT NULL,
    food_item_id BIGINT NULL,
    title VARCHAR(150) NOT NULL,
    message TEXT NOT NULL,
    type VARCHAR(50) NOT NULL,
    is_read BOOLEAN NOT NULL DEFAULT FALSE,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_notif_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_notif_user_read (user_id, is_read)
);

-- 5. Zero-Waste Recipes Table
CREATE TABLE recipes (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(150) NOT NULL,
    description TEXT NOT NULL,
    category VARCHAR(50) NOT NULL,
    prep_time_minutes INT NOT NULL,
    ingredients_text TEXT NOT NULL,
    instructions TEXT NOT NULL,
    image_url VARCHAR(255)
);
```

---

## 📁 Project Folder Structure

```
project-final/
├── pom.xml                                 # Maven dependencies & plugins (Spring Boot 3.3.4)
├── mvnw / mvnw.cmd                         # Maven Wrapper scripts
├── src/
│   ├── main/
│   │   ├── java/com/foodguard/
│   │   │   ├── FoodGuardApplication.java   # Spring Boot Application entrypoint (@EnableScheduling)
│   │   │   ├── config/
│   │   │   │   ├── CustomUserDetailsService.java
│   │   │   │   └── SecurityConfig.java     # Spring Security 6, BCrypt, CSRF, Form Login
│   │   │   ├── controller/
│   │   │   │   ├── AuthController.java
│   │   │   │   ├── HomeController.java
│   │   │   │   ├── DashboardController.java
│   │   │   │   ├── InventoryController.java
│   │   │   │   ├── ActionController.java
│   │   │   │   ├── RecipeController.java
│   │   │   │   ├── AnalyticsController.java
│   │   │   │   ├── ExportController.java
│   │   │   │   ├── NotificationController.java
│   │   │   │   └── ProfileController.java
│   │   │   ├── dto/
│   │   │   │   ├── AnalyticsDto.java
│   │   │   │   ├── DashboardSummaryDto.java
│   │   │   │   ├── FoodActionDto.java
│   │   │   │   ├── FoodItemDto.java
│   │   │   │   ├── PasswordChangeDto.java
│   │   │   │   ├── ProfileUpdateDto.java
│   │   │   │   └── UserRegistrationDto.java
│   │   │   ├── entity/
│   │   │   │   ├── ActionType.java
│   │   │   │   ├── ExpiryStatus.java
│   │   │   │   ├── FoodAction.java
│   │   │   │   ├── FoodCategory.java
│   │   │   │   ├── FoodItem.java
│   │   │   │   ├── Notification.java
│   │   │   │   ├── Recipe.java
│   │   │   │   ├── StorageLocation.java
│   │   │   │   └── User.java
│   │   │   ├── exception/
│   │   │   │   ├── GlobalExceptionHandler.java
│   │   │   │   ├── ResourceNotFoundException.java
│   │   │   │   └── UnauthorizedException.java
│   │   │   ├── repository/
│   │   │   │   ├── FoodActionRepository.java
│   │   │   │   ├── FoodItemRepository.java
│   │   │   │   ├── NotificationRepository.java
│   │   │   │   ├── RecipeRepository.java
│   │   │   │   └── UserRepository.java
│   │   │   ├── service/
│   │   │   │   ├── AnalyticsService.java
│   │   │   │   ├── CsvExportService.java
│   │   │   │   ├── EmailAlertService.java
│   │   │   │   ├── ExpiryScheduler.java
│   │   │   │   ├── FoodActionService.java
│   │   │   │   ├── FoodItemService.java
│   │   │   │   ├── NotificationService.java
│   │   │   │   ├── RecipeService.java
│   │   │   │   └── UserService.java
│   │   │   └── util/
│   │   │       └── SeedDataLoader.java     # CommandLineRunner seeding users, inventory & recipes
│   │   └── resources/
│   │       ├── application.properties      # MySQL datasource, Hibernate, mail, scheduler
│   │       ├── schema.sql                  # MySQL normalized DDL
│   │       ├── static/
│   │       │   ├── css/style.css           # Forest Green & Cream Design System
│   │       │   └── js/
│   │       │       ├── app.js              # Modals, confirmation dialogs, notification badge poller
│   │       │       └── charts.js           # Chart.js renderers (trends, doughnut, storage, finance)
│   │       └── templates/
│   │           ├── layout/
│   │           │   ├── footer.html
│   │           │   ├── messages.html
│   │           │   └── navbar.html
│   │           ├── home/index.html         # Landing page
│   │           ├── auth/
│   │           │   ├── login.html
│   │           │   └── register.html
│   │           ├── dashboard/index.html
│   │           ├── inventory/
│   │           │   ├── action-modal.html
│   │           │   ├── form.html
│   │           │   └── list.html
│   │           ├── history/list.html
│   │           ├── recipes/
│   │           │   ├── detail.html
│   │           │   └── list.html
│   │           ├── analytics/index.html
│   │           ├── notifications/list.html
│   │           ├── profile/index.html
│   │           └── error/
│   │               ├── 403.html
│   │               ├── 404.html
│   │               └── 500.html
│   └── test/
│       ├── java/com/foodguard/
│       │   ├── FoodGuardApplicationTests.java
│       │   ├── controller/InventoryControllerTest.java
│       │   └── service/
│       │       ├── FoodActionServiceTest.java
│       │       └── FoodItemServiceTest.java
│       └── resources/
│           └── application-test.properties # H2 In-Memory profile for unit & integration testing
```

---

## 🚀 Step-by-Step Instructions to Run the Project

### Prerequisites
- **Java JDK 17, 21, or 25** installed
- **MySQL Server 8.0** running on `localhost:3306`

### Database Setup
The application connects with:
- Database: `foodguard_db`
- Username: `root`
- Password: `12345` (or modify `src/main/resources/application.properties` to match your local password)

If not created yet, create the database:
```sql
CREATE DATABASE IF NOT EXISTS foodguard_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
```

---

### Option A: Running from Command Line (Terminal / PowerShell)

1. Open PowerShell or Command Prompt in the project folder:
   ```powershell
   cd c:\Users\Administrator\Desktop\project-final
   ```

2. Run the automated test suite (verifies compilation and tests):
   ```powershell
   .\mvnw.cmd test
   ```

3. Launch the Spring Boot application:
   ```powershell
   .\mvnw.cmd spring-boot:run
   ```

4. Open your web browser and navigate to:
   ```
   http://localhost:8080
   ```

---

### Option B: Running in IntelliJ IDEA

1. Open **IntelliJ IDEA**.
2. Click **File -> Open...** and select the folder `c:\Users\Administrator\Desktop\project-final`.
3. Select **Open as Maven Project** if prompted.
4. Allow IntelliJ to import Maven dependencies (indicated in the bottom right corner).
5. Locate the main class at:
   `src/main/java/com/foodguard/FoodGuardApplication.java`
6. Right-click `FoodGuardApplication.java` and select **Run 'FoodGuardApplication'** (or press `Shift + F10`).
7. Open `http://localhost:8080` in your browser.

---

### Option C: Running in Spring Tool Suite (STS) / Eclipse

1. Open **Spring Tool Suite (STS)**.
2. Select **File -> Import... -> Existing Maven Projects**.
3. Set the Root Directory to `c:\Users\Administrator\Desktop\project-final` and click **Finish**.
4. Right-click the project in the Project Explorer -> **Run As -> Spring Boot App**.
5. Once started, open `http://localhost:8080` in your browser.

---

## 🔑 Demo Account Credentials

Upon startup, the application's `SeedDataLoader` automatically creates demo accounts populated with sample items, recipe matches, notifications, and historical actions:

| User | Email | Password | Role |
| :--- | :--- | :--- | :--- |
| **Alex Green (Primary Demo)** | `alex@foodguard.com` | `password123` | `ROLE_USER` |
| **Demo User** | `demo@foodguard.com` | `password123` | `ROLE_USER` |

> *Tip: On the `/login` page, click the **"Use Demo Account (Alex Green)"** button to instantly auto-fill credentials!*
