# -*- coding: utf-8 -*-
"""
End-to-end Selenium test verifying whole-website translation in FoodGuard:
- Landing Page (Home)
- Login Page
- Dashboard
- Inventory Page
- Restaurant Stock Issue Modal ("Take Half kg")
- Multi-language coverage (Hindi, Telugu, Spanish, French)
- Persistence across navigations
"""
import sys
import time

# Ensure UTF-8 output on Windows console
if sys.stdout.encoding != 'utf-8':
    sys.stdout.reconfigure(encoding='utf-8', errors='replace')

from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait, Select
from selenium.webdriver.support import expected_conditions as EC

def run_tests():
    print("=== STARTING FOODGUARD WHOLE-WEBSITE TRANSLATION TEST ===")
    chrome_options = Options()
    chrome_options.add_argument("--headless=new")
    chrome_options.add_argument("--no-sandbox")
    chrome_options.add_argument("--disable-dev-shm-usage")
    chrome_options.add_argument("--window-size=1280,900")
    
    driver = webdriver.Chrome(options=chrome_options)
    wait = WebDriverWait(driver, 10)
    
    try:
        # TEST 1: Landing Page Translation to Hindi (hi)
        print("\n[TEST 1] Testing Landing Page Translation to Hindi...")
        driver.get("http://localhost:8080/")
        time.sleep(1)
        
        # Verify language selector exists
        lang_select_el = wait.until(EC.presence_of_element_located((By.ID, "languageSelect")))
        select = Select(lang_select_el)
        select.select_by_value("hi")
        time.sleep(1.2)
        
        page_text = driver.find_element(By.TAG_NAME, "body").text
        
        # Check Hindi terms on Landing Page
        assert "अपने भोजन को सुरक्षित रखें" in page_text or "डैशबोर्ड" in page_text, "Failed: Landing hero not in Hindi"
        print("[PASS] Landing page hero / header translated to Hindi successfully.")
        
        assert "आज ही मुफ़्त शुरू करें" in page_text or "लॉग इन" in page_text, "Failed: Landing CTA not in Hindi"
        print("[PASS] Landing CTA buttons translated to Hindi successfully.")

        # TEST 2: Navigation to Login Page & Persistence
        print("\n[TEST 2] Testing Login Page Language Persistence (Hindi)...")
        driver.get("http://localhost:8080/login")
        time.sleep(1.2)
        
        login_text = driver.find_element(By.TAG_NAME, "body").text
        assert "साइन इन" in login_text or "वापसी पर स्वागत है" in login_text, "Failed: Login page not in Hindi"
        assert "ईमेल पता" in login_text or "पासवर्ड" in login_text, "Failed: Login form labels not in Hindi"
        print("[PASS] Login page persisted and translated in Hindi successfully.")

        # TEST 3: Login to Account
        print("\n[TEST 3] Logging in using Demo Credentials...")
        driver.find_element(By.ID, "email").send_keys("alex@foodguard.com")
        driver.find_element(By.ID, "password").send_keys("password123")
        driver.find_element(By.CSS_SELECTOR, "button[type='submit']").click()
        time.sleep(1.5)

        # TEST 4: Dashboard Translation in Hindi
        print("\n[TEST 4] Verifying Dashboard in Hindi...")
        dash_text = driver.find_element(By.TAG_NAME, "body").text
        assert "डैशबोर्ड अवलोकन" in dash_text or "डैशबोर्ड" in dash_text, "Failed: Dashboard title not in Hindi"
        assert "सक्रिय वस्तुएं" in dash_text, "Failed: 'Active Items' stat card not in Hindi"
        assert "जल्द समाप्त होने वाला" in dash_text, "Failed: 'Expiring Soon' stat card not in Hindi"
        print("[PASS] Dashboard title, stat cards, and navigation in Hindi verified.")

        # TEST 5: Switch to Telugu (te) on Dashboard
        print("\n[TEST 5] Switching Language to Telugu (te) on Dashboard...")
        lang_select_el = wait.until(EC.presence_of_element_located((By.ID, "languageSelect")))
        select = Select(lang_select_el)
        select.select_by_value("te")
        time.sleep(1.2)

        te_dash_text = driver.find_element(By.TAG_NAME, "body").text
        assert "డాష్‌బోర్డ్ అవలోకనం" in te_dash_text or "డాష్‌బోర్డ్" in te_dash_text, "Failed: Dashboard not translated to Telugu"
        assert "క్రియాశీల అంశాలు" in te_dash_text, "Failed: 'Active Items' not in Telugu"
        assert "ఆర్థిక పొదుపు" in te_dash_text or "త్వరలో ముగియబోయేవి" in te_dash_text, "Failed: Stat cards not in Telugu"
        print("[PASS] Dashboard dynamically translated into Telugu successfully.")

        # TEST 6: Inventory Page in Telugu & Restaurant Stock Modal
        print("\n[TEST 6] Navigating to Inventory Page in Telugu...")
        driver.get("http://localhost:8080/inventory")
        time.sleep(1.2)

        inv_text = driver.find_element(By.TAG_NAME, "body").text
        assert "ఆహార ఇన్వెంటరీ" in inv_text, "Failed: Inventory title not in Telugu"
        assert "అంశం పేరు" in inv_text or "వర్గం" in inv_text or "పరిమాణం" in inv_text, "Failed: Inventory table headers not in Telugu"
        print("[PASS] Inventory page and table headers translated into Telugu successfully.")

        # TEST 7: Open Restaurant Stock Modal ("Take / Use")
        print("\n[TEST 7] Testing Restaurant Stock Issue Modal in Telugu...")
        take_btns = driver.find_elements(By.CSS_SELECTOR, "button[data-open-action]")
        assert len(take_btns) > 0, "No 'Take / Use' buttons found in inventory"
        take_btns[0].click()
        time.sleep(0.8)

        modal = driver.find_element(By.ID, "actionModal")
        modal_text = modal.text
        assert "స్టాక్ తీసుకోండి / ఉపయోగించండి" in modal_text, "Failed: Modal title not in Telugu"
        assert "అర కిలో తీసుకోండి" in modal_text or "సగం తీసుకోండి" in modal_text or "సగం" in modal_text, "Failed: Take Half button not in Telugu"
        assert "స్టాక్ మార్పు ప్రత్యక్ష ప్రివ్యూ" in modal_text, "Failed: Stock live preview card not in Telugu"
        print("[PASS] Restaurant stock issue modal and 'Take Half kg' options fully translated into Telugu.")

        # Close modal
        close_btn = modal.find_element(By.CSS_SELECTOR, "[data-modal-close]")
        close_btn.click()
        time.sleep(0.5)

        # TEST 8: Test Spanish (es) on Profile Page
        print("\n[TEST 8] Switching Language to Spanish (es) and visiting Profile...")
        lang_select_el = wait.until(EC.presence_of_element_located((By.ID, "languageSelect")))
        select = Select(lang_select_el)
        select.select_by_value("es")
        time.sleep(0.8)

        driver.get("http://localhost:8080/profile")
        time.sleep(1.2)

        prof_text = driver.find_element(By.TAG_NAME, "body").text
        assert "Configuración de la cuenta" in prof_text or "Artículos activos" in prof_text or "Inventario" in prof_text, "Failed: Profile not in Spanish"
        print("[PASS] Profile page translated into Spanish successfully.")

        # TEST 9: Test French (fr) on Recipes Page
        print("\n[TEST 9] Switching Language to French (fr) and visiting Recipes...")
        lang_select_el = wait.until(EC.presence_of_element_located((By.ID, "languageSelect")))
        select = Select(lang_select_el)
        select.select_by_value("fr")
        time.sleep(0.8)

        driver.get("http://localhost:8080/recipes")
        time.sleep(1.2)

        recipes_text = driver.find_element(By.TAG_NAME, "body").text
        assert "Recettes anti-gaspillage" in recipes_text or "Recettes" in recipes_text, "Failed: Recipes not in French"
        print("[PASS] Recipes page translated into French successfully.")

        print("\n=======================================================")
        print("ALL TESTS PASSED! FULL WEBSITE TRANSLATION VERIFIED 100%")
        print("=======================================================")

    finally:
        driver.quit()

if __name__ == "__main__":
    run_tests()
