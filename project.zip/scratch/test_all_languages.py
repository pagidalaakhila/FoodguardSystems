import sys
if sys.stdout.encoding != 'utf-8':
    sys.stdout.reconfigure(encoding='utf-8', errors='replace')
import time
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

opts = Options()
opts.add_argument('--headless=new')
opts.add_argument('--no-sandbox')
opts.add_argument('--disable-dev-shm-usage')
opts.add_argument('--window-size=1280,900')
driver = webdriver.Chrome(options=opts)
wait = WebDriverWait(driver, 10)

try:
    # 1. Login first
    driver.get('http://localhost:8080/login')
    time.sleep(1)
    driver.find_element(By.ID, 'email').send_keys('alex@foodguard.com')
    driver.find_element(By.ID, 'password').send_keys('password123')
    driver.find_element(By.CSS_SELECTOR, "button[type='submit']").click()
    time.sleep(1.5)
    print("Logged in successfully. Current URL:", driver.current_url)

    test_langs = [
        ('hi', 'Hindi'),
        ('te', 'Telugu'),
        ('ta', 'Tamil'),
        ('kn', 'Kannada'),
        ('es', 'Spanish'),
        ('fr', 'French')
    ]

    for lang_code, lang_name in test_langs:
        print(f"\n=======================================================")
        print(f"TESTING LANGUAGE: {lang_name} ({lang_code})")
        print(f"=======================================================")
        
        # Switch language
        driver.execute_script(f"changeFoodGuardLanguage('{lang_code}');")
        time.sleep(1.2)
        
        # Check Dashboard
        driver.get('http://localhost:8080/dashboard')
        time.sleep(1.2)
        dash_text = driver.find_element(By.TAG_NAME, 'body').text
        print(f"[{lang_name}] Dashboard Sample (lines 1-5):")
        for line in dash_text.splitlines()[:5]:
            if line.strip():
                print("   ", line.strip())

        # Check Inventory
        driver.get('http://localhost:8080/inventory')
        time.sleep(1.2)
        inv_text = driver.find_element(By.TAG_NAME, 'body').text
        print(f"[{lang_name}] Inventory Sample:")
        for line in inv_text.splitlines()[:5]:
            if line.strip():
                print("   ", line.strip())

        # Check Inventory Table headers & buttons
        th_elements = [el.text.strip() for el in driver.find_elements(By.CSS_SELECTOR, 'thead th') if el.text.strip()]
        print(f"[{lang_name}] Table Headers:", th_elements[:5])

        # Test Restaurant Stock Action Modal
        take_btns = driver.find_elements(By.CSS_SELECTOR, 'button[data-open-action]')
        if take_btns:
            driver.execute_script("arguments[0].click();", take_btns[0])
            time.sleep(0.6)
            modal = driver.find_element(By.ID, 'actionModal')
            modal_heading = modal.find_element(By.CSS_SELECTOR, '.modal-title').text
            btn_half = modal.find_element(By.ID, 'btnTakeHalf').text
            preview_box = modal.find_element(By.ID, 'kitchenPreviewBox').text
            print(f"[{lang_name}] Modal Title:", repr(modal_heading))
            print(f"[{lang_name}] Take Half Button:", repr(btn_half))
            print(f"[{lang_name}] Preview Box First Line:", repr(preview_box.splitlines()[0] if preview_box else ""))
            
            # Close modal via JS
            driver.execute_script("closeModal('actionModal');")
            time.sleep(0.3)

        # Check Recipes
        driver.get('http://localhost:8080/recipes')
        time.sleep(1.2)
        rec_h1 = driver.find_element(By.TAG_NAME, 'h1').text
        print(f"[{lang_name}] Recipes H1:", repr(rec_h1))

        # Check Analytics
        driver.get('http://localhost:8080/analytics')
        time.sleep(1.2)
        ana_h1 = driver.find_element(By.TAG_NAME, 'h1').text
        print(f"[{lang_name}] Analytics H1:", repr(ana_h1))

        # Check Profile
        driver.get('http://localhost:8080/profile')
        time.sleep(1.2)
        prof_title = driver.find_element(By.CSS_SELECTOR, '.official-gov-title').text
        print(f"[{lang_name}] Official Portal Title:", repr(prof_title))

    print("\n=======================================================")
    print("ALL LANGUAGES SUCCESSFULLY VERIFIED ACROSS WHOLE WEBSITE!")
    print("=======================================================")

finally:
    driver.quit()
