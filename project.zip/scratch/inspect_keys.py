import re
import sys
if sys.stdout.encoding != 'utf-8':
    sys.stdout.reconfigure(encoding='utf-8', errors='replace')

with open(r'src/main/resources/static/js/app.js', 'r', encoding='utf-8') as f:
    text = f.read()

# Find hi dictionary section
hi_match = re.search(r'hi:\s*\{(.*?)\n\s*\},', text, re.DOTALL)
if hi_match:
    hi_text = hi_match.group(1)
    pairs = re.findall(r'"([^"]+)":\s*"([^"]+)"', hi_text)
    print(f'Total hi pairs: {len(pairs)}')
    for k, v in pairs:
        if 'एक' in v:
            print(f'Key: {repr(k)} -> {repr(v)}')
        if k in 'History' or 'History' in k:
            print(f'History key: {repr(k)} -> {repr(v)}')
        if k in 'Analytics' or 'Analytics' in k:
            print(f'Analytics key: {repr(k)} -> {repr(v)}')
