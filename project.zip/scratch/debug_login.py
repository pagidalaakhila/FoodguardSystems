import sys
if sys.stdout.encoding != 'utf-8':
    sys.stdout.reconfigure(encoding='utf-8', errors='replace')
import time
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By

opts = Options()
opts.add_argument('--headless=new')
driver = webdriver.Chrome(options=opts)

driver.get('http://localhost:8080/dashboard')
time.sleep(1)
driver.find_element(By.ID, 'email').send_keys('alex@foodguard.com')
driver.find_element(By.ID, 'password').send_keys('password123')
driver.find_element(By.CSS_SELECTOR, "button[type='submit']").click()
time.sleep(1.5)

# First get English text
print('=== RAW ENGLISH DASHBOARD ===')
h1 = driver.find_element(By.TAG_NAME, 'h1').text
print('H1:', h1)

# Now call applyLanguage directly
driver.execute_script('applyLanguage("hi");')
time.sleep(0.5)

print('=== AFTER applyLanguage(hi) ===')
h1_hi = driver.find_element(By.TAG_NAME, 'h1').text
print('H1 after hi:', h1_hi)
nav_links = [el.text for el in driver.find_elements(By.CSS_SELECTOR, '.nav-links a')]
print('Nav links:', nav_links)
stat_labels = [el.text for el in driver.find_elements(By.CSS_SELECTOR, '.stat-label')]
print('Stat labels:', stat_labels)

driver.quit()
