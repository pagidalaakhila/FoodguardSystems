import os
import docx
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_ALIGN_VERTICAL
from docx.oxml import OxmlElement
from docx.oxml.ns import qn

def set_cell_background(cell, hex_color):
    """Sets background color of a table cell."""
    tc_pr = cell._tc.get_or_add_tcPr()
    shd = OxmlElement('w:shd')
    shd.set(qn('w:val'), 'clear')
    shd.set(qn('w:color'), 'auto')
    shd.set(qn('w:fill'), hex_color)
    tc_pr.append(shd)

def set_cell_margins(cell, top=100, bottom=100, left=150, right=150):
    """Sets cell internal padding in twips."""
    tc_pr = cell._tc.get_or_add_tcPr()
    tc_mar = OxmlElement('w:tcMar')
    for m, val in [('w:top', top), ('w:bottom', bottom), ('w:left', left), ('w:right', right)]:
        node = OxmlElement(m)
        node.set(qn('w:w'), str(val))
        node.set(qn('w:type'), 'dxa')
        tc_mar.append(node)
    tc_pr.append(tc_mar)

def create_document():
    doc = Document()

    # Page Margins: 1 inch on all sides
    for section in doc.sections:
        section.top_margin = Inches(1.0)
        section.bottom_margin = Inches(1.0)
        section.left_margin = Inches(1.0)
        section.right_margin = Inches(1.0)

    # Styles & Colors
    # Primary Forest Green: #1B4332, Secondary Forest: #2D6A4F, Cream Accent: #FAF9F5, Charcoal: #1E293B
    COLOR_FOREST_DARK = RGBColor(27, 67, 50)     # #1B4332
    COLOR_FOREST_MED = RGBColor(45, 106, 79)     # #2D6A4F
    COLOR_CHARCOAL = RGBColor(30, 41, 59)        # #1E293B
    COLOR_MUTED = RGBColor(100, 116, 139)        # #64748B

    # Document Header / Pre-title
    p_meta = doc.add_paragraph()
    r_meta = p_meta.add_run("SYSTEM DESIGN & PROBLEM SPECIFICATION SPECIFICATION • IEEE / INDUSTRY STANDARD")
    r_meta.font.name = "Calibri"
    r_meta.font.size = Pt(9.5)
    r_meta.font.bold = True
    r_meta.font.color.rgb = COLOR_FOREST_MED
    p_meta.paragraph_format.space_after = Pt(4)

    # Document Title
    p_title = doc.add_paragraph()
    r_title = p_title.add_run("Problem Statement Document:\nFoodGuard – Food Expiry and Waste Prevention System")
    r_title.font.name = "Calibri"
    r_title.font.size = Pt(22)
    r_title.font.bold = True
    r_title.font.color.rgb = COLOR_FOREST_DARK
    p_title.paragraph_format.space_after = Pt(8)

    # Subtitle / Tagline
    p_sub = doc.add_paragraph()
    r_sub = p_sub.add_run("An Enterprise-Grade, Full-Stack Architectural Solution for Household Inventory Tracking, Proactive Expiry Mitigation, Culinary Reuse, and Financial Optimization.")
    r_sub.font.name = "Calibri"
    r_sub.font.size = Pt(11.5)
    r_sub.font.italic = True
    r_sub.font.color.rgb = COLOR_CHARCOAL
    p_sub.paragraph_format.space_after = Pt(16)

    # Metadata Table
    meta_table = doc.add_table(rows=4, cols=2)
    meta_table.alignment = WD_TABLE_ALIGNMENT.CENTER
    meta_table.autofit = False

    metadata_entries = [
        ("Project Name", "FoodGuard – Food Expiry and Waste Prevention System"),
        ("Technology Stack", "Java 21, Spring Boot 3.3.4, Hibernate JPA, Spring Security 6 (BCrypt), Thymeleaf, MySQL 8.0, Chart.js, Maven"),
        ("Document Version / Status", "v1.0.0 (Production Release / Approved)"),
        ("Date of Publication", "October 2026")
    ]

    for idx, (label, val) in enumerate(metadata_entries):
        row = meta_table.rows[idx]
        cell_lbl, cell_val = row.cells[0], row.cells[1]
        cell_lbl.width = Inches(2.2)
        cell_val.width = Inches(4.3)
        
        p0 = cell_lbl.paragraphs[0]
        r0 = p0.add_run(label)
        r0.font.bold = True
        r0.font.size = Pt(10)
        r0.font.color.rgb = COLOR_FOREST_DARK
        
        p1 = cell_val.paragraphs[0]
        r1 = p1.add_run(val)
        r1.font.size = Pt(10)
        r1.font.color.rgb = COLOR_CHARCOAL

        set_cell_background(cell_lbl, "EEF9F1")
        set_cell_background(cell_val, "FAF9F5")
        set_cell_margins(cell_lbl, top=80, bottom=80, left=120, right=120)
        set_cell_margins(cell_val, top=80, bottom=80, left=120, right=120)

    doc.add_paragraph().paragraph_format.space_after = Pt(12)

    # Helper for Headings
    def add_h1(text):
        p = doc.add_paragraph()
        r = p.add_run(text)
        r.font.name = "Calibri"
        r.font.size = Pt(15)
        r.font.bold = True
        r.font.color.rgb = COLOR_FOREST_DARK
        p.paragraph_format.space_before = Pt(16)
        p.paragraph_format.space_after = Pt(6)
        return p

    def add_h2(text):
        p = doc.add_paragraph()
        r = p.add_run(text)
        r.font.name = "Calibri"
        r.font.size = Pt(12.5)
        r.font.bold = True
        r.font.color.rgb = COLOR_FOREST_MED
        p.paragraph_format.space_before = Pt(12)
        p.paragraph_format.space_after = Pt(4)
        return p

    def add_body(text):
        p = doc.add_paragraph()
        r = p.add_run(text)
        r.font.name = "Calibri"
        r.font.size = Pt(10.5)
        r.font.color.rgb = COLOR_CHARCOAL
        p.paragraph_format.space_after = Pt(6)
        p.paragraph_format.line_spacing = 1.15
        return p

    def add_bullet(bold_prefix, text):
        p = doc.add_paragraph(style='List Bullet')
        r_bold = p.add_run(bold_prefix + ": ")
        r_bold.font.name = "Calibri"
        r_bold.font.bold = True
        r_bold.font.size = Pt(10.5)
        r_bold.font.color.rgb = COLOR_FOREST_DARK

        r_text = p.add_run(text)
        r_text.font.name = "Calibri"
        r_text.font.size = Pt(10.5)
        r_text.font.color.rgb = COLOR_CHARCOAL
        p.paragraph_format.space_after = Pt(3)
        p.paragraph_format.line_spacing = 1.15
        return p

    # 1. Executive Summary
    add_h1("1. Executive Summary")
    add_body(
        "Food waste is one of the most critical economic, environmental, and ethical challenges of the modern era. "
        "Global studies conducted by the United Nations Environment Programme (UNEP) and the Food and Agriculture "
        "Organization (FAO) reveal that approximately one-third of all food produced for human consumption—amounting to "
        "nearly 1.3 billion metric tons annually—is lost or wasted. Over 60% of this waste occurs downstream at the "
        "household and retail level."
    )
    add_body(
        "In typical urban households, busy professional routines, unorganized storage facilities (refrigerators, deep freezers, "
        "and dry pantries), and the absence of proactive expiry tracking result in frequent spoilage of perishable groceries. "
        "Beyond the environmental burden of methane emissions in landfills, this waste inflicts substantial financial damage: "
        "an average Indian household silently loses between ₹15,000 and ₹30,000 annually on groceries that are bought, forgotten, "
        "and subsequently discarded."
    )
    add_body(
        "FoodGuard was conceived to confront this problem systematically. It is not merely an inventory tracker; it is an "
        "active waste prevention platform that combines dynamic date-driven status classification, daily automated scheduled audits, "
        "smart recipe recommendation algorithms that prioritize expiring ingredients, partial consumption tracking, and "
        "empirically computed financial analytics."
    )

    # 2. Detailed Problem Analysis
    add_h1("2. Detailed Problem Analysis")
    add_body(
        "An in-depth investigation into household grocery lifecycles identified five interconnected points of failure in existing human habits and technical tools:"
    )

    add_bullet(
        "A. The Visibility & Amnesia Gap",
        "Modern multi-zone storage appliances (crisper drawers, freezer compartments, deep shelves) obscure groceries. "
        "Consumers frequently purchase duplicate perishables while existing items quietly pass their expiration dates in the back of the refrigerator."
    )
    add_bullet(
        "B. The 'What Do I Cook Tonight?' Paradox",
        "Even when users realize an item (e.g., spinach, Greek yogurt, sourdough) is approaching expiry, they often lack immediate culinary ideas "
        "to combine fragmented remnants. Consequently, the food is left unconsumed until spoilage occurs."
    )
    add_bullet(
        "C. Absence of Real-Time Proactive Notification",
        "Traditional sticky notes, spreadsheets, and basic note-taking apps rely entirely on manual user memory. They lack automated, "
        "scheduled background daemon engines capable of notifying users days in advance across devices."
    )
    add_bullet(
        "D. All-or-Nothing Logging & Lack of Partial Auditing",
        "Existing food tracking tools treat food items as binary (e.g., either 'in stock' or 'consumed'). They fail to record partial usage "
        "(e.g., consuming 1 kg out of a 2 kg bag), resulting in corrupted inventory counts and loss of user engagement."
    )
    add_bullet(
        "E. The Invisible Financial Drain",
        "Because grocery purchases are made in modest increments over weeks, users rarely perceive the cumulative financial toll of wasted food. "
        "Without concrete metrics quantifying the exact currency lost vs. capital saved, behavioral change remains unattainable."
    )

    # 3. Purpose & Core Objectives
    add_h1("3. Purpose & Core Objectives of FoodGuard")
    add_body("The primary mission of the FoodGuard platform is defined by four measurable engineering and societal goals:")

    add_bullet(
        "1. Real-Time Expiry State Management",
        "Provide automatic day-to-day dynamic classification of all inventory items into Fresh (Green), Expiring Soon (Yellow), and Expired (Red) "
        "using java.time.LocalDate calculation against the active system calendar."
    )
    add_bullet(
        "2. Zero-Waste Culinary Transformation",
        "Implement an intelligent recipe recommendation engine that cross-references active pantry/fridge items, applying bonus weights to recipes "
        "that rescue items nearing expiration."
    )
    add_bullet(
        "3. Financial Quantification in Indian Rupees (₹)",
        "Accurately calculate cost impact down to partial item fractions. Track cumulative financial value saved (via consumption and donation) "
        "versus capital lost to spoilage, visualizing rates through Chart.js dashboards."
    )
    add_bullet(
        "4. Community Donation Integration",
        "Enable users to divert safe edible surpluses toward local community pantries, food drives, and neighbors, creating an auditable history log."
    )

    # 4. Target User Personas
    add_h1("4. Target User Personas & Stakeholder Analysis")

    persona_table = doc.add_table(rows=5, cols=3)
    persona_table.alignment = WD_TABLE_ALIGNMENT.CENTER
    persona_table.autofit = False

    headers = ["Persona", "Core Pain Points", "FoodGuard Solution"]
    for i, h in enumerate(headers):
        cell = persona_table.rows[0].cells[i]
        p = cell.paragraphs[0]
        r = p.add_run(h)
        r.font.bold = True
        r.font.size = Pt(10)
        r.font.color.rgb = RGBColor(255, 255, 255)
        set_cell_background(cell, "1B4332")
        set_cell_margins(cell, top=100, bottom=100, left=120, right=120)

    persona_data = [
        ("Working Professionals & Busy Families", "High grocery bills, uncoordinated meal planning, discarding spoiled vegetables and dairy weekly.", "Automated daily alert notifications, urgent dashboard warnings, and fast 1-click recipe suggestions."),
        ("Eco-Conscious Individuals & Zero-Waste Advocates", "Desire to eliminate landfill waste and greenhouse gas contribution but lack auditing tools.", "Comprehensive Food Action History, donation tracking, waste reduction percentages, and RFC-compliant CSV audit logs."),
        ("Budget-Conscious Students & Households", "Strict weekly grocery allowances; every discarded item directly inflates living costs.", "Real-time rupee financial scorecard (₹ Saved vs ₹ Wasted), partial quantity tracking with proportional costs."),
        ("Community Food Banks & Shelters", "Food donors donate too late (past expiration) or struggle to organize donations.", "Expiring Soon filter allows preemptive donation logging before items spoil, creating verifiable donation records.")
    ]

    col_widths = [Inches(1.8), Inches(2.3), Inches(2.4)]
    for r_idx, (p_name, p_pain, p_sol) in enumerate(persona_data, start=1):
        row = persona_table.rows[r_idx]
        bg = "FFFFFF" if r_idx % 2 == 1 else "F4F1EA"
        for c_idx, text in enumerate([p_name, p_pain, p_sol]):
            cell = row.cells[c_idx]
            cell.width = col_widths[c_idx]
            p = cell.paragraphs[0]
            r = p.add_run(text)
            r.font.size = Pt(9.5)
            r.font.color.rgb = COLOR_CHARCOAL
            if c_idx == 0:
                r.font.bold = True
            set_cell_background(cell, bg)
            set_cell_margins(cell, top=80, bottom=80, left=120, right=120)

    doc.add_paragraph().paragraph_format.space_after = Pt(10)

    # 5. Functional Scope & Module Specifications
    add_h1("5. Functional Scope & Architectural Modules")

    add_h2("Module 1: Identity & Enterprise Security")
    add_body(
        "Built on Spring Security 6, BCrypt password hashing (10 salt rounds), and DaoAuthenticationProvider. "
        "Enforces strict per-user data isolation—no user can view, edit, or delete another user's food items or actions. "
        "Equipped with CSRF tokens on all data-modifying forms and custom authentication handlers."
    )

    add_h2("Module 2: Inventory CRUD & Dynamic Classification")
    add_body(
        "Supports comprehensive food metadata: Name, Category (Produce, Dairy, Meat, Bakery, Pantry, Beverages, Frozen, Other), "
        "Storage Location (Fridge, Freezer, Pantry, Countertop), Quantity, Unit of Measure, Purchase Date, Expiry Date, "
        "Cost in INR (₹), and Notes. Includes dynamic multi-parameter search, multi-category and multi-location filters, column sorting, "
        "and pagination."
    )

    add_h2("Module 3: Daily Expiry Scheduler & Alert Daemon")
    add_body(
        "Leverages Spring's @Scheduled background execution engine running daily at midnight (0 0 0 * * ?) and during application startup. "
        "Scans all registered items against each user's personalized warning threshold (1, 2, 3, 5, 7, or 14 days). "
        "Generates deduplicated in-app notifications and dispatches automated email alert reminders."
    )

    add_h2("Module 4: Action Auditing & Partial Waste Tracking")
    add_body(
        "Allows logging three distinct life-cycle events: Consumed, Donated, or Wasted. "
        "Supports decimal partial amounts (e.g. eating 0.50 of an item): recalculates remaining inventory and proportional financial impact "
        "automatically. Complete audit entries are stored in the normalized food_actions table."
    )

    add_h2("Module 5: Smart Zero-Waste Recipe Matching")
    add_body(
        "Analyzes ingredients currently present in the user's kitchen. Compares available inventory with zero-waste recipe templates, "
        "awarding extra priority weighting to recipes that rescue items expiring today or tomorrow."
    )

    add_h2("Module 6: Chart.js Visual Analytics & RFC 4180 CSV Export")
    add_body(
        "Computes real-time analytical distributions directly from MySQL: 6-month stacked bar monthly trends, doughnut category allocations, "
        "horizontal storage breakdown, and cumulative financial balance in Indian Rupees (₹). "
        "Allows instant CSV report downloads for both active inventory and historical audit logs."
    )

    # 6. Database Schema & Data Dictionary
    add_h1("6. Relational Database Design (MySQL 8.0)")
    add_body(
        "The relational schema is normalized to Third Normal Form (3NF) with cascade deletion constraints and composite indexes for high-speed queries:"
    )

    schema_table = doc.add_table(rows=6, cols=3)
    schema_table.alignment = WD_TABLE_ALIGNMENT.CENTER
    schema_table.autofit = False

    s_headers = ["Table Name", "Primary Key & Foreign Keys", "Description & Key Columns"]
    for i, h in enumerate(s_headers):
        cell = schema_table.rows[0].cells[i]
        p = cell.paragraphs[0]
        r = p.add_run(h)
        r.font.bold = True
        r.font.size = Pt(10)
        r.font.color.rgb = RGBColor(255, 255, 255)
        set_cell_background(cell, "1B4332")
        set_cell_margins(cell, top=100, bottom=100, left=120, right=120)

    s_data = [
        ("users", "id (PK)", "Stores credentials (email, BCrypt password), full name, role, alert_days_before preference, email notification flag."),
        ("food_items", "id (PK)\nuser_id (FK -> users.id)", "Active inventory records with category, storage_location, quantity, unit, purchase_date, expiry_date, cost, and notes."),
        ("food_actions", "id (PK)\nuser_id (FK -> users.id)", "Audit trail logging action_type (CONSUMED, DONATED, WASTED), quantity, cost_impact, action_date, and notes."),
        ("notifications", "id (PK)\nuser_id (FK -> users.id)", "System alert queue storing title, message, type (EXPIRING_SOON, EXPIRED), is_read flag, and timestamp."),
        ("recipes", "id (PK)", "Curated culinary repository storing title, category, prep_time_minutes, ingredients_text, instructions, and high-resolution photo URLs.")
    ]

    s_col_widths = [Inches(1.5), Inches(2.0), Inches(3.0)]
    for r_idx, (t_name, t_keys, t_desc) in enumerate(s_data, start=1):
        row = schema_table.rows[r_idx]
        bg = "FFFFFF" if r_idx % 2 == 1 else "F4F1EA"
        for c_idx, text in enumerate([t_name, t_keys, t_desc]):
            cell = row.cells[c_idx]
            cell.width = s_col_widths[c_idx]
            p = cell.paragraphs[0]
            r = p.add_run(text)
            r.font.size = Pt(9.5)
            r.font.color.rgb = COLOR_CHARCOAL
            if c_idx == 0:
                r.font.bold = True
            set_cell_background(cell, bg)
            set_cell_margins(cell, top=80, bottom=80, left=120, right=120)

    doc.add_paragraph().paragraph_format.space_after = Pt(10)

    # 7. Non-Functional Requirements & Performance
    add_h1("7. Non-Functional & Quality Requirements")
    add_bullet("Performance & Responsiveness", "Sub-200ms page response time; database indexing on (user_id, expiry_date) and (user_id, action_date) ensures rapid retrieval.")
    add_bullet("Data Integrity & ACID Transactions", "@Transactional service boundaries prevent database inconsistency during simultaneous inventory deduction and action logging.")
    add_bullet("UI/UX Design Aesthetics", "Tailored Forest Green (#1B4332, #52B788), Warm Cream (#FAF9F5), and Slate Grey color palette with micro-animations, status badges, and mobile-responsive grid layouts.")
    add_bullet("Permanent Availability", "Auto-starting Windows background daemon and standalone production JAR ensuring continuous availability across reboots.")

    # 8. Expected Outcomes & Impact Metrics
    add_h1("8. Expected Outcomes & Impact Metrics")
    add_body(
        "Upon full deployment and routine household adoption, FoodGuard delivers quantifiable improvements across economic and ecological vectors:"
    )

    add_bullet("Food Waste Reduction", "Targeted 30% to 45% reduction in domestic food spoilage within the first 60 days of active use.")
    add_bullet("Direct Financial Savings", "Estimated average annual savings of ₹15,000 to ₹25,000 per household through reclaimed perishables.")
    add_bullet("Landfill Methane Mitigation", "Measurable decrease in organic waste disposal, preventing domestic methane emission.")
    add_bullet("Community Nutrition Support", "Increased redirection of edible surpluses toward registered charities and food distribution networks.")

    # 9. Conclusion
    add_h1("9. Conclusion")
    add_body(
        "The FoodGuard – Food Expiry and Waste Prevention System bridges the gap between passive food storage and proactive waste prevention. "
        "By uniting enterprise software engineering principles (Spring Boot 3, Spring Security, Hibernate, MySQL) with user-centric design "
        "and intelligent recipe matching, FoodGuard transforms household kitchens into sustainable, cost-effective, and zero-waste environments."
    )

    # Save to project folder
    target_path = os.path.abspath("FoodGuard_Problem_Statement_Document.docx")
    doc.save(target_path)
    print("Saved document to:", target_path)

    # Copy to Desktop for 1-click user access
    desktop_path = r"C:\Users\Administrator\Desktop\FoodGuard_Problem_Statement_Document.docx"
    doc.save(desktop_path)
    print("Saved copy to Desktop:", desktop_path)

if __name__ == "__main__":
    create_document()
